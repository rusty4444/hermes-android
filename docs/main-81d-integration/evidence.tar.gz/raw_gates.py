import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path(__file__).parent
s=importlib.util.spec_from_file_location('v',ROOT/'verify.py'); v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
raw=ROOT/'raw-app'
subprocess.run(['cp','-cR',str(v.APP),str(raw)],check=True)
v.APP=raw
names=['independent_spec_cc009ac_boundary_test.dart','independent_spec_cc009ac_request_start_test.dart','history_authority_ambiguity_counterexample_test.dart','independent_spec_77413_adverse_test.dart','independent_spec_116_boundaries_test.dart']
with tarfile.open(v.REPO/'docs/unreconciled-output/oracles-raw.tar.gz') as t:
    for n in names:
        (raw/'test'/n).write_bytes(t.extractfile('independent/'+n+'.harness').read())
# Exact archived sources, not loader compatibility shims.
v.run('final-raw-removed-api',['/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*['test/'+n for n in names[:4]]])
v.run('final-raw13',['/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json','test/'+names[-1]])
