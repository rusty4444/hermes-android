import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).parent
REPO=Path('/Volumes/Storage/Hermes/workspace/hermes-android-main-81d-integration')
DEST=REPO/'docs/main-81d-integration'
DEST.mkdir(parents=True,exist_ok=True)
extra=ROOT/'third-layer'
extra.mkdir(exist_ok=True)
parents=json.loads((ROOT/'parent-manifests.json').read_text())
ours='dfa65072439e79edf744be213defc91f30293f9b'
peer='81d10e7fbdc0ddd499d77a104d05f1d61b70808d'
manifest=parents[ours]
ledger=[]
for file in subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=REPO,text=True).splitlines():
    if not file.startswith('test/') or not file.endswith('.dart'):continue
    old=subprocess.check_output(['git','show',ours+':'+file],cwd=REPO,text=True) if file in manifest else ''
    new=(REPO/file).read_text()
    diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=ours+':'+file,tofile='main81d:'+file))
    (extra/(Path(file).name+'.diff')).write_text(diff)
    hunks=[l for l in diff.splitlines() if l.startswith('@@')]
    ledger.append({'path':file,'raw_sha256':hashlib.sha256(old.encode()).hexdigest(),'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'hunks':hunks,'class':'S only metadata-autoopen/cross-dispose reasoning; A explicit same-visit token/selectors; D peer new cases; all other safety assertions R','exact_diff':Path(file).name+'.diff'})
ind=json.loads((ROOT/'raw/independent-test-sources.json').read_text())
for name in ['review_root_public_cc_spec_test.dart','review_public_visit_preview_cc_spec_test.dart']:
    file='test/'+name
    newfile=file.removesuffix('_test.dart')+'_main81d_policy_test.dart'
    old=ind[file]; new=(ROOT/'app'/newfile).read_text()
    (extra/(Path(newfile).name+'.harness')).write_text(new)
    diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='raw:'+file,tofile=newfile))
    (extra/(name+'.diff')).write_text(diff)
    ledger.append({'raw_path':file,'new_path':newfile,'raw_sha256':hashlib.sha256(old.encode()).hexdigest(),'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'hunks':[l for l in diff.splitlines() if l.startswith('@@')],'class':'S post-dispose global reasoning value premise only; A explicit visit API; other assertions and schedules R','exact_diff':name+'.diff'})
# Each exact hunk carries source ranges and assertion disposition; untouched
# lines are R, not a claim that entire changed files are byte-unchanged.
for entry in ledger:
    path = entry.get('path', entry.get('raw_path'))
    new_path = entry.get('new_path', path)
    entry['original_case_ids'] = [c['name'] for c in json.loads((ROOT/'prior-case-ids.json').read_text()) if c['path'] == path]
    entry['final_case_ids'] = [c['name'] for c in json.loads((ROOT/'final-combined-summary.json').read_text())['cases'] if c['path'] == new_path]
    diff = (extra / entry['exact_diff']).read_text()
    parts = __import__('re').split(r'(?=^@@ )', diff, flags=__import__('re').M)[1:]
    ranges=[]
    for part in parts:
        header=part.splitlines()[0]
        match=__import__('re').match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))?',header)
        if not match: continue
        disposition='A'
        reason='Explicit visit acquisition/reference or fixture geometry only; same schedule and safety expectations.'
        if any(x in part for x in ['published reopen reset is tool-only','Reasoning retains its app-owned pin','-          reasoning,']):
            disposition='S';reason='Only true-dispose reasoning manual-retention premise is superseded by PR174; retained bodies, keys, draft and no-replay controls remain R.'
        elif any(x in part for x in ['root.reasoningPins','a.reasoningPins','b.reasoningPins']):
            disposition='S/A';reason='Replace app-global merged reasoning choices with independently acquired current-view tokens; all tool alias/bounds/close assertions remain R.'
        elif any(x in part for x in ['expands reasoning the gateway','lateVerbose ?','false, true','verbose display']):
            disposition='S/A';reason='Exact peer app-Verbose-only default replaces gateway metadata autoopen; retain original text/order and manual-open assertions.'
        elif entry.get('path','').endswith(('compact_delegated_task_card_test.dart','chat_timeline_test.dart')):
            disposition='D';reason='Peer new compact/app-Verbose cases added alongside every existing case.'
        elif 'reasoning defaults collapsed' in part:
            disposition='D/Q';reason='Keep peer Navigator active/completes-away body/no-submit semantics; only disclosed C/R lazy geometry adjustment.'
        ranges.append({'header':header,'old_start':int(match[1]),'old_count':int(match[2] or 1),'new_start':int(match[3]),'new_count':int(match[4] or 1),'disposition':disposition,'reason':reason,'exact_hunk':part})
    entry['assertion_ranges']=ranges
    entry['all_unmodified_lines']='R; original inputs/schedules and every unrelated assertion retained'
(extra/'ORACLE-LEDGER.json').write_text(json.dumps(ledger,indent=2))
(extra/'minimal-production-adapter.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--','lib/core/screens/chat_screen.dart','lib/core/services/chat_presentation_state.dart'],cwd=REPO))
(extra/'final-vs-ours.diff').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=REPO))
(extra/'final-vs-peer.diff').write_bytes(subprocess.check_output(['git','diff',peer,'--','lib/core/screens/chat_screen.dart','lib/core/services/chat_presentation_state.dart','lib/core/utils/chat_display_items.dart','test/chat_history_scroll_test.dart','test/chat_timeline_test.dart','test/normal_gateway_route_reattachment_test.dart'],cwd=REPO))
# Exact source/case union: the only removed names are the peer's three renames.
delta=json.loads((ROOT/'case-union-delta.json').read_text())
assert len(delta['missing'])==3 and len(delta['added'])==34
renames={
 'buildChatDisplayItems expands reasoning the gateway marked verbose':'buildChatDisplayItems keeps gateway-marked verbose reasoning collapsed by default',
 'ChatScreen integration Remote completed preview preserves late reasoning.available and verbose display':'ChatScreen integration Remote completed preview retains late reasoning.available without auto-expanding reasoning',
 'ChatScreen integration Remote completed preview preserves late reasoning.delta and verbose display':'ChatScreen integration Remote completed preview retains late reasoning.delta without auto-expanding reasoning',
}
newids={(x['path'],x['name']) for x in json.loads((ROOT/'final-combined-summary.json').read_text())['cases']}
assert all((p,renames[n]) in newids for p,n in delta['missing'])
delta['explicit_peer_renames']=renames
delta['unexplained_missing']=[]
(extra/'case-union-delta.json').write_text(json.dumps(delta,indent=2))
# Repeat unsigned verification with correct Java; keep the failed preflight honest.
apk=ROOT/'app/build/app/outputs/flutter-apk/app-debug.apk'
env=dict(os.environ,JAVA_HOME='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home')
r=subprocess.run(['/Users/sam.russell/Library/Android/sdk/build-tools/36.0.0/apksigner','verify','--verbose',str(apk)],env=env,capture_output=True,text=True)
assert r.returncode==1 and 'DOES NOT VERIFY' in r.stdout+r.stderr
build={'path':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'size':apk.stat().st_size,'signature_verify_exit':r.returncode,'signature_output':r.stdout+r.stderr,'scope':'final genuinely unsigned local debug; initial automatic debug-signed scratch artifact disclosed separately; no production signing/install/distribution'}
(extra/'FINAL-UNSIGNED-APK.json').write_text(json.dumps(build,indent=2))
# Preserve raw original archives untouched; build a separate third layer.
files=[p for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.json','.log','.md','.py','.diff'}]+list((ROOT/'raw').iterdir())+list(extra.iterdir())
with tarfile.open(DEST/'evidence.tar.gz','w:gz') as t:
    for p in sorted(set(files)):
        t.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
cases=json.loads((ROOT/'final-combined-summary.json').read_text())['cases']
(DEST/'case-ids.json.gz').write_bytes(gzip.compress(json.dumps(cases,indent=2).encode(),mtime=0))
gates=json.loads((ROOT/'FINAL-GATES.json').read_text())
gates.append(json.loads((ROOT/'final-worker53-summary.json').read_text()))
summary={
 'status':'UNRELEASED implementation handoff; fresh independent combined CORE and Root/public SPEC then QUALITY required',
 'parents':[ours,peer], 'merge_base':'459022b93fe1e422cf03bee74862a9a4fefe4fe2',
 'published_version':'2.1.32+2175','reasoning_policy':'actual mounted-visit manual choices; default collapsed unless explicit app Verbose; supersedes old tool-only reset premise for reasoning choices only',
 'evidence_root':str(ROOT),
 'gates':[{k:v for k,v in g.items() if k!='cases'} for g in gates],
 'tracked_unique':2336,'combined_unique':2443,'new_adapter_unique':16,'peer_new_unique':15,
 'original_retained_unique':421,'retained_plus_peer_unique':425,
 'source_blobs_verified_before_after_tests_build':586,
 'unchanged_dfa_blobs':570,'changed_dfa_paths':json.loads((ROOT/'parent-unchanged-audit.json').read_text())['dfa_changed'],
 'dependency_audit':json.loads((ROOT/'cache-after.json').read_text()),
 'case_union':delta,
 'raw_originals':{'four_removed_api_probes':'exit1; four loader failures / seven error events; no semantic cases started','raw13':'exit1;12 passes + known post-assert timer failure','cleanup13':'exit0;13 same-content cases, not26 distinct'},
 'root_public':{'total':59,'byte_unchanged_files':5,'byte_unchanged_cases':46,'explicit_adapted_files':2,'cases_in_adapted_files':13,'semantic_reasoning_premise_changes':10},
 'local_unsigned_build':build,
 'limits':['No independent SPEC/QUALITY approval','Native36/server126 historical reuse only','No production signing/Vault/credentials, install, deployment, device/provider/live server/config/model/TUI/push/tag/PR/release action','First attempted unsigned hook was too late and auto debug-signed a scratch dev artifact; final hook before variant creation produces verified unsigned artifact','Existing Kotlin plugin migration/l10n fallback warnings remain'],
 'artifacts':{n:hashlib.sha256((DEST/n).read_bytes()).hexdigest() for n in ['evidence.tar.gz','case-ids.json.gz']},
}
(DEST/'verification.json').write_text(json.dumps(summary,indent=2))
print('evidence bytes',(DEST/'evidence.tar.gz').stat().st_size,'ledger entries',len(ledger))
print(json.dumps(summary['artifacts']))
