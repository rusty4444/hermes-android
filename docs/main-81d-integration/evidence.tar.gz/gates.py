import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).parent
spec=importlib.util.spec_from_file_location('verify',ROOT/'verify.py')
v=importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
v.sync()
prior=json.loads((v.REPO/'docs/unreconciled-output/verification.json').read_text())
tracked=sorted(str(p.relative_to(v.APP)) for p in (v.APP/'test').glob('*_test.dart') if (v.REPO/'test'/p.name).exists())
combined=sorted(str(p.relative_to(v.APP)) for p in (v.APP/'test').glob('*_test.dart'))
formatfiles=sorted(set(subprocess.check_output(['git','diff','--name-only','459022b','HEAD','--','*.dart'],cwd=v.REPO,text=True).splitlines()+subprocess.check_output(['git','diff','--name-only','HEAD','--','*.dart'],cwd=v.REPO,text=True).splitlines()+['test/reasoning_visit_main81d_test.dart']))
results=[]
results.append(v.run('final-format', ['/opt/homebrew/bin/dart','format','--output=none','--set-exit-if-changed',*formatfiles]))
results.append(v.run('final-analysis',['/opt/homebrew/bin/flutter','analyze','--no-pub','--fatal-infos','lib','test']))
for name, files in [('final-tracked',tracked),('final-combined',combined)]:
    results.append(v.run(name,['/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*files]))
for name,key in [('final-retained','final-candidate-retained421'),('final-policy','final-candidate-policy26'),('final-B','final-candidate-B38'),('final-prior-received','final-candidate-prior22'),('final-prior-presentation','final-candidate-previous-new22'),('final-Root-public','final-candidate-root59'),('final-cleanup','final-candidate-cleanup13')]:
    args=prior['gates'][key]['args']
    args=[x.removesuffix('_test.dart')+'_main81d_policy_test.dart' if x.endswith(('review_root_public_cc_spec_test.dart','review_public_visit_preview_cc_spec_test.dart')) else x for x in args]
    results.append(v.run(name,args))
drafts=['test/'+n for n in ['chat_composer_draft_test.dart','chat_draft_alias_handoff_test.dart','chat_draft_lifecycle_test.dart','composer_draft_alias_test.dart','composer_draft_alias_transaction_test.dart','composer_draft_store_race_test.dart','late_identity_draft_test.dart']]
results.append(v.run('final-draft-owner',['/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*drafts]))
(ROOT/'FINAL-GATES.json').write_text(json.dumps(results,indent=2))
source=json.loads((ROOT/'tested-source.json').read_text())
mismatches=[f for f,h in source.items() if v.digest(v.APP/f)!=h or v.digest(v.REPO/f)!=h]
(ROOT/'post-test-source.json').write_text(json.dumps({'files':len(source),'mismatches':mismatches},indent=2))
print('SOURCE',len(source),mismatches)
print('GATES',[(x['name'],x['exit'],x.get('passed'),len(x.get('errors',[]))) for x in results])
assert not mismatches
assert all(x['exit']==0 and not x.get('errors') and (x.get('done') is None or x['done']['success']) for x in results)
