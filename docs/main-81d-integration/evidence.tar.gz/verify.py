import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import urljoin, urlparse, unquote

ROOT = Path(__file__).parent
REPO = Path('/Volumes/Storage/Hermes/workspace/hermes-android-main-81d-integration')
BORROW = Path('/Volumes/Storage/Hermes/scratch/p2a-unreconciled-_flkt2h9/app')
APP = ROOT / 'app'
ENV = dict(os.environ)
ENV.update(HOME=str(ROOT / 'home'), PUB_CACHE=str(ROOT / 'pub-cache'), TMPDIR='/Users/sam.russell/.hermes/cache/scratch', FLUTTER_SUPPRESS_ANALYTICS='true', JAVA_HOME='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home', ANDROID_HOME='/Users/sam.russell/Library/Android/sdk', ANDROID_SDK_ROOT='/Users/sam.russell/Library/Android/sdk')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sync():
    APP.mkdir(exist_ok=True)
    (APP / 'review-evidence').mkdir(exist_ok=True)
    for f in subprocess.check_output(['git', 'ls-files'], cwd=REPO, text=True).splitlines():
        src = REPO / f
        if src.is_file():
            dst = APP / f
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
    for src in (REPO / 'test').rglob('*.dart'):
        dst = APP / src.relative_to(REPO)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    cfgpath = BORROW / '.dart_tool/package_config.json'
    cfg = json.loads(cfgpath.read_text())
    for p in cfg['packages']:
        p['rootUri'] = '../' if p['name'] == 'hermes_android' else urljoin(cfgpath.as_uri(), p['rootUri'])
    (APP / '.dart_tool').mkdir(exist_ok=True)
    (APP / '.dart_tool/package_config.json').write_text(json.dumps(cfg, indent=2))
    for f in ['.dart_tool/package_graph.json', '.flutter-plugins-dependencies']:
        shutil.copyfile(BORROW / f, APP / f)
    (ROOT / 'home').mkdir(exist_ok=True)
    (ROOT / 'pub-cache').mkdir(exist_ok=True)
    ind = json.loads((ROOT / 'raw/independent-test-sources.json').read_text())
    for f, text in ind.items():
        if Path(f).name in {'review_root_public_cc_spec_test.dart', 'review_public_visit_preview_cc_spec_test.dart'}:
            f = f.removesuffix('_test.dart') + '_main81d_policy_test.dart'
        dst = APP / f
        if not dst.exists():
            dst.write_text(text)
    tracked = set(subprocess.check_output(['git','ls-files'],cwd=REPO,text=True).splitlines())
    source = {str(p.relative_to(REPO)): digest(p) for p in REPO.rglob('*') if p.is_file() and (str(p.relative_to(REPO)) in tracked or (p.suffix=='.dart' and p.is_relative_to(REPO/'test')))}
    (ROOT / 'tested-source.json').write_text(json.dumps(source, indent=2))
    return cfg

def parse(log):
    tests = {}; suites = {}; finishes = {}; errors = []; done = None
    for line in log.read_text().splitlines():
        try: e = json.loads(line)
        except ValueError: continue
        if e.get('type') == 'suite': suites[e['suite']['id']] = e['suite']['path']
        if e.get('type') == 'testStart': tests[e['test']['id']] = e['test']
        if e.get('type') == 'testDone' and e['testID'] in tests and not e.get('hidden', False):
            t=tests[e['testID']]
            if not t['name'].startswith('loading '): finishes[e['testID']] = e
        if e.get('type') == 'error': errors.append(e)
        if e.get('type') == 'done': done=e
    cases=[{'path':os.path.relpath(suites[tests[i]['suiteID']], APP), 'name':tests[i]['name'], 'result':e['result'], 'skipped':e.get('skipped',False)} for i,e in finishes.items()]
    ids=[(c['path'],c['name']) for c in cases]
    assert len(ids)==len(set(ids))
    return {'unique':len(cases), 'passed':sum(c['result']=='success' and not c['skipped'] for c in cases), 'skipped':sum(c['skipped'] for c in cases), 'errors':errors, 'done':done, 'cases':cases}

def run(name, args, timeout=600):
    log=ROOT/(name+'.log'); start=time.monotonic()
    with log.open('w') as out:
        try:
            r=subprocess.run(args,cwd=APP,env=ENV,stdout=out,stderr=subprocess.STDOUT,timeout=timeout); rc=r.returncode
        except subprocess.TimeoutExpired:
            rc=124
    summary={'name':name, 'args':args, 'exit':rc, 'seconds':round(time.monotonic()-start,3), 'log':str(log)}
    if '--reporter=json' in args: summary.update(parse(log))
    (ROOT/(name+'-summary.json')).write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','errors')},indent=2),flush=True)
    if summary.get('errors'): print(json.dumps(summary['errors'])[:15000],flush=True)
    if rc and '--reporter=json' not in args: print(log.read_text()[-20000:],flush=True)
    return summary

if __name__ == '__main__':
    if sys.argv[1]=='sync': sync(); print(str(APP))
    else: run(sys.argv[1],sys.argv[2:])
