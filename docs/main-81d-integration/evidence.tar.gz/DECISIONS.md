# Binding semantic decisions before edits

Ours: complete accepted loaded/paged saved C plus bounded volatile labelled unconfirmed received R, independent projection/keys, no guessed correlation or materialized retirement, with application-owned turns/drafts/aliases and physical request-start B fences.
Peer: compact task rows without truncating underlying detail or changing observer/transport, and collapsed reasoning unless explicit app Verbose; manual reasoning choices persist only within an actual mounted chat visit.

## All upstream hunks (459 ->81d)
- chat_screen +375: same-question-different-answer. Keep app-owned registry/writers/controllers; replace app-global reasoning choice authority with a bounded actual-view visit token, not peer unbounded Map. PR174 supersedes only cross-visit reasoning manual retention.
- chat_display_items +158, +185: same-question-different-answer; keep peer explicit-app-Verbose-only defaults for live and stored projections. Preserve our independent C/R helper and no-eviction-resurrection behavior.
- delegated_task_timeline +226: disjoint-intent; retain exact peer model/detail and duplicate-live-preview guard within existing scrollable GET-only controller.
- gateway_insight_card +209: disjoint-intent; retain exact peer one-line goal/status/model, no large detail, existing callbacks/data unchanged.
- chat_display_items_test +346,+358: superseded gateway-verbose-autoopen oracle; retain exact peer collapsed-default assertion.
- chat_history_scroll_test +197,+1116,+1149,+1172: superseded gateway-autoopen oracle plus disjoint manual expansion/order controls; retain peer assertions and all existing C/R physical/scroll assertions.
- chat_timeline_test +41: disjoint-intent; combine peer app-verbose cases with our eviction/identity cases, no removed declarations.
- compact_delegated_task_card_test new: disjoint-intent; exact 11 peer cases unchanged.
- normal_gateway_route_reattachment_test +262: same-question-different-answer resolved PR174; retain exact Navigator pop/reopen, active/completesAway, body retention, streaming manual choice and no-resubmit assertions.
- normal_gateway_route_reattachment_test +846,+891 fixture: disjoint-intent; add peer navigable wrapper to our helper while retaining own push mode, resume hook, physical history request accounting and received retention oracles. Do not replace helper wholesale.

## Marker hunks
1 chat_screen: combine app owners with bounded reasoning visit, superseding global value getter.
2 chat_timeline_test: concatenate both independent groups.
3 route reattachment helper: combine both fixture modes as above.

## Clean authority hotspots
- Registry bind/close: transfer reasoning visit TOKENS alongside existing tool tokens; never merge manual values. No changes to draft chronology/writer lease/persistence. Each reasoning visit uses existing 100-value/100-alias bounded pins class; reasoning IDs already stable from first render, no invented alias correlation.
- ChatScreen init/dispose/updates: one reasoning token for actual State; lazy rebuild/cover/child modal/alias/hydration cannot reset it. On actual different connection/config/controller or unrelated-chat replacement, acquire fresh reasoning token without resetting bodies/drafts/tools/turn owner. Same verified local-stored root retains token.
- Root normal/push navigation, owner snapshot callbacks/latest/deferred/cold read authority, row-only merge, model/HTTP/WAL, received budgets/export/voice/unread remain unchanged.
- Original registry-level global reasoning access tests need explicit visit acquisition and same-token assertions. Old Root/public alias test expected copying both independent reasoning choices into one global root: superseded only that premise; retain independent values per token, all tool/draft/alias/close assertions and original schedules.
- Preserve frozen prior compressed raw/policy archives and verification; add third-layer exact diffs/inventory/report, never rewrite history.
