import hashlib,io,json,pathlib,plistlib,shutil,subprocess,sys,tarfile
R=pathlib.Path(__file__).parent;W=pathlib.Path((R/'workspace.txt').read_text());B=R/'baseline-repeat';A=B/'app'
assert plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
A.mkdir(parents=True);(B/'home').mkdir();(B/'pub-cache').mkdir();(A/'.dart_tool').mkdir();(A/'review-evidence').mkdir()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','78e3d11b64095d08266ca15882a1468793c73910'],cwd=W))) as t:t.extractall(A,filter='data')
manifest=json.loads((R/'source-before.json').read_text())
assert all(hashlib.sha256((A/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
for p in ['.dart_tool/package_config.json','.dart_tool/package_graph.json','.flutter-plugins-dependencies']:shutil.copy2(R/'app'/p,A/p)
for p in (R/'raw-inputs').glob('independent_core78*_test.dart'):shutil.copy2(p,A/'test'/p.name)
shutil.copy2(R/'app/test/independent_root78_valid_origin_test.dart',A/'test/independent_root78_valid_origin_test.dart')
shutil.copy2(R/'run.py',B/'run.py');shutil.copy2(R/'workspace.txt',B/'workspace.txt')
args=[sys.executable,str(B/'run.py'),'baseline-repeat-preserved','/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*[f'test/{p.name}' for p in sorted((A/'test').glob('independent_core78*_test.dart'))],'test/independent_root78_valid_origin_test.dart']
p=subprocess.run(args);assert p.returncode==1
receipt=json.loads((B/'baseline-repeat-preserved-receipt.json').read_text());assert receipt['count']==28 and receipt['results']=={'success':22,'error':6} and not receipt['skips'] and not any('Failed to load' in e['error'] for e in receipt['errors'])
for p in B.glob('baseline-repeat-preserved*'):shutil.copy2(p,R/p.name)
facts={}
for p in (A/'review-evidence').glob('independent-ROOT78-stale-action-*.json'):
 j=json.loads(p.read_text());assert j['bindingChanged'] and j['oldOwnerReplaced'] and j['sameSavedId'] and j['sameOldActionObjectRetained'];facts[p.name]={k:j[k] for k in ['bindingChanged','oldOwnerReplaced','sameSavedId','sameOldActionObjectRetained']}
assert len(facts)==2
(R/'BASELINE-QUEUE-FACTS.json').write_text(json.dumps({'base_blobs_verified':len(manifest),'facts':facts,'source':str(A),'scope':'fresh own baseline repeat; original valid-origin action preserved through real mutation/resume; known red'},indent=2));print(json.dumps(facts,indent=2))
