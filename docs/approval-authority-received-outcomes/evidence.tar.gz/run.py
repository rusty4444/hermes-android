import collections,hashlib,json,os,pathlib,subprocess,sys,time
R=pathlib.Path(__file__).parent;A=R/'app';W=pathlib.Path((R/'workspace.txt').read_text())
env=dict(os.environ,HOME=str(R/'home'),PUB_CACHE=str(R/'pub-cache'),TMPDIR='/Volumes/Storage/Hermes/scratch',FLUTTER_SUPPRESS_ANALYTICS='true',JAVA_HOME='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home',ANDROID_HOME='/Users/sam.russell/Library/Android/sdk',ANDROID_SDK_ROOT='/Users/sam.russell/Library/Android/sdk')
name=sys.argv[1];args=sys.argv[2:]
if args==['accepted']:args=['/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*json.loads((R/'accepted-files.json').read_text())]
start=time.monotonic()
with (R/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
suites={};tests={};ends={};errors=[];done=None
for l in (R/(name+'.log')).read_text().splitlines():
 try:e=json.loads(l)
 except ValueError:continue
 if e.get('type')=='suite':suites[e['suite']['id']]=e['suite']['path']
 if e.get('type')=='testStart':tests[e['test']['id']]=e['test']
 if e.get('type')=='testDone':ends[e['testID']]=e
 if e.get('type')=='error':errors.append(e)
 if e.get('type')=='done':done=e
cases=[{'path':suites.get(t['suiteID']),'name':t['name'],**ends[i]} for i,t in tests.items() if i in ends and not ends[i].get('hidden') and not t['name'].startswith('loading ')]
receipt={'name':name,'args':args,'exit':p.returncode,'seconds':round(time.monotonic()-start,2),'done':done,'count':len(cases),'results':dict(collections.Counter(c['result'] for c in cases)),'skips':sum(bool(c.get('skipped')) for c in cases),'errors':errors,'cases':cases,'sourceHashes':{str(x.relative_to(A)):hashlib.sha256(x.read_bytes()).hexdigest() for d in ['lib','test'] for x in (A/d).rglob('*.dart')}}
(R/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k not in ['errors','cases','sourceHashes']}));print('errors',len(errors));sys.exit(p.returncode)
