import difflib,gzip,hashlib,json,pathlib,plistlib,shutil,subprocess,tarfile
R=pathlib.Path(__file__).parent;W=pathlib.Path((R/'workspace.txt').read_text());D=W/'docs/approval-authority-received-outcomes'
assert plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
D.mkdir(parents=True,exist_ok=True)
original=json.loads((R/'source-before.json').read_text());blob_entries=[]
for raw in subprocess.check_output(['git','ls-tree','-rz','78e3d11b64095d08266ca15882a1468793c73910'],cwd=W).split(b'\0'):
 if not raw:continue
 meta,path=raw.split(b'\t',1);mode,kind,oid=meta.decode().split();p=path.decode()
 if p not in original:continue
 assert p!='android/key.properties'
 data=(W/p).read_bytes();after_oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 blob_entries.append({'path':p,'git_base_blob':oid,'sha256_before':original[p],'git_after_blob':after_oid,'sha256_after':hashlib.sha256(data).hexdigest()})
assert len(blob_entries)==len(original)==590
(R/'GIT-BLOBS.json').write_text(json.dumps(blob_entries,indent=2))
changed=[e['path'] for e in blob_entries if e['git_base_blob']!=e['git_after_blob']]
new=sorted(p for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','lib','test'],cwd=W,text=True).splitlines() if (W/p).is_file())
for label,files in [('production',sorted(p for p in changed+new if p.startswith('lib/'))),('tracked-test-api',sorted(p for p in changed if p.startswith('test/')))]:
 chunks=[]
 for p in files:
  old=subprocess.check_output(['git','show','78e3d11b64095d08266ca15882a1468793c73910:'+p],cwd=W,text=True) if p in original else ''
  chunks.extend(difflib.unified_diff(old.splitlines(True),(W/p).read_text().splitlines(True),fromfile='base/'+p,tofile='candidate/'+p))
 (R/(label+'.diff')).write_text(''.join(chunks))
raw=R/'raw-inputs/independent_root_public_78_spec_test.dart'
(R/'root-extended.diff').write_text(''.join(difflib.unified_diff(raw.read_text().splitlines(True),(W/'test/notification_approval_authority_root_test.dart').read_text().splitlines(True),fromfile='raw/root8.dart',tofile='candidate/root23.dart')))
stock=R/'raw-inputs/independent_core78_stock_received_status_test.dart'
(R/'export-strengthening.diff').write_text(''.join(difflib.unified_diff(stock.read_text().splitlines(True),(W/'test/received_scope_outcome_export_test.dart').read_text().splitlines(True),fromfile='raw/stock-status.dart',tofile='candidate/export-strengthening.dart')))
inputs={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [W/q for q in changed+new]}
(R/'CANDIDATE-INPUT-HASHES.json').write_text(json.dumps(inputs,indent=2))
receipt=json.loads((R/'FINAL-RECEIPT.json').read_text());assert receipt['final']['unique']==2511 and receipt['final']['additional_case_identities']==68
receipt['git_blob_audit']={'entries':len(blob_entries),'intentionally_changed_base_blobs':len(changed),'manifest':'GIT-BLOBS.json inside evidence.tar.gz'}
receipt['artifact_root']=str(D);receipt['working_evidence_root']=str(R)
(D/'verification.json').write_text(json.dumps(receipt,indent=2));shutil.copy2(R/'case-ids.json.gz',D/'case-ids.json.gz')
with tarfile.open(D/'evidence.tar.gz','w:gz') as t:
 for p in sorted(R.iterdir()):
  if p.is_file() and p.suffix in ['.json','.jsonl','.log','.py','.md','.diff','.gz','.txt']:t.add(p,arcname=p.name)
 for sub,arc in [(R/'raw-inputs','raw-inputs'),(R/'app/review-evidence','final-review-evidence'),(R/'baseline-repeat/app/review-evidence','baseline-review-evidence'),(R/'stage2-source-proof','stage2-source-proof')]:
  t.add(sub,arcname=arc)
 for p in new:t.add(W/p,arcname='candidate-inputs/'+p)
 for p in [R/'app/test/independent_root78_valid_origin_test.dart',R/'app/.dart_tool/package_config.json',R/'app/.dart_tool/package_graph.json',R/'app/.flutter-plugins-dependencies']:t.add(p,arcname='owned-harness/'+str(p.relative_to(R/'app')))
 for p in [pathlib.Path('/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/CORE-SPEC-REPORT.md'),pathlib.Path('/Volumes/Storage/Hermes/scratch/root-public-78-spec-cg5vi5jt/ROOT-PUBLIC-SPEC.md'),pathlib.Path('/Volumes/Storage/Hermes/scratch/android-approval-authority-received-outcomes-contract.md')]:t.add(p,arcname='input-reports/'+p.name)
# Verify durable archive inputs and distinct baseline/final evidence, not just tar creation.
with tarfile.open(D/'evidence.tar.gz','r:gz') as t:
 assert t.extractfile('raw-inputs/independent_core78_stock_received_status_test.dart').read()==stock.read_bytes()
 assert t.extractfile('raw-inputs/independent_root_public_78_spec_test.dart').read()==raw.read_bytes()
 assert json.load(t.extractfile('baseline-review-evidence/independent-ROOT78-stale-action-profile.json'))['sameOldActionObjectRetained'] is True
 assert json.load(t.extractfile('final-review-evidence/independent-ROOT78-stale-action-profile.json'))['sameOldActionObjectRetained'] is False
 assert len(json.load(t.extractfile('complete-final-3-receipt.json'))['cases'])==2511
hashes={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.is_file() and p.name!='ARTIFACT-HASHES.json'}
(D/'ARTIFACT-HASHES.json').write_text(json.dumps(hashes,indent=2))
assert not subprocess.check_output(['git','diff','--check'],cwd=W,text=True)
print(json.dumps({'artifact_root':str(D),'final':receipt['final'],'archive':hashes['evidence.tar.gz'],'original_git_blobs':len(blob_entries),'changed_base_blobs':len(changed)},indent=2))
