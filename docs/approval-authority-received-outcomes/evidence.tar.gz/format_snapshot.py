import hashlib,json,pathlib,shutil,subprocess,sys
R=pathlib.Path(__file__).parent;W=pathlib.Path((R/'workspace.txt').read_text());A=R/'app'
fs=sorted(set(subprocess.check_output(['git','diff','--name-only','--','*.dart'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.dart'],cwd=W,text=True).splitlines()))
(R/'format-files.json').write_text(json.dumps(fs,indent=2))
subprocess.run([sys.executable,str(R/'sync.py')],check=True)
subprocess.run([sys.executable,str(R/'run.py'),'format-final-3','/opt/homebrew/bin/dart','format',*fs],check=True)
for f in fs:shutil.copy2(A/f,W/f)
subprocess.run([sys.executable,str(R/'run.py'),'gen-l10n-final-3','/opt/homebrew/bin/flutter','gen-l10n'],check=True)
for p in (A/'lib/l10n').glob('*.dart'):assert p.read_bytes()==(W/p.relative_to(A)).read_bytes(),str(p)
for src,name in [(A,'final-app-before'),(W,'final-worktree-before')]:
 files={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['lib','test'] for p in (src/d).rglob('*') if p.is_file()}
 (R/(name+'.json')).write_text(json.dumps(files,indent=2))
print('Formatted owned scope, regenerated L10N unchanged, captured final source.')
