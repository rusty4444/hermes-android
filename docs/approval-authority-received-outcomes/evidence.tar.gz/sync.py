import pathlib,shutil,subprocess
R=pathlib.Path(__file__).parent;A=R/'app';W=pathlib.Path((R/'workspace.txt').read_text())
for d in ['lib','test']:
 for p in (W/d).rglob('*'):
  if p.is_file():
   target=A/p.relative_to(W);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
(A/'review-evidence').mkdir(exist_ok=True)
print('Synchronized owned source/tests only; borrowed paths untouched.')
