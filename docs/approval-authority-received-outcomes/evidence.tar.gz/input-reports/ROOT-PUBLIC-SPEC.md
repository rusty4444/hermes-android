# Independent ROOT + PUBLIC-UI SPEC — REQUEST_CHANGES

## Frozen target and scope

- Target: `78e3d11b64095d08266ca15882a1468793c73910`.
- Exact parents: `dfa65072439e79edf744be213defc91f30293f9b` and `81d10e7fbdc0ddd499d77a104d05f1d61b70808d`.
- Independent private Git archive: `/Volumes/Storage/Hermes/scratch/root-public-78-spec-cg5vi5jt/app`; immutable input tar: `exact-source.tar` beside this report.
- Scope: real application startup/resume/tap/teardown, account/proof/ordinary entry consumers, background/notification ownership, compact task details, per-visit reasoning/tools, and retained-route C/R/paging/alias/modal contracts. CORE/WAL/reducer internals are not independently approved by this report.
- No production changes or fixes. No new QUALITY decision. Published identity remains `2.1.32+2175`, unreleased integration; no build, signing, install, server, credential, device, provider, TUI, push, tag, PR, or release action.

## Blocking finding ROOT-1 — P1: queued notification actions lose account fencing

**Production locations**

- `lib/main.dart:724–735, 765–779`: the root captures a saved account while handling an approval action, but the pending handoff stores only connection ID, session ID, request ID and choice.
- `lib/core/services/turn_notification_service.dart:905–917, 928–938`: `PendingNotificationApproval` and its dedup key contain no captured configuration/account/profile fingerprint or revocable owner token.
- `lib/main.dart:483–498`: resume prunes obsolete route authority and replaces the application session, without revoking the already-queued action.
- `lib/core/screens/chat_screen.dart:4027–4058`: a later route selects these queued actions using only saved connection ID plus session ID, and passes the old choice/request ID to its current session.

**Deterministic reproduction on the actual root**

1. Mount real `HermesApp`, Home/Workspace and ChatScreen navigation with the real application controller and ConnectionManager; only credentials/native notification channels are fixture boundaries, with real loopback HTTP/WS.
2. Deliver an ordinary native `approve` action for the configured account, `sessionId=stored`, `requestId=approval-reused`. The root cannot currently answer it and queues the intent. Confirm its old account ID and `choice=once` before mutation.
3. Pause; perform the real saved-list transaction under the same saved ID: either `updateApiKey`, or `updateConnection(... gatewayProfile: replacement-profile)`.
4. Resume. Confirm that `MobilePushService.binding` changed, the root replaced the old NormalGateway application session, and the new session is ready.
5. Observe that the exact old `PendingNotificationApproval` object is still globally queued. Both account variants fail the revocation assertion. Teardown still unmounts the real root and clears owned notifications/keepalive.

This violates the binding requirement that account/configuration replacement revoke obsolete intents. The later consumer cannot distinguish the old action from a replacement account's action with the same IDs. A peer request ID is not global account authority. This is a ROOT consumer gap present in exact78; it is not caused by the compact-card or reasoning-default overlay, and historical scoped component approval does not establish this missing fence.

**Precisely demonstrated:** stale queued-action retention through production root entry, real account mutation and resume, despite confirmed owner replacement. **Not claimed:** an executed wrong-account approval RPC, real native notification delivery, or a physical/provider exploit. The potential later same-ID consumption is supported by the actual consumer code above, not misreported as a wire execution.

Fresh case IDs:

- `ROOT78-STALE-ACTION queued approval loses authority on same-ID credential replacement`
- `ROOT78-STALE-ACTION queued approval loses authority on same-ID profile replacement`

Evidence: `stale-action-spec.log`, `stale-action-repeat.log`, `fresh-eight-final.log`, and `combined-with-action-probes.log`; each associated `*-receipt.json` retains process exit, reporter terminal status, exact case identities/errors/skips/loaders. Both failures repeat alone, in the fresh cohort, and in the combined suite. They are `TestFailure: Expected empty / Actual [PendingNotificationApproval]`, not loader, timer, output-directory, or obsolete-oracle failures. Facts are in `app/review-evidence/independent-ROOT78-stale-action-{credential,profile}.json` (`bindingChanged`, `oldOwnerReplaced`, `sameSavedId`, and `sameOldActionObjectRetained` are true).

## Executed evidence, with overlaps kept separate

| Gate | Actual result |
|---|---|
| All prior Root/public schedules | 59/59 pass, process0, terminal success, zero errors/skips/loaders |
| New independently authored schedules | 8 unique: 6 pass; the 2 ROOT-1 assertions fail |
| Final tracked + accepted independent + new probes | 2,451 unique; 2,449 pass; only the two ROOT-1 assertions fail; Flutter exit1, terminal `success=false`, zero skips/loaders |
| All original tracked cases inside that final run | 2,336 pass |
| Prior accepted independent identities inside that run | 107 pass |
| Exact cross-scope push-proof cases, isolated | 2/2 pass unchanged; also pass in Root59 and full runs |
| Exact peer compact-task file | All 11 cases pass; file and both peer task production files are byte-identical to81d |
| Main81d reasoning-visit cohort | All 16 cases pass |
| Fatal analysis, all `lib` and `test` including action probes | Pass, zero issues |
| Formatting / diff checks | Affected99 Dart-file check plus the owned probe; final probe check and Git diff check pass |

These are overlapping gates, not additive totals. All2,451 final identities were freshly executed here. Eight test identities were authored here; the other2,443 are reused test sources freshly rerun, not reused execution results. Parent91 and producer receipts were provenance/preflight inputs, not independent execution credit. Native36/server126 remain historical reuse only. The accepted cleanup13 executes within the independent set; it is not26 unique cases with raw13.

The initial owned full run had20 evidence-directory failures because `app/review-evidence/` had not yet been created. Its raw output is preserved in `full-accepted.log`; the byte-unchanged Root59 rerun and subsequent complete run passed after that owned directory prerequisite was corrected. The earlier six-probe broad control passed2,449/2,449 before the two new action schedules exposed ROOT-1. Do not mistake either broad green for the final verdict.

## Prior59 oracle audit — explicit policy layers

`ORACLE-AUDIT-59.json` inventories every executed suite/name and verifies original/adapted hashes and exact third-layer diffs against the frozen evidence.

- Five files /46 cases are literal byte-unchanged.
- Thirteen schedules are in the two explicitly named `_main81d_policy_test.dart` files, not thirteen unchanged schedules/files. Eight Root schedules supersede only true-disposal reasoning retention; all prior same-State/controller/key/pin/draft/120-scroll assertions remain. In the five-case public file, only the two reverse-alias schedules switch global merged reasoning values to independent visit tokens; the other three cases remain unchanged. Thus ten schedules contain the authorized policy change, not59.
- First public-tool API/default layer, second C/R layer (15 tracked /4 independent copies), and third main81d layer remain separately archived. No adverse barriers, UUID/floor/no-replay/no-synthetic, owner, draft, inner-key or scroll controls were removed.
- The preserved Root8 evidence writer still emits the legacy descriptive field `reasoningStillOpen: true`; do not use that field as post-disposal evidence. The actual adapted post-disposal controller assertion is `isFalse`, and the exact one-assertion policy diff and executable case are the authority. That historical writer was not silently edited here.
- R = retained safety; S = only the explicitly superseded cross-source/default/global-retention premise; A = same-schedule API/selectors/lazy reveal; H = the separately preserved cleanup-only raw13 adaptation.
- The92-entry raw provenance manifest matches. The supplied second-layer assertion ledger has2,073 R /49 S /25 A entries; this is a provenance audit, not a new claim that all historical raw sources load.
- Raw four removed-API loader outcomes and raw13's historical12-pass/post-assert-timer result were read as historical evidence, not relabelled fresh passes. Cleanup13 is separately named and not double-counted.

## Public/lifecycle contracts exercised successfully

The six new passing cases use the actual root and real retained routes, not a helper-only projection:

- Four400/1000-width ordinary/proof entry schedules retain the same ChatScreen State/Route, composer controller, draft and non-collapsed selection, reasoning/tool inner keys and manual pins across alias convergence, a covering route and the same GET-only task modal/controller.
- Exact120→120 parent scroll is asserted and recorded in all four new combined schedules. Real older-page flow is controlled with held Futures: the active settlement advances physical coverage from50 to52; a later accepted physical Refresh fences a held older page; its completion cannot advance the cursor; a retry requests52 again. The actual delegate then renders the complete paged saved window (all60 context rows plus saved current prompt/reply), then local received prompt/reply, with one auxiliary task card. Repeated final text appears twice across C/R, once within each source, as required.
- Task goals render one ellipsised line with bounded actual row height; full goal/model and full live-preview text remain in the existing scrollable read-only viewer. Equal detail/livePreview is not duplicated. Sparse completion continues through the same viewer after parent hydration. Child requests are GET-only and include compacted history; no child resume/create/send is added.
- Same-State cover preserves actual card controllers; lazy remount preserves manual choices; real State disposal/reopen resets both detail kinds without losing received bodies/draft or resubmitting. Peer tests additionally cover2x text, running/completed status and phone/wide modal layouts.
- Two held permission schedules cover old-denied/new-granted and old-granted/new-revoked. Actual root resume demands a fresh trailing plugin read, without a repeated prompt, while retaining the mounted reasoning card/key/manual choice. Ongoing entries obey the resulting permission and clean on settlement.

Source review traced startup `main.dart:31–127`, root lifecycle/policy/notification reconciliation `357–610`, ordinary/proof origin and alias-aware routing `284–311,693–1042`, root teardown `1083–1120`, application configuration ownership, notification demand epochs/durable owned IDs, ChatScreen snapshot/history/deferred/older consumers, per-visit registry binding, actual source-qualified lazy cell builders, export/current-owned voice/unread consumers, task cards and the modal controller.

Same-State config-replacement tests using optional widget/client/session seams are qualified embedder fixtures, not proof that stock navigation mutates an account in place. Ordinary auto-voice's optional `speakResponse` fixture proves consumer selection only; ordinary Send defaults false, and no physical TTS action is claimed. Real loopback traffic and mocked native/plugin contracts are not physical OS/distributor permission or FGS/process-death proof.

## Cross-scope proof-error classification

The two named errors from CORE process `proc_43b4ed3c1022` were independently read, without modifying its files. Both expose `PathNotFoundException` for `review-evidence/fresh-authority-fresh-revised-proof-{true,false}.json`, surfaced by its cleanup `expect(tester.takeException(), isNull)` at line427. They are evidence-output prerequisite failures, not authority assertion failures, timer errors or reasoning-oracle changes. Exact raw selected events, original file SHA and origin path are preserved in `CORE-PROOF-RAW-READONLY.json`; own unchanged executions are in `root59.log` and `proof-two-isolated.log`. This classification covers those two sampled schedules only, not all other CORE results.

## Isolation, source and cache verification

`SOURCE-CACHE-AFTER.json` verifies all590 Git blobs, including137 library blobs, before/after execution; both integration repositories remain clean at exact78 with the exact parents. Storage UUID was verified as `F7E08904-541C-463A-8BD5-284D3C146333` before archive creation and at the final audit.

`UNCHANGED-AUTHORITY-PEER.json` verifies `connection_manager.dart`, all41 Android files and all26 server files byte-unchanged fromdfa. The peer compact test and both task presentation files match81d exactly. No repeated unrelated provider/server review or native execution is implied.

All7,416 required borrowed dependency Dart hashes and nanosecond mtimes match. The wider owned audit also checks9,554 dependency-plus-SDK Dart files, with zero hash/mtime differences. Both package_config and package_graph and plugin metadata were copied; the main package is `../` in this archive and borrowed relative URIs were resolved against their original config origin. HOME and PUB_CACHE are owned siblings outside the app. No pub get/install/upgrade or warning suppression was used. Flutter commands were serial within this archive, maximum two workers.

Only owned review artifacts/probes/copies/tool metadata were created under this scratch root. Producer, integration, parent and CORE sources/caches were not edited. The default-profile Android review checklist received two reusable review lessons (evidence-directory prerequisites and queued-action account fencing); no application fix was made.

## Main artifacts

- Report: `ROOT-PUBLIC-SPEC.md` (this file).
- Machine receipt: `REVIEW-RECEIPT.json`.
- Final probe: `app/test/independent_root_public_78_spec_test.dart`, SHA-256 `faad50efdb6caaebf5fc83bc85ae185e76340e2ce2c58d85839482945d19cac4`.
- Original passing six-case probe used by the earlier complete control: `combined-strong-six-probe.dart.harness` and `combined-strong-probe-hash.json`.
- Oracle/assertion and source/cache audits: `ORACLE-AUDIT-59.json`, `PROVENANCE-AUDIT.json`, `SOURCE-CACHE-AFTER.json`, `UNCHANGED-AUTHORITY-PEER.json`.
- Final command/raw results: `combined-with-action-probes{.log,-receipt.json}`, `fresh-eight-final{.log,-receipt.json}`, `stale-action-repeat{.log,-receipt.json}`, `analysis-with-action-probes{.log,-receipt.json}`.

**Verdict: REQUEST_CHANGES for the independent ROOT + PUBLIC-UI SPEC scope because of ROOT-1.** The compact/task, per-visit presentation and retained-route controls passing here do not waive the queued-action account-authority failure or approve the whole candidate/release.
