# Independent combined CORE SPEC — REQUEST_CHANGES

## Immutable target and scope

- Commit: `78e3d11b64095d08266ca15882a1468793c73910`.
- Exact parents: `dfa65072439e79edf744be213defc91f30293f9b` and `81d10e7fbdc0ddd499d77a104d05f1d61b70808d`.
- Own Git archive: `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/app`.
- Review: combined canonical/received presentation, physical request-start freshness, turn/receipt/draft/alias ownership, rendered consumers, child inspection, compact task and actual-visit reasoning overlay. This is SPEC, not QUALITY or release/deployment approval. No production implementation was changed.

## Blocking finding

### P2 / CORE78-STATUS — retained received scopes lose an already-proven failed outcome

A first turn produces received partial prose and is **authoritatively known to have failed**. After a later successful turn, its prompt and received body remain in R, but its known failure no longer exists in the retained scope or rendered presentation. Both bodies have only the same generic persistence-provenance badge. The latest owner now has `phase=completed`, `error=null`; neither the retained rows nor their timeline imports carry the first scope's outcome. A temporarily displayed failure snackbar is not retained scope status.

This is not the permitted repetition of C and R, and is not a demand to infer that an unmatched reply is unsaved. It violates the binding requirement to retain received scopes with their **known status**. Persistence correspondence and lifecycle outcome are different facts.

Relevant frozen source:

- `lib/core/services/normal_gateway_application_session.dart:937–945`: next reservation replaces the phase and clears the sole `_error`/`_status`.
- `.../normal_gateway_application_session.dart:1008–1027`: prior received rows survive, but no prior-scope outcome is carried alongside them.
- `.../normal_gateway_application_session.dart:1711–1746`: settlement records outcome only on the current owner; rows receive only `_gateway_pending_response=false`.
- `.../normal_gateway_application_session.dart:2025–2035`: imported settled presentation retains rows/tools/timeline/observation, not outcome.
- `lib/core/screens/chat_screen.dart:772–790`: failure is shown transiently in a snackbar.
- `.../chat_screen.dart:5430–5449`: received cells render local-context or generic match-unconfirmed labels, with no retained lifecycle status. Export at1392–1416 likewise contains the bodies and provenance but no outcome.

#### Deterministic production-call-path reproduction

The isolated stock-shaped probe uses real loopback HTTP/WebSocket, the production `DesktopGatewayClient`, application owner, Send gesture, `ChatScreen`, export, and actual State/scroll/composer controllers. No private owner mutation or widened send callback is used.

1. Load stored canonical context with durable ID1.
2. Send `First local prompt` once; receive `Repeated received body`.
3. Receive ID-less stock-shaped `message.complete` with `status:error`, `error:Deterministic first-turn failure`, `partial:true`. A subsequent **physical session.resume** returns `running:false` and `inflight.status:error` / the retained error. Assert the owner is failed, its error is known, and more than one resume has occurred. Thus this is not merely a transport interruption or an ID-less terminal pretending to prove its own ownership.
4. Let the existing snackbar expire. Send `Second local prompt` once and complete successfully with the identical body.
5. Assert complete C, both distinct received scopes once within R, exactly two wire prompts, same mounted State/scroll/composer controllers, source-labelled export and no framework exception. These controls pass.
6. Inspect the whole built transcript at400 and1000 widths. Both R bodies remain, but there is no retained indication that the first is a known failed partial. The only current outcome is completed/error-null. The known-status assertions fail.

A separate supported identified-terminal fixture reproduces the same loss; that control is explicitly distinct from the stock ID-less-completion/resume path.

This is an ordinary sequential production route path, not a widened owner-API scheduling counterexample. The server is a controlled stock-shaped fixture, not a live gateway/provider. The ID-less error completion and recoverable inflight shape were cross-checked read-only against `tui_gateway/session_auto_continue.py:550–585` in `/Volumes/Storage/Hermes/workspace/hermes-agent-session-replay-adoption`; no server test or deployment is claimed.

#### Copy/oracle qualification

The diagnostic matcher searches the English fixture's built text for `failed|failure|interrupted`. Those are **not required product strings**, nor is preservation of the raw backend error text required. A valid localized label, accessible outcome indicator, or neutral scope-associated status such as an appropriately qualified incomplete/ended-with-error indication can satisfy the contract. The finding is supported independently by the source's missing per-scope outcome, the recorded initial proven failure, and the final complete rendered-text/row observation—not solely by absence of those three English words. There is currently no alternative outcome indicator in the observed presentation. Do not label a mere local interruption or unknown outcome as a definite backend failure; the stock probe deliberately establishes actual failure through the later authoritative resume.

#### Executed minimal repro

Working directory:
`/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/app`

```sh
python3 ../run_gate.py reproduce-stock-status /opt/homebrew/bin/flutter test --no-pub --concurrency=2 --reporter=json test/independent_core78_stock_received_status_test.dart --plain-name 'CORE78-STOCK known-status'
```

Actual: process exit1,2 unique cases,0 passes,2 status assertion errors,0 skips, reporter `done.success=false`. Both cases reach the terminal-status assertion after their canonical/received/identity/wire controls.

- Probe: `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/app/test/independent_core78_stock_received_status_test.dart`
- Probe SHA-256: `34559a54b663021611933edd6d7345a8e1d5968c4b09899d9695a107938012c8`
- Raw output: `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/reproduce-stock-status.jsonl`
- Parsed command/outcomes: same directory, `reproduce-stock-status-summary.json`.

## Fresh execution and error classification

Counts below overlap; do not add cohorts or repeated runs.

| Gate | Actual result |
|---|---|
| Complete accepted combined source/copy inventory |2443 unique passes, exit0, terminal success,0 errors/skips |
| Tracked tests within that same run |2336 unique passes; every tracked test compiles/runs |
| Retained cohort within combined |425 passes (421 original schedules plus4 peer additions) |
| Physical freshness B cohort within combined |38 passes; original B36 bytes unchanged |
| C/R policy cohort within combined |26 passes |
| Root/public within combined |59 passes:46 literal schedules +13 in two explicit main81d-policy copies |
| New independent production-seam probes |20 unique,16 pass,4 status assertion errors,0 skips, exit1 / terminal false |
| Minimal stock status repro |2 failing cases above, overlapping the new20 |
| Final fatal `flutter analyze --no-pub --fatal-infos lib test` |exit0, no issues, includes all three new probes |
| Raw four removed-API originals |4 loader failures /7 error events,0 semantic cases; exit1 / terminal false |
| Raw13 original |12 passes +1 known post-assert pending-timer failure, exit1 / terminal false |
| Existing cleanup13 |13 passes inside accepted run; same13 content schedules, NOT26 unique cases |

The new passing schedules include12 actual Refresh interleavings: a retained failed received scope plus a held older physical GET, a newer exact request-start-token physical observation with empty/lower-ID/unidentified rows, then obsolete success or503. At both400/1000, the latest owner observation remains authoritative, loaded canonical context stays usable, R scope IDs stay unchanged, no stale body/error/loader is published, actual State/scroll identity survives, and exactly one prompt remains on the wire. Four additional canonical/control cases (identified and stock completion/resume at both widths) pass before the known-status check.

### Initial failures preserved, not treated as product red

The first combined run selected the **correct** two main81d copies; it was not using the obsolete raw reasoning oracle. It returned2443 unique /2405 passes /38 errors, exit1 / terminal false:

-37 schedules report `PathNotFoundException` for missing scratch `review-evidence/` output files. This includes both `FRESH separate push proofs same target own generations latestValid=true/false` cases. Actual errors are preserved, not guessed from names.
-1 `FRESH inner pagination authority replacement fence=pause` case reports a fixture-condition timeout rather than a semantic expected/actual mismatch. Its precise initial root cause is not independently proven. It passes unchanged in the complete rerun.

Created only the missing scratch output directory; changed no accepted test or assertion. The subsequent whole2443 run passes, including the exact38 prior failed schedules. See `full-combined.jsonl`, `first-full-errors.json`, and `FIRST-RUN-CLASSIFICATIONS.json`.

Reviewer-code preflights are separate: the first new status fixture needed normal snackbar entrance/exit pumping before the second hit-tested Send; its initial missed-tap/condition errors are retained. Analyzer initially flagged an `avoid_print`, then three brace infos in the new probes, then one brace info in the added stock fixture. Fixed only reviewer logging/brace style, with no suppression or production edits; preserved `initial-*`, `second-*`, and `third-preflight-*` analysis receipts. Final fatal analysis is green. These preflight exits are not product findings.

Raw13 again reaches its existing assertions and then fails Flutter's pending-timer invariant (HTTP idle / WsClient heartbeat); this is not a fresh semantic finding or permission for a production timer workaround. Four raw removed-history-API probes are genuine compile incompatibilities, not assertions passed.

## Oracle provenance audit

- Independently verified all92 raw-archive manifest entries and26 policy-archive entries.
- Reapplied every supplied second-layer unified diff against the preserved exact raw original and checked the resulting declared SHA. This covers15 tracked changes plus four separately named policy copies. Unchanged safety sources were byte-checked too.
- Reapplied all11 third-layer test diffs against frozen dfa/independent parents and checked final executable bytes. The two task production files and compact task test are byte-identical to81d.
- Original B36 SHA: `af693c27acfad4ad3a403c515b527a029698c634ffe57a479bae7bc8ce88a201`, unchanged fromdfa.
- Fresh2443 suite/path/name inventory exactly equals committed `docs/main-81d-integration/case-ids.json.gz`. The prior2412→2443 migration has15 peer additions and16 adapter additions, with the three explicitly documented peer case renames; no unexplained missing case.
- Root59 selection is five byte-identical files /46 schedules and TWO `_main81d_policy_test.dart` files /13 schedules. Those13 are retained schedules, not claimed byte-unchanged old global/cross-disposal reasoning assertions.
- Reviewed deleted assertion lines and exact R/S/A/H diffs against the binding C/R and newer reasoning overlay. No wire/floor/WAL/identity/actual-State/controller/draft/120-scroll/no-replay safety assertion was intentionally relaxed in this review. One third-layer ledger hunk (`chat_display_items_test.dart` initiallyExpanded true→false) is locally tagged A although semantically S; the exact diff and approved PR174 default change are disclosed, so this is classification imprecision, not hidden oracle weakening or a separate blocking product defect.

Detailed machine audit: `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/PROVENANCE-AUDIT.json`.

## Inspected combined authorities and consumers

Traced owner C latest versus route loaded/paged window; physical offset-zero tokens and non-promoting older fences; synchronous fan-out/microtask rechecks; obsolete error/deferred/loader/scroll cleanup and REST send-latch finally. Traced separate C/R projector inputs, canonical-only tool extraction, source-qualified lazy keys/index lookup, inner reasoning/tool identity, source headings/badges/lifetime, loading/error gates, export, current received unread/voice selection, parent/child updates and GET-only viewer/controller. Traced reserve/pre-wire baseline/WAL/terminal/pre-ACK recovery paths, root/alias convergence, shared bounded received timeline/imports/tombstones, composer handles/physical queue/reload/rollback/clear-marker authority, bounded per-visit preferences, compact tasks and genuine reasoning-visit resets. Regression coverage is fresh in the complete run; no claim that green tests establish untested device/provider behavior.

No second blocking contract failure was reproduced in that coverage. This does not independently approve the source or cancel the status finding.

## Integrity and boundaries

Before/after tooling, all590 tracked Git blobs (137 underlib) matched the immutable commit in the private app and both supplied integration worktrees; both repositories remain clean at the exact target/parents. Borrowed dependencies are read-only: all7416 supplied third-party Dart hash/mtime entries match, and the broader9554 Dart package-root audit (including SDK packages) also has zero hash/mtime changes. Owned HOME/PUB_CACHE are siblings of the app; relocated package config, graph and plugin metadata point main code to this archive. Flutter operations were serial, max2 test workers. Storage UUID was verified before scratch writes.

All new source is reviewer probes under scratch. Full receipt and case IDs:

- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/CORE-SPEC-RECEIPT.json`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/fresh-case-ids.json`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/source-before.json` and `source-after.json`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/cache-before.json` and `cache-after.json`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/accepted-combined.jsonl`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/independent-new-final.jsonl`
- `/Volumes/Storage/Hermes/scratch/core-spec-78e3d11-8iyamegv/analysis-final.jsonl`

Historical native36/server126 results are not fresh evidence here. No APK build/sign/install, device/Keystore/provider/real voice/network-provider validation, live app/server/config/default/fallback/Vault/credential/other-profile/TUI change, push/tag/PR/release or QUALITY was performed. Published version remains2.1.32+2175; this report grants no candidate/deployment acceptance.
