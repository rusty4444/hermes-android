import json,pathlib,subprocess,sys
R=pathlib.Path(__file__).parent;W=pathlib.Path((R/'workspace.txt').read_text())
base=json.loads((R/'accepted-files.json').read_text())
new=[p for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','test'],cwd=W,text=True).splitlines() if p.endswith('_test.dart')]
files=sorted(set(base+new));(R/'final-files.json').write_text(json.dumps(files,indent=2))
print('Test files:',len(files),'New test files:',len(new),flush=True)
run_name = sys.argv[1] if len(sys.argv) > 1 else 'complete-final'
sys.exit(subprocess.run([sys.executable,str(R/'run.py'),run_name,'/opt/homebrew/bin/flutter','test','--no-pub','--concurrency=2','--reporter=json',*files]).returncode)
