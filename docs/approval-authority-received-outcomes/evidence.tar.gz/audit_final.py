import collections,difflib,gzip,hashlib,json,pathlib,plistlib,subprocess
R=pathlib.Path(__file__).parent;W=pathlib.Path((R/'workspace.txt').read_text());A=R/'app'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
volume=plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))
assert volume['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
base='78e3d11b64095d08266ca15882a1468793c73910'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==base
original=json.loads((R/'source-before.json').read_text())
changed=sorted(p for p,h in original.items() if sha(W/p)!=h)
allowed=set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines())
assert set(changed)<=allowed
protected=[p for p in original if p.startswith(('android/','server/','docs/unreconciled-output/','docs/main-81d-integration/','docs/reviews/')) or p in ['pubspec.yaml','pubspec.lock','README.md','CHANGELOG.md']]
assert not set(changed).intersection(protected)
source_proof={}
for src,name in [(W,'final-worktree'),(A,'final-app')]:
 before=json.loads((R/(name+'-before.json')).read_text())
 after={str(p.relative_to(src)):sha(p) for d in ['lib','test'] for p in (src/d).rglob('*') if p.is_file()}
 bad=[p for p,h in before.items() if after.get(p)!=h]
 assert not bad,(name,bad)
 (R/(name+'-after.json')).write_text(json.dumps(after,indent=2))
 source_proof[name]={'files':len(before),'mismatches':bad}
cache=json.loads((R/'cache-before.json').read_text());cache_after={};bad=[]
for p,prior in cache.items():
 path=pathlib.Path(p);now={'sha256':sha(path),'mtime_ns':path.stat().st_mtime_ns};cache_after[p]=now
 if now!=prior:bad.append(p)
assert not bad,bad
(R/'cache-after.json').write_text(json.dumps(cache_after,indent=2))
raw=json.loads((R/'raw-inputs.json').read_text());rawproof={}
for name,h in raw.items():
 assert sha(R/'raw-inputs'/name)==h
 if name.startswith('independent_core78'):
  assert sha(W/'test'/name)==h
 assert sha(A/'test'/name)==h
 rawproof[name]=h
rawroot=R/'raw-inputs/independent_root_public_78_spec_test.dart';adapt=A/'test/independent_root78_valid_origin_test.dart'
(R/'root-valid-origin.diff').write_text(''.join(difflib.unified_diff(rawroot.read_text().splitlines(True),adapt.read_text().splitlines(True),fromfile='raw/independent_root_public_78_spec_test.dart',tofile='adapted/independent_root78_valid_origin_test.dart')))
assert adapt.read_text()==rawroot.read_text().replace("'requestId': 'approval-reused',", "'requestId': 'approval-reused',\n                'approvalAccount': MobilePushService.binding(oldConnection),\n                'approvalMutation': '00000000-0000-4000-8000-000000000000:initial',")
final=json.loads((R/'complete-final-3-receipt.json').read_text())
assert final['exit']==0 and final['done']['success'] and not final['errors'] and not final['skips']
cases=[{'path':c['path'].split('/app/',1)[1],'name':c['name'],'result':c['result'],'skipped':bool(c.get('skipped'))} for c in final['cases']]
keys=lambda cs:{(c['path'],c['name']) for c in cs}
assert len(keys(cases))==len(cases)==final['count']
prior=json.loads(gzip.decompress((W/'docs/main-81d-integration/case-ids.json.gz').read_bytes()))
assert keys(prior)<=keys(cases)
new_cases=[c for c in cases if (c['path'],c['name']) not in keys(prior)]
tracked_paths=set(subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=W,text=True).splitlines())
owned_paths=tracked_paths|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines())
tracked_final=[c for c in cases if c['path'] in owned_paths]
cohorts={}
for name,cohort in json.loads((R/'CORE-SPEC-RECEIPT.json').read_text())['overlapping_cohorts_do_not_sum'].items():
 selected=[c for c in cases if c['path'] in cohort['files']]
 assert len(selected)==cohort['count'],(name,len(selected))
 cohorts[name]={'count':len(selected),'all_success':all(c['result']=='success' for c in selected),'files':cohort['files']}
for name,paths in {'peer-compact11':['test/compact_delegated_task_card_test.dart'],'reasoning-visit16':['test/reasoning_visit_main81d_test.dart'],'cleanup13':['test/independent_spec_116_cleanup_77413_test.dart'],'CORE-original20':[f'test/{n}' for n in raw if n.startswith('independent_core78')]}.items():
 selected=[c for c in cases if c['path'] in paths];cohorts[name]={'count':len(selected),'all_success':all(c['result']=='success' for c in selected),'files':paths}
steps=[]
for p in sorted(R.glob('*-receipt.json')):
 d=json.loads(p.read_text())
 if 'args' in d:steps.append({'name':d['name'],'exit':d['exit'],'count':d['count'],'results':d['results'],'skips':d['skips'],'error_events':len(d['errors']),'loader_errors':sum('Failed to load' in e.get('error','') for e in d['errors']),'terminal':d['done'],'receipt':p.name})
wire=json.loads((A/'review-evidence/independent-AUTHORITY-wire.json').read_text())
assert wire['replacementResponsesBeforeFreshAction']==0 and wire['replacementResponsesAfterFreshAction']==1 and wire['replacementChoice']=={'choice':'deny'} and wire['oldOwnerReplaced']
metadata={p:sha(A/p) for p in ['.dart_tool/package_config.json','.dart_tool/package_graph.json','.flutter-plugins-dependencies']}
config=json.loads((A/'.dart_tool/package_config.json').read_text());assert next(p for p in config['packages'] if p['name']=='hermes_android')['rootUri']=='../'
receipt={'status':'implementation execution evidence only; parent independent SPEC then QUALITY still required','base':base,'parents':subprocess.check_output(['git','show','-s','--format=%P','HEAD'],cwd=W,text=True).strip().split(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=W,text=True).strip(),'volume_uuid':volume['VolumeUUID'],'version_unchanged':sha(W/'pubspec.yaml')==original['pubspec.yaml'],'verified_base_blobs':len(original),'intentionally_changed_base_paths':changed,'protected_base_paths_unchanged':len(protected),'source_proof':source_proof,'cache':{'all_dart':len(cache),'third_party_dart':sum('pub-cache' in p for p in cache),'hash_mtime_mismatches':bad},'raw_probe_sha256':rawproof,'minimal_valid_origin_sha256':sha(adapt),'final':{'unique':len(cases),'tracked_including_new':len(tracked_final),'accepted_independent':len(cases)-len(tracked_final),'retained_base_unique':len(prior),'additional_case_identities':len(new_cases),'exit':final['exit'],'terminal':final['done'],'errors':len(final['errors']),'skips':final['skips']},'overlapping_cohorts_do_not_sum':cohorts,'new_case_counts_by_file':dict(collections.Counter(c['path'] for c in new_cases)),'steps':steps,'metadata_sha256':metadata,'controlled_wire':{k:wire[k] for k in ['replacementResponsesBeforeFreshAction','replacementResponsesAfterFreshAction','replacementChoice','oldOwnerReplaced']},'no_native_server_execution_or_deployment':True}
(R/'FINAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2))
(R/'case-ids.json.gz').write_bytes(gzip.compress(json.dumps(cases,indent=2).encode(),mtime=0));(R/'additional-case-ids.json').write_text(json.dumps(new_cases,indent=2))
print(json.dumps({k:receipt[k] for k in ['final','cache','new_case_counts_by_file','controlled_wire','source_proof']},indent=2))
