import collections, gzip, hashlib, json, os, plistlib, shutil, subprocess, tarfile
from pathlib import Path
R=Path(__file__).parent
A=R/'app'
W=Path('/Volumes/Storage/Hermes/workspace/hermes-android-mutation-observer-isolation')
REV='37f52c1b84a1e7a1ca93c8e573e8e79badd030fc'
D=W/'docs/mutation-observer-isolation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
keys=lambda cs:{(c['path'],c['name']) for c in cs}
volume=plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))
assert volume['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==REV
manifest=json.loads((R/'SOURCE-BEFORE.json').read_text())
changed='lib/core/services/connection_mutation_barrier.dart'
new=['test/connection_mutation_barrier_test.dart','test/connection_mutation_observer_root_test.dart','test/connection_mutation_observer_transaction_test.dart','test/support/mutation_observer_root_fixture.dart']
source={}
for label,root in [('app',A),('worktree',W)]:
    after={p:sha(root/p) for p in manifest}
    differences=[p for p in manifest if after[p]!=manifest[p]]
    assert differences==[changed],differences
    for p in [changed,*new]: assert (A/p).read_bytes()==(W/p).read_bytes(),p
    source[label]={'base_blobs':len(manifest),'lib_blobs':sum(p.startswith('lib/') for p in manifest),'changed_base_paths':differences,'unexpected_changes':[],'hashes':after,'new_tests':{p:sha(root/p) for p in new}}
(R/'SOURCE-AFTER.json').write_text(json.dumps(source,indent=2))
cache_before=json.loads((R/'CACHE-BEFORE.json').read_text())
cache_after={p:{'sha256':sha(Path(p)),'mtime_ns':Path(p).stat().st_mtime_ns} for p in cache_before}
bad=[p for p in cache_before if cache_before[p]!=cache_after[p]]
assert not bad,bad
(R/'CACHE-AFTER.json').write_text(json.dumps(cache_after,indent=2))
full=json.loads((R/'full-final-exact-receipt.json').read_text())
cases=full['cases']
assert full['exit']==0 and full['done']['success'] and not full['errors'] and full['loader_errors']==full['skips']==0
assert len(keys(cases))==len(cases) and all(c['result']=='success' for c in cases)
expected=json.loads((R/'EXPECTED-CASES.json').read_text())
assert len(expected)==2511 and keys(expected)<=keys(cases)
prior=json.loads(gzip.decompress((W/'docs/main-81d-integration/case-ids.json.gz').read_bytes()))
assert len(prior)==2443 and keys(prior)<=keys(cases)
accepted_sources=json.loads((R/'ACCEPTED-SOURCES.json').read_text())
for entry in accepted_sources: assert sha(A/entry['path'])==entry['sha256']
tracked=set(manifest)
assert sum(c['path'] in tracked for c in expected)==2404
v=json.loads((W/'docs/approval-authority-received-outcomes/verification.json').read_text())
cohorts={}
for name,cohort in v['overlapping_cohorts_do_not_sum'].items():
    selected=[c for c in cases if c['path'] in cohort['files']]
    assert len(selected)==cohort['count'] and all(c['result']=='success' for c in selected)
    cohorts[name]={'count':len(selected),'all_success':True,'files':cohort['files']}
probe='test/independent37_root_adverse_test.dart'
assert sha(A/probe)==sha(R/'ORIGINAL-ROOT37.dart.harness')=='c288e37bbff0d28d370a10c101d8e64d1610e6defd6953d31dc36d5f5e4061cb'
assert sha(A/'test/independent_core37_lifetime_test.dart')=='6f79288605ad8f5f6ea0173f268e4e049050bc2fde0ac18a8f449761dd92e730'
assert sha(A/'test/independent_root78_valid_origin_test.dart')=='7a9f6d0bb930282ed2e1bb324dc647562ff318fd08633f0ec32062ace459cca6'
red=json.loads((R/'base37-raw-seven-receipt.json').read_text())
assert red['results']=={'error':2,'success':5} and red['exit']==1 and red['skips']==red['loader_errors']==0
assert all(c['result']=='success' for c in cases if c['path']==probe)
new_cases=[c for c in cases if c['path'] in new]
assert len(new_cases)==8
base_new=json.loads((R/'base37-permanent-final-bytes-receipt.json').read_text())
assert base_new['results']=={'error':8} and keys(base_new['cases'])==keys(new_cases)
for label,expected_pending,expected_reset in [('base37-raw-seven',True,False),('full-final-exact',False,True)]:
    folder=R/(label+'-widget-evidence')
    leak=json.loads((folder/'independent37-root-listener-leak.json').read_text())
    reset=json.loads((folder/'independent37-root-reset-recovery.json').read_text())
    assert leak['unrelatedQueuedObjectSurvives'] and leak['successorPhysicallyCommitted']
    assert leak['pendingAfterFault']==leak['pendingAfterSuccessor']==expected_pending
    assert leak['successorCurrent']!=expected_pending and reset['resetClearedCorruption']==expected_reset
    if expected_pending:
        assert 'HermesAppState._pruneApprovalActions' in leak['faultStack'] and 'ConnectionMutationBarrier.begin' in leak['faultStack']
    else:
        assert 'ConnectionMutationManager' not in leak['faultStack']
        assert 'ConnectionManager._loadConnectionsWithSecrets' in leak['faultStack']
        assert 'ConnectionMutationBarrier.begin' not in leak['faultStack']
steps=[]
for p in sorted(R.glob('*-receipt.json')):
    d=json.loads(p.read_text())
    if 'name' not in d:continue
    steps.append({k:d.get(k) for k in ['name','args','exit','seconds','count','unique','results','skips','loader_errors','done']}|{'error_events':len(d.get('errors',[])),'receipt':str(p)})
assert json.loads((R/'format-exact-receipt.json').read_text())['exit']==0
assert json.loads((R/'fatal-analysis-exact-receipt.json').read_text())['exit']==0
assert 'No issues found!' in (R/'fatal-analysis-exact.log').read_text()
focus=json.loads((R/'focused-final-receipt.json').read_text())
assert focus['exit']==0 and focus['done']['success'] and not focus['errors']
metadata={p:sha(A/p) for p in ['.dart_tool/package_config.json','.dart_tool/package_graph.json','.flutter-plugins-dependencies']}
config=json.loads((A/'.dart_tool/package_config.json').read_text())
assert next(p for p in config['packages'] if p['name']=='hermes_android')['rootUri']=='../'
assert all(p['name']=='hermes_android' or p['rootUri'].startswith('file:///') for p in config['packages'])
production_diff=subprocess.check_output(['git','diff','--',changed],cwd=W,text=True)
(R/'PRODUCTION.diff').write_text(production_diff)
receipt={'status':'Implementation execution evidence only; no SPEC/QUALITY/deployment approval','scope':'ROOT37-1/P2 observer delivery boundary only','base':REV,'base_parent':'78e3d11b64095d08266ca15882a1468793c73910','branch':subprocess.check_output(['git','branch','--show-current'],cwd=W,text=True).strip(),'volume_uuid':volume['VolumeUUID'],'version_unchanged':True,'production_changed_paths':[changed],'production_diff':production_diff,'observer_policy':'Synchronous per-listener catch of all thrown objects at this optional observer boundary; continue snapshot delivery and return exact caller-owned lease. No logging/telemetry/raw exception formatting (zero diagnostic bytes/state), no async rethrow or global error handler. Epoch loop and refcounts/releases unchanged. Actual manager storage/native failures still propagate through existing sanitized transaction/finally paths.','source':{k:{q:e for q,e in d.items() if q!='hashes'} for k,d in source.items()},'base_archive':{'path':str(R/'exact37-source.tar.gz'),'sha256':sha(R/'exact37-source.tar.gz')},'raw_probe':{'path':str(R/'ORIGINAL-ROOT37.dart.harness'),'sha256':sha(R/'ORIGINAL-ROOT37.dart.harness'),'adaptations':[],'base':{k:red[k] for k in ['count','results','exit','skips','loader_errors','done']},'fixed':[c for c in cases if c['path']==probe]},'new_permanent_cases':new_cases,'new_base_result':{k:base_new[k] for k in ['count','results','exit','skips','loader_errors','done']},'final':{k:full[k] for k in ['count','unique','results','exit','skips','loader_errors','done']},'accepted':{'unique':len(expected),'all_pass':True,'tracked':2404,'accepted_independent':107,'prior_retained':len(prior)},'focused':{k:focus[k] for k in ['count','unique','results','exit','skips','loader_errors','done']},'overlapping_cohorts_do_not_sum':cohorts,'cache':{'third_party_dart':sum('pub-cache' in p for p in cache_before),'dependency_sdk_dart':len(cache_before),'hash_mtime_mismatches':bad},'package_metadata':metadata,'steps':steps,'setup_qualifications':['Native channels and credentials are fixtures; real HermesApp/root/default session factories, ConnectionManager and loopback HTTP/WS are exercised. No native/device/provider/server or process-death acceptance.','Exact unmodified reviewer Root7 requires review-evidence directory, created by owned harness before execution. No A/H adapter applied to that source. Permanent root tests write no evidence files.','Permanent root helper narrows the reused fixture to no-turn/queued-B schedules. Retains startup/quick-chat/real default owner, actual malformed saved key, exact queued object, pause, successor/reset and root-owned teardown. Inherited 21-second widget-only recovery timeout drain; no production timeout changes.','One newly authored test initially counted four observer deliveries after a fresh physical export; export correctly adds an empty-ID list lease. It now asserts four before export and five after; no pre-existing oracle changed.','Initial owned-helper fatal analysis reported unnecessary import and private public-field type; corrected only test helper with no suppression. A later no-write format check identified unit-test formatting; corrected and reran exact full suite and fatal analysis. No loader/setup failures.','Raw4 removed-API loaders, raw13 timer case, raw unscoped Root8 six-pass/two-admission-fail and original native36/server126 remain historic qualifications, not freshly rerun unchanged-green credit. Minimal valid-origin Root8 and cleanup13 are freshly green as their existing explicit adapters, not raw originals.'],'evidence_root':str(R),'no_build_sign_install_push_release_or_quality':True}
D.mkdir()
(D/'verification.json').write_text(json.dumps(receipt,indent=2))
(D/'case-ids.json.gz').write_bytes(gzip.compress(json.dumps(cases,indent=2).encode(),mtime=0))
(R/'FINAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2))
# Preserve all commands, raw errors and actual result artifacts, plus replay sources.
with tarfile.open(D/'evidence.tar.gz','w:gz') as t:
    for p in sorted(R.iterdir()):
        if p.is_file() and (p.suffix in ('.log','.json','.py','.diff','.harness') or p.name=='ORIGINAL-ROOT37.dart.harness'):
            t.add(p,arcname=p.name,recursive=False)
    for name in ['base37-raw-seven','base37-permanent-final-bytes','full-final-exact','focused-final']:
        t.add(R/(name+'-widget-evidence'),arcname=name+'-widget-evidence')
    for p in new: t.add(W/p,arcname='permanent/'+p+'.harness')
    for p in [probe,'test/independent_core37_lifetime_test.dart','test/independent_root78_valid_origin_test.dart']:
        t.add(A/p,arcname='reused/'+p+'.harness')
    for entry in accepted_sources:
        p=entry['path'];t.add(A/p,arcname='accepted-independent/'+p+'.harness')
print(json.dumps({'evidence_root':str(R),'doc_root':str(D),'full':receipt['final'],'focus':receipt['focused'],'accepted':receipt['accepted'],'new_permanent':len(new_cases),'cohorts':{n:d['count'] for n,d in cohorts.items()},'cache':receipt['cache'],'source_changed':source['worktree']['changed_base_paths'],'evidence_bytes':(D/'evidence.tar.gz').stat().st_size},indent=2))
