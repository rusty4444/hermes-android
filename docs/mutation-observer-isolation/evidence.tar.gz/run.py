import collections, json, os, subprocess, sys, time, shutil
from pathlib import Path
R=Path(__file__).parent
A=R/'app'
env=dict(os.environ,**json.loads((R/'env.json').read_text()))
name=sys.argv[1]
args=sys.argv[2:]
if args[0] in ('flutter','dart'): args[0]='/opt/homebrew/bin/'+args[0]
start=time.monotonic()
with (R/(name+'.log')).open('w') as f:
    p=subprocess.run(args,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
started={}; finished={}; suites={}; errors=[]; done=None
for line in (R/(name+'.log')).read_text().splitlines():
    try: e=json.loads(line)
    except ValueError: continue
    t=e.get('type')
    if t=='suite': suites[e['suite']['id']]=e['suite']['path']
    elif t=='testStart': started[e['test']['id']]=e['test']
    elif t=='testDone' and not e.get('hidden'): finished[e['testID']]=e
    elif t=='error': errors.append(e)
    elif t=='done': done=e
cases=[{'path':suites[started[i]['suiteID']].replace(str(A)+'/', ''),'name':started[i]['name'],'result':e['result'],'skipped':bool(e.get('skipped'))} for i,e in finished.items() if not started[i]['name'].startswith('loading ')]
receipt={'name':name,'args':args,'exit':p.returncode,'seconds':round(time.monotonic()-start,2),'count':len(cases),'unique':len(set((c['path'],c['name']) for c in cases)),'results':dict(collections.Counter(c['result'] for c in cases)),'skips':sum(c['skipped'] for c in cases),'errors':errors,'loader_errors':sum(started.get(i,{}).get('name','').startswith('loading ') and e['result']=='error' for i,e in finished.items()),'done':done,'cases':cases}
(R/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
if (A/'review-evidence').exists(): shutil.copytree(A/'review-evidence',R/(name+'-widget-evidence'),dirs_exist_ok=True)
print(json.dumps({k:v for k,v in receipt.items() if k not in ('cases','errors')},indent=2))
if errors: print(json.dumps(errors,indent=2)[:18000])
sys.exit(p.returncode)
