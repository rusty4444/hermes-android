// Fresh schedules; prior independent authority fixture, paged server extension.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/connection_keepalive_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/gateway_turn_journal.dart';
import 'package:hermes_android/core/services/mobile_push_service.dart';
import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'support/memory_turn_journal_store.dart';

// Independent multi-session server: no producer/spec navigation fixture imports.
class _Wire {
  _Wire(this.http);
  final HttpServer http;
  final sockets = <WebSocket>[];
  final requests = <String>[];
  final rpc = <Map<String, dynamic>>[];
  final prompts = <String, List<Map<String, dynamic>>>{};
  final running = <String>{};
  final history = <String, List<Map<String, dynamic>>>{};
  final createEntered = Completer<void>();
  void Function()? releaseCreate;
  bool closed = false;
  Completer<void>? listGate;
  final listEntered = Completer<void>();
  final pages = <_HeldPage>[];
  final ownedPages = <_HeldPage>[];
  _HeldPage holdPage(Map<String, dynamic> payload) {
    final p = _HeldPage(payload);
    pages.add(p);
    ownedPages.add(p);
    return p;
  }

  int listReplies = 0;
  List<Map<String, dynamic>> feed = [];

  static Future<_Wire> start() async {
    final wire = _Wire(await HttpServer.bind(InternetAddress.loopbackIPv4, 0));
    wire.http.listen(wire.handle);
    return wire;
  }

  Map<String, dynamic> session(String id) => {
    'id': id,
    'title': 'Quality $id',
    'model': 'fixture',
    'source': 'mobile',
    'message_count': history[id]?.length ?? 0,
    'started_at': 1,
  };

  Future<void> handle(HttpRequest request) async {
    requests.add(request.uri.toString());
    if (request.uri.path == '/api/plugins/mobile-push/events') {
      request.response.headers.contentType = ContentType.json;
      request.response.write(
        jsonEncode({'events': feed, 'has_more': false, 'next_cursor': '1'}),
      );
      await request.response.close();
      return;
    }
    if (request.uri.path.startsWith('/api/sessions')) {
      expectSync(request.headers.value('authorization'), 'Bearer quality-key');
      request.response.headers.contentType = ContentType.json;
      if (request.uri.path == '/api/sessions') {
        if (pages.isEmpty) {
          throw StateError('Unplanned physical session page ${request.uri}');
        }
        final page = pages.removeAt(0);
        page.entered.complete();
        await page.released.future;
        listReplies++;
        request.response.write(jsonEncode(page.payload));
      } else if (request.uri.path.endsWith('/messages')) {
        final id = request.uri.pathSegments[2];
        if (id != 'shared' && id != 'other') {
          request.response.statusCode = 404;
        }
        request.response.write(jsonEncode({'data': history[id] ?? []}));
      } else {
        request.response.statusCode = 404;
      }
      await request.response.close();
      return;
    }
    if (request.uri.path == '/api/auth/ws-ticket') {
      request.response.headers.contentType = ContentType.json;
      request.response.write('{"ticket":"quality"}');
      await request.response.close();
      return;
    }
    if (request.uri.path != '/api/ws') {
      request.response.statusCode = 404;
      await request.response.close();
      return;
    }
    final socket = await WebSocketTransformer.upgrade(request);
    sockets.add(socket);
    socket.add(
      jsonEncode({
        'jsonrpc': '2.0',
        'method': 'event',
        'params': {'type': 'gateway.ready', 'payload': {}},
      }),
    );
    socket.listen((raw) {
      if (closed) return;
      final frame = Map<String, dynamic>.from(jsonDecode(raw as String) as Map);
      rpc.add(frame);
      final method = frame['method'];
      if (method == null) return;
      final params = Map<String, dynamic>.from(frame['params'] as Map? ?? {});
      final reply = <String, dynamic>{'jsonrpc': '2.0', 'id': frame['id']};
      if (method == 'session.resume') {
        final id = params['session_id'] as String?;
        if (id != 'shared' && id != 'other') {
          reply['error'] = {'code': 4007, 'message': 'session not found'};
        } else {
          reply['result'] = {
            'session_id': 'runtime-$id',
            'stored_session_id': id,
            'running': running.contains(id),
            'status': running.contains(id) ? 'running' : 'idle',
          };
        }
      } else if (method == 'session.create') {
        expectSync(params.containsKey('session_id'), isFalse);
        reply['result'] = {
          'session_id': 'runtime-shared',
          'stored_session_id': 'shared',
          'message_count': 0,
          'messages': [],
        };
        final encoded = jsonEncode(reply);
        releaseCreate = () {
          if (socket.readyState == WebSocket.open) socket.add(encoded);
        };
        if (!createEntered.isCompleted) createEntered.complete();
        return;
      } else {
        if (method == 'prompt.submit') {
          final id = (params['session_id'] as String).replaceFirst(
            'runtime-',
            '',
          );
          prompts.putIfAbsent(id, () => []).add(params);
          running.add(id);
        }
        reply['result'] = {'ok': true};
      }
      if (socket.readyState == WebSocket.open) socket.add(jsonEncode(reply));
    });
  }

  void finish(String id) {
    expect(running.remove(id), isTrue);
    final turn = 'quality-$id-${prompts[id]!.length}';
    final rows = history.putIfAbsent(id, () => []);
    rows.addAll([
      {
        'id': rows.length + 1,
        'role': 'user',
        'content': prompts[id]!.last['text'],
      },
      {'id': rows.length + 2, 'role': 'assistant', 'content': 'Result $id'},
    ]);
    for (final entry in [
      ('message.start', <String, dynamic>{}),
      ('message.complete', <String, dynamic>{'text': 'Result $id'}),
      ('turn.end', <String, dynamic>{}),
    ]) {
      // Scope by runtime and multicast over open owned sockets, not sockets.last.
      for (final socket in sockets.where(
        (s) => s.readyState == WebSocket.open,
      )) {
        socket.add(
          jsonEncode({
            'jsonrpc': '2.0',
            'method': 'event',
            'params': {
              'type': entry.$1,
              'session_id': 'runtime-$id',
              'turn_id': turn,
              'payload': entry.$2,
            },
          }),
        );
      }
    }
  }

  Future<void> close() async {
    if (closed) return;
    closed = true;
    releaseCreate?.call();
    for (final socket in sockets) {
      await socket.close();
    }
    await http.close(force: true);
  }
}

class _Secrets implements CredentialStore {
  final entries = <String, String>{};
  @override
  String? readCached(String key) => entries[key];
  @override
  Future<String?> read(String key) async => entries[key];
  @override
  Future<void> write(String key, String value) async => entries[key] = value;
  @override
  Future<void> delete(String key) async => entries.remove(key);
}

const _plugin = MethodChannel('dexterous.com/flutter/local_notifications');
const _tts = MethodChannel('flutter_tts');
const _picker = MethodChannel('plugins.flutter.io/image_picker');

Future<void> _until(WidgetTester tester, bool Function() predicate) async {
  for (var n = 0; n < 400; n++) {
    await tester.pump();
    if (predicate()) return;
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 5)),
    );
  }
  fail('Independent root condition did not arrive');
}

Future<void> _animate(WidgetTester tester) async {
  await tester.pump();
  await tester.pump(const Duration(seconds: 1));
  for (var i = 0; i < 15; i++) {
    await tester.pump();
    await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  }
}

void _lifecycle(WidgetTester tester, bool paused) {
  if (paused) {
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  } else {
    if (tester.binding.lifecycleState == AppLifecycleState.paused) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
  }
}

const _native = MethodChannel('test/quality-independent-push');

class _Root {
  _Root() : push = MobilePushService(supported: true, channel: _native);
  final native = <String, dynamic>{'enabled': false};
  final nativeCalls = <String>[];
  final wires = <_Wire>[];
  final accounts = <SavedConnection>[];
  final commands = <MethodCall>[];
  final keepalive = <String>[];
  final live = <int, Map<String, dynamic>>{};
  final controller = GatewayTurnApplicationController(
    journalFactory: () => GatewayTurnJournal(store: MemoryTurnJournalStore()),
  );
  final MobilePushService push;
  late ConnectionManager manager;
  bool nativeRunning = false;
  String? recordedSchedule;

  Future<void> mount(WidgetTester tester, {int count = 1}) async {
    _lifecycle(tester, false);
    manager = ConnectionManager(
      await SharedPreferences.getInstance(),
      credentialStore: _Secrets(),
    );
    for (var i = 0; i < count; i++) {
      final wire = (await tester.runAsync(_Wire.start))!;
      wires.add(wire);
      await manager.saveConnection(
        'Quality $i',
        '127.0.0.1',
        wire.http.port,
        'quality-key',
        dashboardPort: wire.http.port,
        dashboardProxied: true,
        gatewayProfile: 'profile-$i',
      );
    }
    accounts.addAll(
      wires.map(
        (wire) => manager.getConnections().singleWhere(
          (c) => c.port == wire.http.port,
        ),
      ),
    );
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(_native, (call) async {
      nativeCalls.add(call.method);
      if (call.method == 'preferences') {
        native.addAll(Map<String, dynamic>.from(call.arguments as Map));
      }
      if (call.method == 'takeTap') return native.remove('tap');
      if (call.method == 'disable') {
        native['enabled'] = false;
        native['active'] = false;
        native.remove('tap');
      }
      return Map<String, dynamic>.from(native);
    });
    messenger.setMockMethodCallHandler(_tts, (_) async => 1);
    messenger.setMockMethodCallHandler(_picker, (_) async => null);
    messenger.setMockMethodCallHandler(_plugin, (call) async {
      commands.add(call);
      if (call.method == 'show') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live[args['id'] as int] = args;
      } else if (call.method == 'cancel') {
        live.remove((call.arguments as Map)['id']);
      }
      return call.method == 'getNotificationAppLaunchDetails' ? null : true;
    });
    messenger.setMockMethodCallHandler(ConnectionKeepAliveService.channel, (
      call,
    ) async {
      keepalive.add(call.method);
      if (call.method == 'start') nativeRunning = true;
      if (call.method == 'stop') nativeRunning = false;
      return true;
    });
    await tester.pumpWidget(
      HermesApp(
        connManager: manager,
        turnApplicationController: controller,
        mobilePush: push,
      ),
    );
    await _animate(tester);
    expect(find.byType(ChatScreen, skipOffstage: false), findsNothing);
  }

  void tap(String id, {int account = 0}) => notificationResponseHandler!(
    NotificationResponse(
      payload: jsonEncode({
        'connectionId': accounts[account].id,
        'sessionId': id,
      }),
      notificationResponseType: NotificationResponseType.selectedNotification,
    ),
  );

  Future<State> open(WidgetTester tester, String id, {int account = 0}) async {
    tap(id, account: account);
    await _until(
      tester,
      () => find.byType(ChatScreen, skipOffstage: false).evaluate().any((e) {
        final screen = e.widget as ChatScreen;
        return screen.session.id == id &&
            screen.connection.id == accounts[account].id &&
            ModalRoute.of(e)!.isCurrent;
      }),
    );
    await _animate(tester);
    return tester.state(find.byType(ChatScreen));
  }

  Iterable<Map<String, dynamic>> get ongoing => live.values.where(
    (n) => (n['platformSpecifics'] as Map?)?['ongoing'] == true,
  );
  Iterable<Map> get terminals => commands
      .where((c) => c.method == 'show')
      .map((c) => c.arguments as Map)
      .where(
        (n) =>
            n['title'] == 'Hermes response ready' ||
            n['title'] == 'Hermes turn failed',
      );

  Future<void> send(
    WidgetTester tester,
    String text,
    String id, {
    int account = 0,
  }) async {
    await tester.enterText(find.byType(TextField), text);
    await tester.tap(find.byTooltip('Send'));
    await _until(tester, () => wires[account].prompts[id]?.isNotEmpty ?? false);
  }

  Future<void> close(WidgetTester tester) async {
    _lifecycle(tester, false);
    await tester.pumpWidget(const SizedBox());
    await _animate(tester);
    await controller.close();
    for (final wire in wires) {
      await tester.runAsync(wire.close);
    }
    await tester.pump(const Duration(seconds: 16));
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    expect(find.byType(HermesApp), findsNothing);
    expect(nativeRunning, isFalse);
    expect(ongoing, isEmpty);
    expect(
      prefs.getStringList(TurnNotificationService.ongoingIdsStorageKey) ?? [],
      isEmpty,
    );
    expect(commands.where((c) => c.method == 'cancelAll'), isEmpty);
    expect(tester.takeException(), isNull);
    if (recordedSchedule != null) {
      await tester.runAsync(
        () =>
            File(
              'review-evidence/fresh-authority-cleanup-$recordedSchedule.json',
            ).writeAsString(
              jsonEncode({
                'rootUnmounted': find.byType(HermesApp).evaluate().isEmpty,
                'nativeRunning': nativeRunning,
                'ongoingCount': ongoing.length,
                'durableOngoingIds':
                    prefs.getStringList(
                      TurnNotificationService.ongoingIdsStorageKey,
                    ) ??
                    [],
                'cancelAllCount': commands
                    .where((c) => c.method == 'cancelAll')
                    .length,
              }),
            ),
      );
    }
    push.dispose();
    final messenger = tester.binding.defaultBinaryMessenger;
    for (final channel in [
      _plugin,
      _native,
      _tts,
      _picker,
      ConnectionKeepAliveService.channel,
    ]) {
      messenger.setMockMethodCallHandler(channel, null);
    }
    debugDefaultTargetPlatformOverride = null;
  }

  Future<void> record(
    WidgetTester tester,
    String name,
    Map<String, dynamic> facts,
  ) async {
    recordedSchedule = name;
    await tester.runAsync(
      () => File('review-evidence/fresh-authority-$name.json').writeAsString(
        jsonEncode({
          'schedule': name,
          'nativeCommands': nativeCalls,
          ...facts,
          'mountedIds': tester
              .widgetList<ChatScreen>(
                find.byType(ChatScreen, skipOffstage: false),
              )
              .map((s) => '${s.connection.id}:${s.session.id}')
              .toList(),
          'rpc': wires.map((w) => w.rpc).toList(),
          'requests': wires.map((w) => w.requests).toList(),
          'keepalive': keepalive,
          'commands': commands
              .map((c) => {'method': c.method, 'arguments': c.arguments})
              .toList(),
        }),
      ),
    );
  }
}

class _HeldPage {
  _HeldPage(this.payload);
  final Map<String, dynamic> payload;
  final entered = Completer<void>();
  final released = Completer<void>();
  void complete() {
    if (!released.isCompleted) released.complete();
  }
}

Map<String, dynamic> _page(_Wire w, String id, {bool more = false}) => {
  'data': [w.session(id)],
  'has_more': more,
};
Future<void> _push(
  WidgetTester tester,
  _Root f, {
  int revision = 1,
  double? expiry,
}) async {
  final c = f.accounts.single;
  expiry ??= DateTime.now().millisecondsSinceEpoch / 1000 + 3600;
  f.native.addAll({
    'enabled': true,
    'active': true,
    'connection': c.id,
    'binding': MobilePushService.binding(c),
    'installation': 'fresh-installation',
    'nonce': 'fresh-nonce',
    'generation': 7,
    'revision': revision,
    'endpoint': 'https://push.invalid/opaque',
    'sessions': ['shared'],
    'tap': {
      'nonce': 'fresh-nonce',
      'generation': 7,
      'revision': revision,
      'event_id': 'fresh-$revision',
      'expires_at': expiry,
    },
  });
  f.wires.single.feed = [
    {
      'event_id': 'fresh-$revision',
      'session_id': 'shared',
      'kind': 'input',
      'expires_at': expiry,
    },
  ];
  await tester.runAsync(f.push.refresh);
}

void _expectCurrent(WidgetTester tester, String? id) {
  final screens = find.byType(ChatScreen, skipOffstage: false);
  if (id == null) {
    expect(screens, findsNothing);
    return;
  }
  expect(screens, findsOneWidget);
  expect(tester.widget<ChatScreen>(screens).session.id, id);
  expect(ModalRoute.of(tester.state(screens).context)!.isCurrent, isTrue);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });
  for (final action in [
    'valid',
    'revoke',
    'expiry',
    'account',
    'ordinary',
    'pause',
    'ordinary-pause',
  ]) {
    testWidgets('FRESH inner pagination authority replacement fence=$action', (
      tester,
    ) async {
      final f = _Root();
      await f.mount(tester);
      final w = f.wires.single;
      final first = w.holdPage(_page(w, 'older-1', more: true));
      final second = w.holdPage(
        _page(
          w,
          action == 'valid' ? 'shared' : 'older-2',
          more: action != 'valid',
        ),
      );
      _HeldPage? replacement;
      try {
        final expiry = DateTime.now().millisecondsSinceEpoch / 1000 + 1.0;
        await _push(tester, f, expiry: action == 'expiry' ? expiry : null);
        await _until(tester, () => first.entered.isCompleted);
        first.complete();
        await _until(tester, () => second.entered.isCompleted);
        expect(
          w.requests
              .where((p) => Uri.parse(p).path == '/api/sessions')
              .map((p) => Uri.parse(p).queryParameters['offset'] ?? '0'),
          ['0', '1'],
        );
        if (action.startsWith('ordinary')) {
          replacement = w.holdPage(_page(w, 'shared'));
          f.tap('shared');
          await _until(tester, () => replacement!.entered.isCompleted);
          await tester.runAsync(f.push.disable);
        } else if (action == 'revoke') {
          await tester.runAsync(f.push.disable);
        } else if (action == 'account') {
          await f.manager.updateApiKey(
            f.accounts.single.id,
            'fresh-replacement-key',
          );
        } else if (action == 'expiry') {
          await tester.runAsync(() async {
            while (DateTime.now().millisecondsSinceEpoch / 1000 <= expiry) {
              await Future<void>.delayed(const Duration(milliseconds: 10));
            }
          });
        }
        if (action == 'pause' || action == 'ordinary-pause') {
          _lifecycle(tester, true);
        }
        second.complete();
        await _until(tester, () => w.listReplies >= 2);
        await _animate(tester);
        final countWhileOldDrained = w.requests
            .where((p) => Uri.parse(p).path == '/api/sessions')
            .length;
        expect(
          countWhileOldDrained,
          action.startsWith('ordinary') ? 3 : 2,
          reason:
              'older credentials/proof cannot send another page after losing authority',
        );
        if (action.startsWith('ordinary')) {
          for (var i = 0; i < 4; i++) {
            f.tap('shared');
            await tester.pump();
          }
          expect(
            w.requests
                .where((p) => Uri.parse(p).path == '/api/sessions')
                .length,
            3,
          );
          replacement!.complete();
          await _until(tester, () => w.listReplies == 3);
          await _animate(tester);
        }
        if (action == 'pause' || action == 'ordinary-pause') {
          _expectCurrent(tester, null);
          final resumed = w.holdPage(_page(w, 'shared'));
          _lifecycle(tester, false);
          await _until(tester, () => resumed.entered.isCompleted);
          resumed.complete();
          await _until(
            tester,
            () => w.listReplies == (action == 'pause' ? 3 : 4),
          );
          await _animate(tester);
        }
        final shouldOpen = [
          'valid',
          'ordinary',
          'pause',
          'ordinary-pause',
        ].contains(action);
        _expectCurrent(tester, shouldOpen ? 'shared' : null);
        expect(w.prompts, isEmpty);
        expect(pendingNotificationApprovals.value, isEmpty);
        await f.record(tester, 'fresh-pagination-$action', {
          'offsets': w.requests
              .where((p) => Uri.parse(p).path == '/api/sessions')
              .map((p) => Uri.parse(p).queryParameters['offset'] ?? '0')
              .toList(),
          'oldDrainedRequestCount': countWhileOldDrained,
          'listReplies': w.listReplies,
          'newerOrdinaryOpened': action.startsWith('ordinary') && shouldOpen,
          'pushEnabled': f.push.enabled,
        });
      } finally {
        for (final page in w.ownedPages) {
          page.complete();
        }
        await f.close(tester);
      }
    });
  }
  for (final newerValid in [true, false]) {
    testWidgets(
      'FRESH separate push proofs same target own generations latestValid=$newerValid',
      (tester) async {
        final f = _Root();
        await f.mount(tester);
        final w = f.wires.single;
        final one = w.holdPage(_page(w, 'shared'));
        _HeldPage? two;
        try {
          await _push(tester, f, revision: 1);
          await _until(tester, () => one.entered.isCompleted);
          two = w.holdPage(_page(w, 'shared'));
          await _push(tester, f, revision: 2);
          // Root serializes push consumption; a newer pending proof invalidates
          // the old generation immediately, then starts after its worker drains.
          one.complete();
          await _until(tester, () => two!.entered.isCompleted);
          await _until(tester, () => w.listReplies == 1);
          await _animate(tester);
          _expectCurrent(tester, null);
          if (!newerValid) await tester.runAsync(f.push.disable);
          two.complete();
          await _until(tester, () => w.listReplies == 2);
          await _animate(tester);
          _expectCurrent(tester, newerValid ? 'shared' : null);
          expect(
            w.requests.where((p) => Uri.parse(p).path == '/api/sessions'),
            hasLength(2),
          );
          expect(w.prompts, isEmpty);
          await f.record(tester, 'fresh-revised-proof-$newerValid', {
            'listReplies': w.listReplies,
            'nativeRevision': f.native['revision'],
            'latestProofValid': newerValid,
          });
        } finally {
          one.complete();
          two?.complete();
          await f.close(tester);
        }
      },
    );
  }
}
