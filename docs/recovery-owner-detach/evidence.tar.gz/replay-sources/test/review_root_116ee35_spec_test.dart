import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/screens/workspace_screen.dart';
import 'package:hermes_android/core/services/android_launch_intent_service.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/composer_draft_store.dart';
import 'package:hermes_android/core/services/connection_keepalive_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/gateway_turn_journal.dart';
import 'package:hermes_android/core/services/mobile_push_service.dart';

import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/main.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, widgetUntil;
import 'support/memory_turn_journal_store.dart';

class _RootServer extends BindingServer {
  _RootServer(super.server);
  static Future<_RootServer> start() async {
    final owner = _RootServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    owner.server.listen(owner.handle);
    return owner;
  }

  final requests = <String>[];
  Completer<void>? nextSessionListGate;
  Completer<void>? sessionListEntered;
  @override
  Future<void> handle(HttpRequest request) async {
    requests.add(request.uri.toString());
    if (request.uri.path == '/api/sessions') {
      expect(request.headers.value('authorization'), 'Bearer fixture');
      final gate = nextSessionListGate;
      if (gate != null) {
        nextSessionListGate = null;
        sessionListEntered!.complete();
        await gate.future;
      }
      request.response.headers.contentType = ContentType.json;
      request.response.write(
        jsonEncode({
          'data': [
            if (creates > 0)
              {
                'id': 'stored',
                'title': 'Verified canonical',
                'model': 'fixture',
                'source': 'mobile',
                'message_count': rows.length,
                'started_at': 1,
              },
          ],
          'has_more': false,
        }),
      );
      await request.response.close();
      return;
    }
    await super.handle(request);
  }

  // Home/Workspace and recovery discovery may own independent control sockets.
  // Deliver a server session event on each open fixture socket; production
  // client runtime maps, not whichever socket was created last, admit it.
  @override
  void event(String type, Map<String, dynamic> payload, {String? turnId}) {
    for (final socket in sockets) {
      if (socket.readyState != WebSocket.open) continue;
      socket.add(
        jsonEncode({
          'jsonrpc': '2.0',
          'method': 'event',
          'params': {
            'type': type,
            'session_id': 'runtime',
            'turn_id': ?turnId,
            'payload': payload,
          },
        }),
      );
    }
  }

  void failTurn() {
    running = false;
    final id = 'wire-${prompts.length}';
    event('message.start', {}, turnId: id);
    event('turn.error', {'message': 'Fixture terminal failure'}, turnId: id);
  }
}

class _MemoryCredentials implements CredentialStore {
  final values = <String, String>{};
  @override
  String? readCached(String key) => values[key];
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async => values[key] = value;
  @override
  Future<void> delete(String key) async => values.remove(key);
}

class _RootAliasFixture {
  final controller = GatewayTurnApplicationController(
    journalFactory: () => GatewayTurnJournal(store: MemoryTurnJournalStore()),
  );
  final native = <String, dynamic>{'enabled': false};
  final nativeCalls = <MethodCall>[];
  final pluginCalls = <MethodCall>[];
  final live = <int, Map<String, dynamic>>{};
  final keepalive = <String>[];
  final pushRequests = <http.Request>[];
  final channel = const MethodChannel('test/spec-root-alias-push');
  static const plugin = MethodChannel(
    'dexterous.com/flutter/local_notifications',
  );
  final launch = AndroidLaunchIntentService();
  late _RootServer server;
  late ConnectionManager manager;
  late SavedConnection connection;
  late MobilePushService push;
  List<Map<String, dynamic>> feed = [];
  bool nativeRunning = false;
  String? recordedSchedule;
  Completer<Map<String, dynamic>>? snapshotGate;
  Completer<void>? snapshotEntered;
  Completer<void>? eventGate;
  Completer<void>? eventEntered;
  int snapshots = 0;
  Future<void> initialize(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    server = (await tester.runAsync(_RootServer.start))!;
    manager = ConnectionManager(
      await SharedPreferences.getInstance(),
      credentialStore: _MemoryCredentials(),
    );
    await manager.saveConnection(
      'Root loopback',
      '127.0.0.1',
      server.server.port,
      'fixture',
      dashboardPort: server.server.port,
      dashboardProxied: true,
      gatewayProfile: 'root-profile',
    );
    connection = manager.getConnections().single;
    final messenger = tester.binding.defaultBinaryMessenger;
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      (_) async => null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      (_) async => 1,
    );
    messenger.setMockMethodCallHandler(plugin, (call) async {
      pluginCalls.add(call);
      if (call.method == 'show') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live[args['id'] as int] = args;
      } else if (call.method == 'cancel') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live.remove(args['id']);
      }
      return call.method == 'getNotificationAppLaunchDetails' ? null : true;
    });
    messenger.setMockMethodCallHandler(ConnectionKeepAliveService.channel, (
      call,
    ) async {
      keepalive.add(call.method);
      if (call.method == 'start') {
        nativeRunning = true;
      }
      if (call.method == 'stop') nativeRunning = false;
      return true;
    });
    messenger.setMockMethodCallHandler(channel, (call) async {
      nativeCalls.add(call);
      switch (call.method) {
        case 'snapshot':
          snapshots++;
          final gate = snapshotGate;
          if (gate != null) {
            snapshotGate = null;
            snapshotEntered!.complete();
            return gate.future;
          }
          return Map<String, dynamic>.from(native);
        case 'preferences':
          native.addAll(Map<String, dynamic>.from(call.arguments as Map));
          return Map<String, dynamic>.from(native);
        case 'takeTap':
          return native.remove('tap');
        case 'disable':
          native['enabled'] = false;
          native['active'] = false;
          native.remove('tap');
          return Map<String, dynamic>.from(native);
        default:
          throw StateError('Unexpected native command ${call.method}');
      }
    });
    push = MobilePushService(
      supported: true,
      channel: channel,
      clientFactory: (c) => DashboardClient(
        host: c.host,
        port: c.dashboardPort,
        proxied: c.dashboardProxied,
        gatewayProfile: c.gatewayProfile,
        httpClient: MockClient((request) async {
          pushRequests.add(request);
          final gate = eventGate;
          if (gate != null) {
            eventGate = null;
            eventEntered!.complete();
            await gate.future;
          }
          expect(request.method, 'GET');
          expect(request.url.path, '/api/plugins/mobile-push/events');
          expect(request.url.queryParameters['profile'], 'root-profile');
          return http.Response(
            jsonEncode({'events': feed, 'has_more': false, 'next_cursor': '1'}),
            200,
          );
        }),
      ),
    );
    launch.pendingQuickChat.value =
        true; // Fixture-owned launcher input, production Home/Workspace navigation.
    await tester.pumpWidget(
      HermesApp(
        connManager: manager,
        turnApplicationController: controller,
        mobilePush: push,
        launchIntents: launch,
      ),
    );
    await widgetUntil(
      tester,
      () => find.byType(ChatScreen).evaluate().isNotEmpty,
    );
    await widgetUntil(
      tester,
      () => find
          .byKey(const ValueKey('legacy-transport-notice'))
          .evaluate()
          .isNotEmpty,
    );
    await _drain(tester);
    expect(find.byType(HermesApp), findsOneWidget);
    expect(find.byType(WorkspaceScreen, skipOffstage: false), findsOneWidget);
    expect(
      tester
          .widget<WorkspaceScreen>(
            find.byType(WorkspaceScreen, skipOffstage: false),
          )
          .turnApplicationController,
      same(controller),
    );
  }

  Future<void> canonicalTap(
    WidgetTester tester, {
    required bool viaPush,
    int mountedChats = 2,
  }) async {
    if (viaPush) {
      final expiry = DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600;
      native.addAll({
        'enabled': true,
        'active': true,
        'connection': connection.id,
        'binding': MobilePushService.binding(connection),
        'installation': 'root-spec-installation',
        'nonce': 'root-spec-nonce',
        'generation': 7,
        'revision': 1,
        'endpoint': 'https://push.invalid/opaque',
        'sessions': ['stored'],
        'tap': {
          'nonce': 'root-spec-nonce',
          'generation': 7,
          'revision': 1,
          'event_id': 'root-spec-event',
          'expires_at': expiry,
        },
      });
      feed = [
        {
          'event_id': 'root-spec-event',
          'session_id': 'stored',
          'kind': 'input',
          'expires_at': expiry,
        },
      ];
      await tester.runAsync(push.refresh);
    } else {
      tap('stored');
    }
    await widgetUntil(
      tester,
      () =>
          find.byType(ChatScreen, skipOffstage: false).evaluate().length ==
          mountedChats,
    );
    await tester.pump(const Duration(seconds: 1));
    await _drain(tester);
  }

  void tap(String id) {
    notificationResponseHandler!(
      NotificationResponse(
        payload: jsonEncode({'connectionId': connection.id, 'sessionId': id}),
        notificationResponseType: NotificationResponseType.selectedNotification,
      ),
    );
  }

  Iterable<Map<String, dynamic>> get ongoing => live.values.where(
    (n) => (n['platformSpecifics'] as Map?)?['ongoing'] == true,
  );
  Iterable<Map<String, dynamic>> get terminals => pluginCalls
      .where((c) => c.method == 'show')
      .map((c) => Map<String, dynamic>.from(c.arguments as Map))
      .where(
        (n) =>
            (n['title'] == 'Hermes response ready' ||
            n['title'] == 'Hermes turn failed'),
      );
  Future<void> close(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    await _drain(tester);
    await tester.pumpWidget(const SizedBox.shrink());
    await _drain(tester);
    await controller.close();
    await tester.runAsync(server.close);
    await tester.pump(const Duration(seconds: 16));
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    expect(find.byType(HermesApp), findsNothing);
    expect(nativeRunning, isFalse);
    expect(ongoing, isEmpty);
    expect(
      prefs.getStringList(TurnNotificationService.ongoingIdsStorageKey) ??
          <String>[],
      isEmpty,
    );
    expect(pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
    if (recordedSchedule != null) {
      await tester.runAsync(
        () => File('review-evidence/cleanup-$recordedSchedule.json')
            .writeAsString(
              jsonEncode({
                'rootUnmounted': true,
                'nativeRunning': nativeRunning,
                'ongoingCount': ongoing.length,
                'durableOngoingIds': prefs.getStringList(
                  TurnNotificationService.ongoingIdsStorageKey,
                ),
                'keepaliveCommands': keepalive,
              }),
            ),
      );
    }
    push.dispose();
    launch.dispose();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(plugin, null);
    messenger.setMockMethodCallHandler(
      ConnectionKeepAliveService.channel,
      null,
    );
    messenger.setMockMethodCallHandler(channel, null);
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      null,
    );
    debugDefaultTargetPlatformOverride = null;
  }
}

Future<void> _drain(WidgetTester tester) async {
  for (var i = 0; i < 12; i++) {
    await tester.pump();
  }
  await tester.pump(const Duration(milliseconds: 350));
  await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  for (var i = 0; i < 6; i++) {
    await tester.pump();
  }
}

void _lifecycle(WidgetTester tester, AppLifecycleState target) {
  if (tester.binding.lifecycleState == target) return;
  if (target == AppLifecycleState.paused) {
    if (tester.binding.lifecycleState == AppLifecycleState.resumed) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.inactive) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  } else {
    if (tester.binding.lifecycleState == AppLifecycleState.paused) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.hidden) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
  }
}

void _seedPush(_RootAliasFixture f, {int? expiry}) {
  final deadline =
      expiry ?? DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600;
  f.native.addAll({
    'enabled': true,
    'active': true,
    'connection': f.connection.id,
    'binding': MobilePushService.binding(f.connection),
    'installation': 'root-spec-installation',
    'nonce': 'root-spec-nonce',
    'generation': 7,
    'revision': 1,
    'endpoint': 'https://push.invalid/opaque',
    'sessions': ['stored'],
    'tap': {
      'nonce': 'root-spec-nonce',
      'generation': 7,
      'revision': 1,
      'event_id': 'independent-event',
      'expires_at': deadline,
    },
  });
  f.feed = [
    {
      'event_id': 'independent-event',
      'session_id': 'stored',
      'kind': 'input',
      'expires_at': deadline,
    },
  ];
}

Future<String> _startSource(WidgetTester tester, _RootAliasFixture f) async {
  final id = tester.widget<ChatScreen>(find.byType(ChatScreen)).session.id;
  await tester.enterText(find.byType(TextField), 'Independent source request');
  await tester.tap(find.byTooltip('Send'));
  await widgetUntil(tester, () => f.server.createEntered.isCompleted);
  return id;
}

Future<void> _cover(WidgetTester tester, State state) async {
  Navigator.of(state.context).push<void>(
    MaterialPageRoute(
      builder: (_) => const Scaffold(body: Text('Independent retained cover')),
    ),
  );
  await tester.pump();
  await tester.pump(const Duration(seconds: 1));
  await _drain(tester);
  expect(ModalRoute.of(state.context)!.isCurrent, isFalse);
}

Future<void> _profileEdit(_RootAliasFixture f) async {
  final c = f.connection;
  await f.manager.updateConnection(
    c.id,
    c.label,
    c.host,
    c.port,
    c.apiKey,
    dashboardPort: c.dashboardPort,
    dashboardProxied: c.dashboardProxied,
    gatewayProfile: 'different-profile',
  );
  expect(f.manager.getConnections().single.gatewayProfile, 'different-profile');
  expect(
    MobilePushService.binding(f.manager.getConnections().single),
    isNot(MobilePushService.binding(c)),
  );
}

Future<void> _record(
  WidgetTester tester,
  _RootAliasFixture f,
  String name,
  Map<String, dynamic> facts,
) async {
  f.recordedSchedule = name;
  final data = {
    'schedule': name,
    ...facts,
    'keepalive': f.keepalive,
    'native': f.nativeCalls
        .map((c) => {'method': c.method, 'arguments': c.arguments})
        .toList(),
    'plugin': f.pluginCalls
        .map((c) => {'method': c.method, 'arguments': c.arguments})
        .toList(),
    'pushURLs': f.pushRequests.map((r) => r.url.toString()).toList(),
    'httpPaths': f.server.requests,
    'wirePrompts': f.server.prompts,
    'mountedIds': tester
        .widgetList<ChatScreen>(find.byType(ChatScreen, skipOffstage: false))
        .map((c) => c.session.id)
        .toList(),
  };
  await tester.runAsync(
    () => File(
      'review-evidence/independent-$name.json',
    ).writeAsString(jsonEncode(data)),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });

  for (final push in [false, true]) {
    testWidgets(
      'INDEPENDENT settled canonical loses to source; exact State draft scroll and next turn push=$push',
      (tester) async {
        await tester.binding.setSurfaceSize(const Size(1000, 1600));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = _RootAliasFixture();
        await f.initialize(tester);
        try {
          final sourceId = await _startSource(tester, f);
          final normal = f.controller.normalSessionFor(f.connection);
          final source = normal.findChat(sourceId)!;
          await f.canonicalTap(tester, viaPush: false);
          final canonicalState = tester.state(find.byType(ChatScreen));
          final canonicalRoute = ModalRoute.of(canonicalState.context)!;
          final canonical = normal.findChat('stored')!;
          await tester.enterText(
            find.byType(TextField),
            'Earlier canonical request',
          );
          await tester.tap(find.byTooltip('Send'));
          await widgetUntil(tester, () => f.server.prompts.length == 1);
          f.server.finish(
            List.generate(
              70,
              (i) => 'Earlier canonical reply line $i.',
            ).join('\n\n'),
          );
          await widgetUntil(tester, () => !canonical.snapshot.hasActiveTurn);
          expect(canonical.turnId, isNotNull);
          expect(source.snapshot.hasActiveTurn, isTrue);
          await _drain(tester);
          await tester.enterText(
            find.byType(TextField),
            'Newer canonical unsent draft',
          );
          await _drain(tester);
          final scrolls = tester
              .stateList<ScrollableState>(
                find.descendant(
                  of: find.byType(ChatScreen),
                  matching: find.byType(Scrollable),
                ),
              )
              .where((s) => s.position.maxScrollExtent > 200)
              .toList();
          expect(scrolls, hasLength(1));
          final scroll = scrolls.single;
          scroll.position.jumpTo(120);
          await _drain(tester);
          final before = scroll.position.pixels;
          await _cover(tester, canonicalState);
          f.server.releaseCreate();
          await widgetUntil(
            tester,
            () =>
                identical(normal.findChat('stored'), source) &&
                f.server.prompts.length == 2,
          );
          expect(source.localSessionId, sourceId);
          expect(normal.chats, hasLength(1));
          expect(f.server.prompts.map((p) => p['text']), [
            'Earlier canonical request',
            'Independent source request',
          ]);
          await f.canonicalTap(tester, viaPush: push);
          await tester.pump(const Duration(seconds: 1));
          expect(canonicalRoute.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(canonicalState));
          expect(
            find.byType(ChatScreen, skipOffstage: false),
            findsNWidgets(2),
          );
          expect(scroll.mounted, isTrue);
          expect(scroll.position.pixels, closeTo(before, 1));
          expect(
            tester.widget<TextField>(find.byType(TextField)).controller!.text,
            'Newer canonical unsent draft',
          );
          expect(
            await tester.runAsync(
              () => ComposerDraftStore.read(
                connectionId: f.connection.id,
                sessionId: 'stored',
              ),
            ),
            'Newer canonical unsent draft',
          );
          expect(f.terminals, isEmpty);
          _lifecycle(tester, AppLifecycleState.paused);
          await _drain(tester);
          expect(f.nativeRunning, isTrue);
          expect(f.ongoing, hasLength(1));
          final winningTurn = source.turnId;
          f.server.finish('Independent source response');
          await widgetUntil(tester, () => !f.controller.hasActiveTurn);
          await _drain(tester);
          expect(f.terminals, hasLength(1));
          expect(jsonDecode(f.terminals.single['payload'] as String), {
            'connectionId': f.connection.id,
            'sessionId': 'stored',
            'turnId': winningTurn,
          });
          expect(f.ongoing, isEmpty);
          expect(f.nativeRunning, isFalse);
          _lifecycle(tester, AppLifecycleState.resumed);
          await _drain(tester);
          await _cover(tester, canonicalState);
          f.tap(sourceId);
          await _drain(tester);
          await tester.pump(const Duration(seconds: 1));
          expect(canonicalRoute.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(canonicalState));
          await tester.enterText(
            find.byType(TextField),
            'Explicit next canonical send',
          );
          await tester.tap(find.byTooltip('Send'));
          await widgetUntil(tester, () => f.server.prompts.length == 3);
          f.server.event('message.start', {}, turnId: 'wire-2');
          f.server.event('turn.end', {}, turnId: 'wire-2');
          await _drain(tester);
          expect(
            source.snapshot.hasActiveTurn,
            isTrue,
            reason: 'old settled RPC events cannot settle the newer turn',
          );
          f.server.finish('Third explicit result');
          await widgetUntil(tester, () => !f.controller.hasActiveTurn);
          await _drain(tester);
          expect(
            f.terminals,
            hasLength(1),
            reason: 'foreground third turn is not a background alert',
          );
          expect(f.server.creates, 1);
          expect(f.pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
          expect(tester.takeException(), isNull);
          await _record(tester, f, 'settled-$push', {
            'sourceWinner': true,
            'exactRetainedState': true,
            'canonicalCurrent': canonicalRoute.isCurrent,
            'scrollBefore': before,
            'scrollAfterFocus': scroll.position.pixels,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  for (final alias in ['local', 'stored']) {
    testWidgets(
      'INDEPENDENT durable route registered first survives local alias disposal; tap=$alias',
      (tester) async {
        await tester.binding.setSurfaceSize(const Size(1000, 1600));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = _RootAliasFixture();
        await f.initialize(tester);
        try {
          final sourceId = await _startSource(tester, f);
          final normal = f.controller.normalSessionFor(f.connection);
          await f.canonicalTap(tester, viaPush: false);
          final durable = tester.state(find.byType(ChatScreen));
          final route = ModalRoute.of(durable.context)!;
          f.tap(sourceId);
          await widgetUntil(
            tester,
            () =>
                find
                    .byType(ChatScreen, skipOffstage: false)
                    .evaluate()
                    .length ==
                3,
          );
          await tester.pump(const Duration(seconds: 1));
          await _drain(tester);
          final local = tester.state(find.byType(ChatScreen));
          expect(local, isNot(same(durable)));
          f.server.releaseCreate();
          await widgetUntil(
            tester,
            () =>
                identical(
                  normal.findChat(sourceId),
                  normal.findChat('stored'),
                ) &&
                f.server.prompts.length == 1,
          );
          await _cover(tester, local);
          f.tap(alias == 'local' ? sourceId : 'stored');
          await widgetUntil(tester, () => route.isCurrent);
          await tester.pump(const Duration(seconds: 1));
          await _drain(tester);
          expect(local.mounted, isFalse);
          expect(tester.state(find.byType(ChatScreen)), same(durable));
          expect(
            find.byType(ChatScreen, skipOffstage: false),
            findsNWidgets(2),
          );
          for (final id in ['stored', sourceId]) {
            await _cover(tester, durable);
            f.tap(id);
            await _drain(tester);
            await tester.pump(const Duration(seconds: 1));
            await _drain(tester);
            expect(route.isCurrent, isTrue);
            expect(tester.state(find.byType(ChatScreen)), same(durable));
            expect(
              find.byType(ChatScreen, skipOffstage: false),
              findsNWidgets(2),
            );
          }
          f.server.finish('Durable preference result');
          await widgetUntil(tester, () => !f.controller.hasActiveTurn);
          expect(f.server.prompts, hasLength(1));
          expect(tester.takeException(), isNull);
          await _record(tester, f, 'durable-first-$alias', {
            'exactState': true,
            'localAliasDisposed': !local.mounted,
            'canonicalCurrent': route.isCurrent,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  for (final action in [
    'newer',
    'profile',
    'key',
    'removed',
    'pause',
    'dispose',
  ]) {
    testWidgets(
      'INDEPENDENT alias converges during real detail HTTP; fence=$action',
      (tester) async {
        await tester.binding.setSurfaceSize(const Size(1000, 1600));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = _RootAliasFixture();
        await f.initialize(tester);
        final gate = Completer<void>();
        try {
          final sourceId = await _startSource(tester, f);
          final normal = f.controller.normalSessionFor(f.connection);
          await f.canonicalTap(tester, viaPush: false);
          final canonical = tester.state(find.byType(ChatScreen));
          final route = ModalRoute.of(canonical.context)!;
          await _cover(tester, canonical);
          f.server.nextSessionListGate = gate;
          f.server.sessionListEntered = Completer<void>();
          f.tap(sourceId);
          await widgetUntil(
            tester,
            () => f.server.sessionListEntered!.isCompleted,
          );
          f.server.releaseCreate();
          await widgetUntil(
            tester,
            () =>
                identical(
                  normal.findChat(sourceId),
                  normal.findChat('stored'),
                ) &&
                f.server.prompts.length == 1,
          );
          if (action == 'newer') {
            f.tap('stored');
            await _drain(tester);
            await tester.pump(const Duration(seconds: 1));
            expect(route.isCurrent, isTrue);
            await _cover(tester, canonical);
          } else if (action == 'profile') {
            await _profileEdit(f);
          } else if (action == 'key') {
            await f.manager.updateApiKey(
              f.connection.id,
              'independent-new-key',
            );
          } else if (action == 'removed') {
            await f.manager.deleteConnection(f.connection.id);
          } else if (action == 'pause') {
            _lifecycle(tester, AppLifecycleState.paused);
          } else if (action == 'dispose') {
            final appState = tester.state(find.byType(HermesApp));
            await tester.pumpWidget(const SizedBox.shrink());
            await _drain(tester);
            expect(appState.mounted, isFalse);
          }
          gate.complete();
          await _drain(tester);
          await tester.pump(const Duration(seconds: 1));
          await _drain(tester);
          if (action == 'dispose') {
            expect(find.byType(ChatScreen, skipOffstage: false), findsNothing);
            expect(f.nativeRunning, isFalse);
          } else {
            expect(route.isCurrent, isFalse);
            expect(
              find.byType(ChatScreen, skipOffstage: false),
              findsNWidgets(2),
            );
            if (action == 'pause') {
              _lifecycle(tester, AppLifecycleState.resumed);
              await widgetUntil(tester, () => route.isCurrent);
              await tester.pump(const Duration(seconds: 1));
              await _drain(tester);
              expect(tester.state(find.byType(ChatScreen)), same(canonical));
              expect(
                find.byType(ChatScreen, skipOffstage: false),
                findsNWidgets(2),
              );
            } else {
              expect(find.text('Independent retained cover'), findsOneWidget);
            }
          }
          expect(f.server.prompts, hasLength(1));
          expect(f.pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
          expect(tester.takeException(), isNull);
          await _record(tester, f, 'detail-$action', {'fenceHeld': true});
        } finally {
          if (!gate.isCompleted) gate.complete();
          await f.close(tester);
        }
      },
    );
  }

  for (final action in [
    'valid',
    'latest',
    'profile',
    'key',
    'consent',
    'master',
    'kind',
    'expiry',
    'pause-revoke',
    'dispose',
  ]) {
    testWidgets(
      'INDEPENDENT production push after held authenticated HTTP then native validation; fence=$action',
      (tester) async {
        await tester.binding.setSurfaceSize(const Size(1000, 1600));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = _RootAliasFixture();
        await f.initialize(tester);
        final detail = Completer<void>();
        final native = Completer<Map<String, dynamic>>();
        try {
          final sourceId = await _startSource(tester, f);
          final sourceState = tester.state(find.byType(ChatScreen));
          final normal = f.controller.normalSessionFor(f.connection);
          await _cover(tester, sourceState);
          f.server.nextSessionListGate = detail;
          f.server.sessionListEntered = Completer<void>();
          final expiry = DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3;
          _seedPush(f, expiry: action == 'expiry' ? expiry : null);
          await tester.runAsync(f.push.refresh);
          await widgetUntil(
            tester,
            () => f.server.sessionListEntered!.isCompleted,
          );
          f.server.releaseCreate();
          await widgetUntil(
            tester,
            () =>
                normal.findChat(sourceId)?.storedSessionId == 'stored' &&
                f.server.prompts.length == 1,
          );
          f.snapshotGate = native;
          f.snapshotEntered = Completer<void>();
          detail.complete();
          await widgetUntil(tester, () => f.snapshotEntered!.isCompleted);
          final captured = Map<String, dynamic>.from(f.native);
          if (action == 'latest') {
            f.tap('stored.unverified-lookalike');
            await _drain(tester);
            await tester.pump(const Duration(seconds: 1));
            await widgetUntil(
              tester,
              () => find.byType(WorkspaceScreen).evaluate().isNotEmpty,
            );
          } else if (action == 'profile') {
            await _profileEdit(f);
          } else if (action == 'key') {
            await f.manager.updateApiKey(f.connection.id, 'push-new-key');
          } else if (action == 'consent' || action == 'pause-revoke') {
            if (action == 'pause-revoke') {
              _lifecycle(tester, AppLifecycleState.paused);
            }
            await tester.runAsync(f.push.disable);
          } else if (action == 'master') {
            notificationPrefs.value = NotificationPrefs.defaults.copyWith(
              enabled: false,
            );
          } else if (action == 'kind') {
            notificationPrefs.value = NotificationPrefs.defaults.copyWith(
              kind: HermesNotificationKind.input,
              kindValue: false,
            );
          } else if (action == 'expiry') {
            await tester.runAsync(() async {
              final wait =
                  expiry * 1000 - DateTime.now().millisecondsSinceEpoch + 100;
              if (wait > 0) {
                await Future<void>.delayed(Duration(milliseconds: wait));
              }
            });
          } else if (action == 'dispose') {
            final root = tester.state(find.byType(HermesApp));
            await tester.pumpWidget(const SizedBox.shrink());
            await _drain(tester);
            expect(root.mounted, isFalse);
          }
          native.complete(captured);
          await _drain(tester);
          await tester.pump(const Duration(seconds: 1));
          await _drain(tester);
          if (action == 'pause-revoke') {
            _lifecycle(tester, AppLifecycleState.resumed);
            await _drain(tester);
            await tester.pump(const Duration(seconds: 1));
            await _drain(tester);
          }
          if (action == 'valid') {
            await widgetUntil(
              tester,
              () => find.byType(ChatScreen).evaluate().isNotEmpty,
            );
            final retained = tester.state(find.byType(ChatScreen));
            expect(retained, isNot(same(sourceState)));
            expect(
              find.byType(ChatScreen, skipOffstage: false),
              findsNWidgets(2),
            );
            await _cover(tester, retained);
            f.tap(sourceId);
            await _drain(tester);
            await tester.pump(const Duration(seconds: 1));
            await _drain(tester);
            expect(tester.state(find.byType(ChatScreen)), same(retained));
            expect(ModalRoute.of(retained.context)!.isCurrent, isTrue);
          } else if (action == 'dispose') {
            expect(find.byType(ChatScreen, skipOffstage: false), findsNothing);
            expect(f.nativeRunning, isFalse);
          } else {
            expect(
              find.byType(ChatScreen, skipOffstage: false),
              findsOneWidget,
            );
            expect(ModalRoute.of(sourceState.context)!.isCurrent, isFalse);
            if (action == 'latest') {
              expect(find.byType(WorkspaceScreen), findsOneWidget);
            } else {
              expect(find.text('Independent retained cover'), findsOneWidget);
            }
          }
          expect(f.server.prompts, hasLength(1));
          expect(f.pushRequests, isNotEmpty);
          expect(pendingNotificationApprovals.value, isEmpty);
          expect(f.pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
          expect(tester.takeException(), isNull);
          await _record(tester, f, 'push-$action', {
            'validationEntered': true,
            'physicalDetailRead': true,
            'expiredAt': action == 'expiry' ? expiry : null,
          });
        } finally {
          if (!detail.isCompleted) detail.complete();
          if (!native.isCompleted) {
            native.complete(Map<String, dynamic>.from(f.native));
          }
          await f.close(tester);
        }
      },
    );
  }

  testWidgets(
    'INDEPENDENT same saved ID with changed profile cannot raise prior-account alias State',
    (tester) async {
      await tester.binding.setSurfaceSize(const Size(1000, 1600));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final f = _RootAliasFixture();
      await f.initialize(tester);
      try {
        final sourceId = await _startSource(tester, f);
        final normal = f.controller.normalSessionFor(f.connection);
        await f.canonicalTap(tester, viaPush: false);
        final oldState = tester.state(find.byType(ChatScreen));
        final oldRoute = ModalRoute.of(oldState.context)!;
        f.server.releaseCreate();
        await widgetUntil(
          tester,
          () =>
              identical(normal.findChat(sourceId), normal.findChat('stored')) &&
              f.server.prompts.length == 1,
        );
        f.server.finish('Old account completed');
        await widgetUntil(tester, () => !f.controller.hasActiveTurn);
        await _cover(tester, oldState);
        await _profileEdit(f);
        f.connection = f.manager.getConnections().single;
        f.tap('stored');
        await widgetUntil(
          tester,
          () =>
              find.byType(ChatScreen, skipOffstage: false).evaluate().length ==
              3,
        );
        await tester.pump(const Duration(seconds: 1));
        await _drain(tester);
        final currentState = tester.state(find.byType(ChatScreen));
        expect(currentState, isNot(same(oldState)));
        expect(oldState.mounted, isTrue);
        expect(oldRoute.isCurrent, isFalse);
        expect(
          tester
              .widget<ChatScreen>(find.byType(ChatScreen))
              .connection
              .gatewayProfile,
          'different-profile',
        );
        final newNormal = f.controller.normalSessionFor(f.connection);
        expect(newNormal, isNot(same(normal)));
        expect(
          newNormal.findChat(sourceId),
          isNull,
          reason: 'old verified aliases are account scoped',
        );
        await _cover(tester, currentState);
        f.tap('stored');
        await _drain(tester);
        await tester.pump(const Duration(seconds: 1));
        await _drain(tester);
        expect(tester.state(find.byType(ChatScreen)), same(currentState));
        expect(find.byType(ChatScreen, skipOffstage: false), findsNWidgets(3));
        expect(f.server.prompts, hasLength(1));
        expect(tester.takeException(), isNull);
        await _record(tester, f, 'profile-route-pruning', {
          'differentState': true,
          'oldRouteCurrent': oldRoute.isCurrent,
          'accountScopedAlias': true,
        });
      } finally {
        await f.close(tester);
      }
    },
  );
}
