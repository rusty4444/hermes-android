import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/models/gateway_activity.dart';
import 'package:hermes_android/core/services/chat_presentation_state.dart';
import 'package:hermes_android/core/services/tool_activity_group_pins.dart';
import 'package:hermes_android/core/widgets/gateway_activity_card.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'support/l10n_test_utils.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));
  for (final reverse in [false, true]) {
    test(
      'FRESH independent prebinding visits preserve opposite choices identity-only fanout reverse=$reverse',
      () async {
        final registry = ChatPresentationRegistry('fresh-presentation');
        final a = registry.chatFor('local');
        final b = registry.chatFor('stored');
        final aVisit = a.openToolVisit()..pin('anonymous-a', true);
        final bVisit = b.openToolVisit()..pin('anonymous-a', false);
        // MAIN81D third policy layer: independent reasoning visits, not copied
        // global manual values. All original tool/alias/close assertions remain.
        final aReasoning = a.openReasoningVisit()
          ..pin('first-render-scoped-reason', true);
        final bReasoning = b.openReasoningVisit()
          ..pin('other-scoped-reason', false);
        a.aliasTool('anonymous-a', 'tool:durable-a');
        b.aliasTool('anonymous-b', 'tool:durable-b');
        expect(aVisit['tool:durable-a'], isTrue);
        expect(bVisit['tool:durable-a'], isNull);
        registry.bind(
          reverse ? 'stored' : 'local',
          reverse ? 'local' : 'stored',
        );
        final root = registry.chatFor('local');
        expect(root, same(registry.chatFor('stored')));
        expect(aVisit['anonymous-a'], isTrue);
        expect(bVisit['anonymous-a'], isFalse);
        expect(aVisit['tool:durable-a'], isTrue);
        expect(bVisit['tool:durable-a'], isFalse);
        // An alias learned in either source is metadata in all surviving tokens.
        aVisit.pin('anonymous-b', true);
        bVisit.pin('anonymous-b', false);
        expect(aVisit['tool:durable-b'], isTrue);
        expect(bVisit['tool:durable-b'], isFalse);
        final third = root.openToolVisit();
        expect(third.length, 0);
        expect(third['tool:durable-a'], isNull);
        third.pin('anonymous-a', false);
        expect(third['tool:durable-a'], isFalse);
        a.closeToolVisit(aVisit);
        expect(aVisit.length, 0);
        expect(bVisit['tool:durable-a'], isFalse);
        b.aliasTool('anonymous-b', 'tool:durable-new');
        expect(bVisit['tool:durable-new'], isFalse);
        expect(
          aVisit['tool:durable-new'],
          isNull,
          reason: 'closed token must not remain an orphan live visit',
        );
        expect(aReasoning['first-render-scoped-reason'], isTrue);
        expect(bReasoning['other-scoped-reason'], isFalse);
        expect(aReasoning['other-scoped-reason'], isNull);
        expect(bReasoning['first-render-scoped-reason'], isNull);
        a.closeReasoningVisit(aReasoning);
        expect(aReasoning.length, 0);
        expect(bReasoning['other-scoped-reason'], isFalse);
        expect(root.openReasoningVisit()['first-render-scoped-reason'], isNull);
        registry.close();
        expect(bVisit.length, 0);
        expect(third.length, 0);
        expect(() => a.openToolVisit(), throwsStateError);
        // Closing a redirected old view after app close remains exact and safe.
        a.closeToolVisit(aVisit);
        await Future<void>.delayed(Duration.zero);
      },
    );
  }
  test(
    'FRESH identity ledger bounds survive visit churn without importing choices',
    () {
      final registry = ChatPresentationRegistry('bounded-visits');
      final state = registry.chatFor('stored');
      final first = state.openToolVisit();
      for (var i = 0; i < 350; i++) {
        state.aliasTool('group-$i', 'tool:$i');
        first.pin('group-$i', i.isEven);
      }
      expect(first.length, lessThanOrEqualTo(ToolActivityGroupPins.maxPins));
      expect(first['group-0'], isNull);
      for (var i = 0; i < 150; i++) {
        // Keep this link actively evidenced while old links are evicted.
        state.aliasTool('group-349', 'tool:349');
        final visit = state.openToolVisit();
        expect(visit.length, 0);
        visit.pin('group-349', false);
        expect(visit['tool:349'], isFalse);
        visit.pin('group-0', true);
        expect(
          visit['tool:0'],
          isNull,
          reason:
              'expired identity alias must not survive the 100-entry ledger',
        );
        state.closeToolVisit(visit);
        state.aliasTool('post-close-$i', 'post-tool-$i');
        expect(visit.length, 0);
      }
      state.closeToolVisit(first);
      registry.close();
    },
  );
  for (final width in [400.0, 1000.0]) {
    testWidgets(
      'FRESH collapsed preview prefers newest nonterminal not latest timestamp width=$width',
      (tester) async {
        await tester.binding.setSurfaceSize(Size(width, 1000));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final at = DateTime(2026, 1, 1, 1, 2, 3);
        GatewayToolActivity activity(
          String name,
          String id,
          GatewayToolActivityPhase phase, {
          DateTime? time,
        }) => GatewayToolActivity(
          name: name,
          toolId: id,
          phase: phase,
          detail: 'Secret-body-$id',
          durationSeconds: phase == GatewayToolActivityPhase.failed
              ? 2.5
              : null,
          lastActivityAt: time ?? at,
          lastActivityTimeSource: GatewayToolTimeSource.observed,
        );
        Future<void> show(
          List<GatewayToolActivity> items, {
          bool verbose = false,
        }) async {
          await tester.pumpWidget(
            testAppWithL10n(
              Scaffold(
                body: ListView(
                  children: [
                    GatewayActivityCard(activities: items, verbose: verbose),
                  ],
                ),
              ),
            ),
          );
          await tester.pump(const Duration(milliseconds: 350));
        }

        bool expanded() => tester
            .widget<ExpansionTile>(find.byType(ExpansionTile))
            .controller!
            .isExpanded;
        var items = [
          activity('terminal', 'a', GatewayToolActivityPhase.running),
          activity('read_file', 'b', GatewayToolActivityPhase.progress),
          activity(
            'search_files',
            'c',
            GatewayToolActivityPhase.failed,
            time: at.add(const Duration(seconds: 10)),
          ),
        ];
        await show(items);
        expect(expanded(), isFalse);
        expect(find.text('Read file: Working'), findsOneWidget);
        expect(find.textContaining('Terminal:'), findsNothing);
        expect(find.textContaining('Search files:'), findsNothing);
        expect(
          find.text('Last observed 01:02:13 (local)'),
          findsOneWidget,
          reason: 'aggregate time must still include the later failed sibling',
        );
        expect(find.text('Secret-body-b'), findsNothing);
        items = [
          items[0],
          activity('read_file', 'b', GatewayToolActivityPhase.completed),
          items[2],
        ];
        await show(items);
        expect(expanded(), isFalse);
        expect(find.text('Terminal: Running'), findsOneWidget);
        items = [
          activity(
            'terminal',
            'a',
            GatewayToolActivityPhase.completed,
            time: at.add(const Duration(seconds: 20)),
          ),
          items[1],
          items[2],
        ];
        await show(items);
        expect(find.text('Search files: Failed after 2.5 s'), findsOneWidget);
        expect(find.text('1 failed • 3 total'), findsOneWidget);
        expect(find.text('Last observed 01:02:23 (local)'), findsOneWidget);
        await tester.tap(find.text('Tool activity'));
        await tester.pump(const Duration(milliseconds: 350));
        expect(expanded(), isTrue);
        expect(find.text('Secret-body-a'), findsOneWidget);
        expect(find.text('Secret-body-c'), findsOneWidget);
        await show([
          ...items,
          activity('newest', 'd', GatewayToolActivityPhase.running),
        ]);
        expect(expanded(), isTrue);
        await tester.tap(find.text('Tool activity'));
        await tester.pump(const Duration(milliseconds: 350));
        await show([
          ...items,
          activity('newest', 'd', GatewayToolActivityPhase.running),
        ], verbose: true);
        expect(
          expanded(),
          isFalse,
          reason: 'manual closed beats explicit verbose within visit',
        );
        expect(find.text('Newest: Running'), findsOneWidget);
        await tester.pumpWidget(const SizedBox());
        await show(items);
        expect(expanded(), isFalse, reason: 'new State resets manual choice');
        await tester.pumpWidget(const SizedBox());
        await show([], verbose: true);
        expect(expanded(), isTrue);
        expect(find.text('0 completed'), findsOneWidget);
        await show([]);
        expect(
          expanded(),
          isFalse,
          reason: 'explicit verbose fallback is not a manual pin',
        );
        expect(tester.takeException(), isNull);
      },
    );
  }
}
