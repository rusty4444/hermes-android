import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/composer_draft_store.dart';
import 'package:hermes_android/core/services/connection_keepalive_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/gateway_turn_journal.dart';
import 'package:hermes_android/core/services/mobile_push_service.dart';
import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'support/memory_turn_journal_store.dart';

// Independent multi-session server: no producer/spec navigation fixture imports.
class _Wire {
  _Wire(this.http);
  final HttpServer http;
  final sockets = <WebSocket>[];
  final requests = <String>[];
  final rpc = <Map<String, dynamic>>[];
  final prompts = <String, List<Map<String, dynamic>>>{};
  final running = <String>{};
  final history = <String, List<Map<String, dynamic>>>{};
  final createEntered = Completer<void>();
  void Function()? releaseCreate;
  bool closed = false;

  static Future<_Wire> start() async {
    final wire = _Wire(await HttpServer.bind(InternetAddress.loopbackIPv4, 0));
    wire.http.listen(wire.handle);
    return wire;
  }

  Map<String, dynamic> session(String id) => {
    'id': id,
    'title': 'Quality $id',
    'model': 'fixture',
    'source': 'mobile',
    'message_count': history[id]?.length ?? 0,
    'started_at': 1,
  };

  Future<void> handle(HttpRequest request) async {
    requests.add(request.uri.toString());
    if (request.uri.path.startsWith('/api/sessions')) {
      expectSync(request.headers.value('authorization'), 'Bearer quality-key');
      request.response.headers.contentType = ContentType.json;
      if (request.uri.path == '/api/sessions') {
        request.response.write(
          jsonEncode({
            'data': [session('shared'), session('other')],
            'has_more': false,
          }),
        );
      } else if (request.uri.path.endsWith('/messages')) {
        final id = request.uri.pathSegments[2];
        if (id != 'shared' && id != 'other') {
          request.response.statusCode = 404;
        }
        request.response.write(jsonEncode({'data': history[id] ?? []}));
      } else {
        request.response.statusCode = 404;
      }
      await request.response.close();
      return;
    }
    if (request.uri.path == '/api/auth/ws-ticket') {
      request.response.headers.contentType = ContentType.json;
      request.response.write('{"ticket":"quality"}');
      await request.response.close();
      return;
    }
    if (request.uri.path != '/api/ws') {
      request.response.statusCode = 404;
      await request.response.close();
      return;
    }
    final socket = await WebSocketTransformer.upgrade(request);
    sockets.add(socket);
    socket.add(
      jsonEncode({
        'jsonrpc': '2.0',
        'method': 'event',
        'params': {'type': 'gateway.ready', 'payload': {}},
      }),
    );
    socket.listen((raw) {
      if (closed) return;
      final frame = Map<String, dynamic>.from(jsonDecode(raw as String) as Map);
      rpc.add(frame);
      final method = frame['method'];
      if (method == null) return;
      final params = Map<String, dynamic>.from(frame['params'] as Map? ?? {});
      final reply = <String, dynamic>{'jsonrpc': '2.0', 'id': frame['id']};
      if (method == 'session.resume') {
        final id = params['session_id'] as String?;
        if (id != 'shared' && id != 'other') {
          reply['error'] = {'code': 4007, 'message': 'session not found'};
        } else {
          reply['result'] = {
            'session_id': 'runtime-$id',
            'stored_session_id': id,
            'running': running.contains(id),
            'status': running.contains(id) ? 'running' : 'idle',
          };
        }
      } else if (method == 'session.create') {
        expectSync(params.containsKey('session_id'), isFalse);
        reply['result'] = {
          'session_id': 'runtime-shared',
          'stored_session_id': 'shared',
          'message_count': 0,
          'messages': [],
        };
        final encoded = jsonEncode(reply);
        releaseCreate = () {
          if (socket.readyState == WebSocket.open) socket.add(encoded);
        };
        if (!createEntered.isCompleted) createEntered.complete();
        return;
      } else {
        if (method == 'prompt.submit') {
          final id = (params['session_id'] as String).replaceFirst(
            'runtime-',
            '',
          );
          prompts.putIfAbsent(id, () => []).add(params);
          running.add(id);
        }
        reply['result'] = {'ok': true};
      }
      if (socket.readyState == WebSocket.open) socket.add(jsonEncode(reply));
    });
  }

  void finish(String id) {
    expect(running.remove(id), isTrue);
    final turn = 'quality-$id-${prompts[id]!.length}';
    final rows = history.putIfAbsent(id, () => []);
    rows.addAll([
      {
        'id': rows.length + 1,
        'role': 'user',
        'content': prompts[id]!.last['text'],
      },
      {'id': rows.length + 2, 'role': 'assistant', 'content': 'Result $id'},
    ]);
    for (final entry in [
      ('message.start', <String, dynamic>{}),
      ('message.complete', <String, dynamic>{'text': 'Result $id'}),
      ('turn.end', <String, dynamic>{}),
    ]) {
      // Scope by runtime and multicast over open owned sockets, not sockets.last.
      for (final socket in sockets.where(
        (s) => s.readyState == WebSocket.open,
      )) {
        socket.add(
          jsonEncode({
            'jsonrpc': '2.0',
            'method': 'event',
            'params': {
              'type': entry.$1,
              'session_id': 'runtime-$id',
              'turn_id': turn,
              'payload': entry.$2,
            },
          }),
        );
      }
    }
  }

  Future<void> close() async {
    if (closed) return;
    closed = true;
    releaseCreate?.call();
    for (final socket in sockets) {
      await socket.close();
    }
    await http.close(force: true);
  }
}

class _Secrets implements CredentialStore {
  final entries = <String, String>{};
  @override
  String? readCached(String key) => entries[key];
  @override
  Future<String?> read(String key) async => entries[key];
  @override
  Future<void> write(String key, String value) async => entries[key] = value;
  @override
  Future<void> delete(String key) async => entries.remove(key);
}

const _plugin = MethodChannel('dexterous.com/flutter/local_notifications');
const _tts = MethodChannel('flutter_tts');
const _picker = MethodChannel('plugins.flutter.io/image_picker');

Future<void> _until(WidgetTester tester, bool Function() predicate) async {
  for (var n = 0; n < 400; n++) {
    await tester.pump();
    if (predicate()) return;
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 5)),
    );
  }
  fail('Independent root condition did not arrive');
}

Future<void> _animate(WidgetTester tester) async {
  await tester.pump();
  await tester.pump(const Duration(seconds: 1));
  for (var i = 0; i < 15; i++) {
    await tester.pump();
    await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  }
}

void _lifecycle(WidgetTester tester, bool paused) {
  if (paused) {
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  } else {
    if (tester.binding.lifecycleState == AppLifecycleState.paused) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
  }
}

class _Root {
  final wires = <_Wire>[];
  final accounts = <SavedConnection>[];
  final commands = <MethodCall>[];
  final keepalive = <String>[];
  final live = <int, Map<String, dynamic>>{};
  final controller = GatewayTurnApplicationController(
    journalFactory: () => GatewayTurnJournal(store: MemoryTurnJournalStore()),
  );
  final push = MobilePushService(supported: false);
  late ConnectionManager manager;
  bool nativeRunning = false;
  String? recordedSchedule;

  Future<void> mount(WidgetTester tester, {int count = 1}) async {
    _lifecycle(tester, false);
    manager = ConnectionManager(
      await SharedPreferences.getInstance(),
      credentialStore: _Secrets(),
    );
    for (var i = 0; i < count; i++) {
      final wire = (await tester.runAsync(_Wire.start))!;
      wires.add(wire);
      await manager.saveConnection(
        'Quality $i',
        '127.0.0.1',
        wire.http.port,
        'quality-key',
        dashboardPort: wire.http.port,
        dashboardProxied: true,
        gatewayProfile: 'profile-$i',
      );
    }
    accounts.addAll(
      wires.map(
        (wire) => manager.getConnections().singleWhere(
          (c) => c.port == wire.http.port,
        ),
      ),
    );
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(_tts, (_) async => 1);
    messenger.setMockMethodCallHandler(_picker, (_) async => null);
    messenger.setMockMethodCallHandler(_plugin, (call) async {
      commands.add(call);
      if (call.method == 'show') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live[args['id'] as int] = args;
      } else if (call.method == 'cancel') {
        live.remove((call.arguments as Map)['id']);
      }
      return call.method == 'getNotificationAppLaunchDetails' ? null : true;
    });
    messenger.setMockMethodCallHandler(ConnectionKeepAliveService.channel, (
      call,
    ) async {
      keepalive.add(call.method);
      if (call.method == 'start') nativeRunning = true;
      if (call.method == 'stop') nativeRunning = false;
      return true;
    });
    await tester.pumpWidget(
      HermesApp(
        connManager: manager,
        turnApplicationController: controller,
        mobilePush: push,
      ),
    );
    await _animate(tester);
    expect(find.byType(ChatScreen, skipOffstage: false), findsNothing);
  }

  void tap(String id, {int account = 0}) => notificationResponseHandler!(
    NotificationResponse(
      payload: jsonEncode({
        'connectionId': accounts[account].id,
        'sessionId': id,
      }),
      notificationResponseType: NotificationResponseType.selectedNotification,
    ),
  );

  Future<State> open(WidgetTester tester, String id, {int account = 0}) async {
    tap(id, account: account);
    await _until(
      tester,
      () => find.byType(ChatScreen, skipOffstage: false).evaluate().any((e) {
        final screen = e.widget as ChatScreen;
        return screen.session.id == id &&
            screen.connection.id == accounts[account].id &&
            ModalRoute.of(e)!.isCurrent;
      }),
    );
    await _animate(tester);
    return tester.state(find.byType(ChatScreen));
  }

  Iterable<Map<String, dynamic>> get ongoing => live.values.where(
    (n) => (n['platformSpecifics'] as Map?)?['ongoing'] == true,
  );
  Iterable<Map> get terminals => commands
      .where((c) => c.method == 'show')
      .map((c) => c.arguments as Map)
      .where(
        (n) =>
            n['title'] == 'Hermes response ready' ||
            n['title'] == 'Hermes turn failed',
      );

  Future<void> send(
    WidgetTester tester,
    String text,
    String id, {
    int account = 0,
  }) async {
    await tester.enterText(find.byType(TextField), text);
    await tester.tap(find.byTooltip('Send'));
    await _until(tester, () => wires[account].prompts[id]?.isNotEmpty ?? false);
  }

  Future<void> close(WidgetTester tester) async {
    _lifecycle(tester, false);
    await tester.pumpWidget(const SizedBox());
    await _animate(tester);
    await controller.close();
    for (final wire in wires) {
      await tester.runAsync(wire.close);
    }
    await tester.pump(const Duration(seconds: 16));
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    expect(find.byType(HermesApp), findsNothing);
    expect(nativeRunning, isFalse);
    expect(ongoing, isEmpty);
    expect(
      prefs.getStringList(TurnNotificationService.ongoingIdsStorageKey) ?? [],
      isEmpty,
    );
    expect(commands.where((c) => c.method == 'cancelAll'), isEmpty);
    expect(tester.takeException(), isNull);
    if (recordedSchedule != null) {
      await tester.runAsync(
        () => File('review-evidence/quality-cleanup-$recordedSchedule.json')
            .writeAsString(
              jsonEncode({
                'rootUnmounted': find.byType(HermesApp).evaluate().isEmpty,
                'nativeRunning': nativeRunning,
                'ongoingCount': ongoing.length,
                'durableOngoingIds':
                    prefs.getStringList(
                      TurnNotificationService.ongoingIdsStorageKey,
                    ) ??
                    [],
                'cancelAllCount': commands
                    .where((c) => c.method == 'cancelAll')
                    .length,
              }),
            ),
      );
    }
    push.dispose();
    final messenger = tester.binding.defaultBinaryMessenger;
    for (final channel in [
      _plugin,
      _tts,
      _picker,
      ConnectionKeepAliveService.channel,
    ]) {
      messenger.setMockMethodCallHandler(channel, null);
    }
    debugDefaultTargetPlatformOverride = null;
  }

  Future<void> record(
    WidgetTester tester,
    String name,
    Map<String, dynamic> facts,
  ) async {
    recordedSchedule = name;
    await tester.runAsync(
      () => File('review-evidence/quality-$name.json').writeAsString(
        jsonEncode({
          'schedule': name,
          ...facts,
          'mountedIds': tester
              .widgetList<ChatScreen>(
                find.byType(ChatScreen, skipOffstage: false),
              )
              .map((s) => '${s.connection.id}:${s.session.id}')
              .toList(),
          'rpc': wires.map((w) => w.rpc).toList(),
          'requests': wires.map((w) => w.requests).toList(),
          'keepalive': keepalive,
          'commands': commands
              .map((c) => {'method': c.method, 'arguments': c.arguments})
              .toList(),
        }),
      ),
    );
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });

  for (final remove in [false, true]) {
    testWidgets(
      'QUALITY exact cleanup cannot erase replacement during old route completion remove=$remove',
      (tester) async {
        final f = _Root();
        await f.mount(tester);
        try {
          final old = await f.open(tester, 'shared');
          final oldRoute = ModalRoute.of(old.context)!;
          final navigator = Navigator.of(old.context);
          await tester.enterText(
            find.byType(TextField),
            'Durable draft through replacement',
          );
          await _animate(tester);
          if (remove) {
            navigator.removeRoute(oldRoute);
          } else {
            navigator.pop();
          }
          // Intentionally before animation/disposal/completion drains.
          f.tap('shared');
          await _until(
            tester,
            () => find
                .byType(ChatScreen, skipOffstage: false)
                .evaluate()
                .any(
                  (e) =>
                      !identical((e as StatefulElement).state, old) &&
                      ModalRoute.of(e)!.isCurrent,
                ),
          );
          await _animate(tester);
          final replacement = tester.state(find.byType(ChatScreen));
          final route = ModalRoute.of(replacement.context)!;
          expect(old.mounted, isFalse);
          expect(route.isCurrent, isTrue);
          expect(find.byType(ChatScreen, skipOffstage: false), findsOneWidget);
          expect(
            tester.widget<TextField>(find.byType(TextField)).controller!.text,
            'Durable draft through replacement',
          );
          unawaited(
            navigator.push(
              MaterialPageRoute<void>(
                builder: (_) => const Scaffold(body: Text('Replacement cover')),
              ),
            ),
          );
          await _animate(tester);
          f.tap('shared');
          f.tap('shared');
          f.tap('shared');
          await _animate(tester);
          expect(route.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(replacement));
          expect(find.byType(ChatScreen, skipOffstage: false), findsOneWidget);
          // Draft persistence is a pause/close contract, not a per-edit save.
          _lifecycle(tester, true);
          await _animate(tester);
          expect(
            await tester.runAsync(
              () => ComposerDraftStore.read(
                connectionId: f.accounts.single.id,
                sessionId: 'shared',
              ),
            ),
            'Durable draft through replacement',
          );
          _lifecycle(tester, false);
          await _animate(tester);
          await f.record(tester, 'replacement-$remove', {
            'oldUnmounted': !old.mounted,
            'exactReplacement': true,
            'current': route.isCurrent,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  for (final sharedFirst in [false, true]) {
    testWidgets(
      'QUALITY alias focus preserves concurrent different chat after route disposal sharedFirst=$sharedFirst',
      (tester) async {
        final f = _Root();
        await f.mount(tester);
        try {
          final normal = f.controller.normalSessionFor(f.accounts.single);
          await normal.ready;
          normal.chatFor('quality-local', title: 'Local source');
          await f.open(tester, 'quality-local');
          await tester.enterText(
            find.byType(TextField),
            'Local admitted source',
          );
          await tester.tap(find.byTooltip('Send'));
          await _until(tester, () => f.wires.single.createEntered.isCompleted);
          final canonical = await f.open(tester, 'shared');
          final route = ModalRoute.of(canonical.context)!;
          await tester.enterText(
            find.byType(TextField),
            'Canonical draft retained',
          );
          await _animate(tester);
          final sibling = await f.open(tester, 'other');
          await f.send(tester, 'Concurrent other request', 'other');
          f.wires.single.releaseCreate!();
          await _until(
            tester,
            () => f.wires.single.prompts['shared']?.length == 1,
          );
          expect(
            normal.findChat('quality-local'),
            same(normal.findChat('shared')),
          );
          expect(f.controller.activeChatActivities, hasLength(2));
          f.tap('quality-local');
          f.tap('shared');
          await _animate(tester);
          expect(sibling.mounted, isFalse);
          expect(route.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(canonical));
          expect(
            find.byType(ChatScreen, skipOffstage: false),
            findsNWidgets(2),
          );
          expect(
            tester.widget<TextField>(find.byType(TextField)).controller!.text,
            'Canonical draft retained',
          );
          _lifecycle(tester, true);
          await _animate(tester);
          expect(f.ongoing, hasLength(2));
          expect(f.nativeRunning, isTrue);
          final first = sharedFirst ? 'shared' : 'other';
          final second = sharedFirst ? 'other' : 'shared';
          f.wires.single.finish(first);
          await _until(
            tester,
            () => f.controller.activeChatActivities.length == 1,
          );
          await _animate(tester);
          expect(
            f.controller.activeChatActivities.single.storedSessionId,
            second,
          );
          expect(f.ongoing, hasLength(1));
          expect(
            jsonDecode(f.ongoing.single['payload'] as String)['sessionId'],
            second,
          );
          expect(f.nativeRunning, isTrue);
          expect(f.terminals, hasLength(1));
          expect(
            jsonDecode(f.terminals.single['payload'] as String)['sessionId'],
            first,
          );
          f.wires.single.finish(second);
          await _until(tester, () => !f.controller.hasActiveTurn);
          await _animate(tester);
          expect(f.ongoing, isEmpty);
          expect(f.nativeRunning, isFalse);
          expect(f.terminals, hasLength(2));
          expect(
            f.wires.single.prompts.values.map((p) => p.length),
            everyElement(1),
          );
          _lifecycle(tester, false);
          await _animate(tester);
          expect(route.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(canonical));
          await f.record(tester, 'alias-sibling-$sharedFirst', {
            'concurrentDistinctWork': true,
            'disposedSiblingContinued': true,
            'exactCanonicalState': true,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  for (final firstAccount in [0, 1]) {
    testWidgets(
      'QUALITY same stored ID in different accounts never dedupes work first=$firstAccount',
      (tester) async {
        final f = _Root();
        await f.mount(tester, count: 2);
        try {
          final first = await f.open(tester, 'shared');
          final route = ModalRoute.of(first.context)!;
          await f.send(tester, 'Account zero request', 'shared');
          final second = await f.open(tester, 'shared', account: 1);
          await f.send(tester, 'Account one request', 'shared', account: 1);
          expect(f.controller.activeChatActivities, hasLength(2));
          f.tap('shared');
          await _animate(tester);
          expect(second.mounted, isFalse);
          expect(route.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(first));
          expect(find.byType(ChatScreen, skipOffstage: false), findsOneWidget);
          expect(f.controller.activeChatActivities, hasLength(2));
          _lifecycle(tester, true);
          await _animate(tester);
          expect(f.ongoing, hasLength(2));
          expect(f.nativeRunning, isTrue);
          f.wires[firstAccount].finish('shared');
          await _until(
            tester,
            () => f.controller.activeChatActivities.length == 1,
          );
          await _animate(tester);
          expect(
            f.controller.activeChatActivities.single.connectionId,
            f.accounts[1 - firstAccount].id,
          );
          expect(f.ongoing, hasLength(1));
          expect(
            jsonDecode(f.ongoing.single['payload'] as String)['connectionId'],
            f.accounts[1 - firstAccount].id,
          );
          expect(f.terminals, hasLength(1));
          expect(
            jsonDecode(f.terminals.single['payload'] as String)['connectionId'],
            f.accounts[firstAccount].id,
          );
          expect(f.nativeRunning, isTrue);
          f.wires[1 - firstAccount].finish('shared');
          await _until(tester, () => !f.controller.hasActiveTurn);
          await _animate(tester);
          expect(f.terminals, hasLength(2));
          expect(f.ongoing, isEmpty);
          expect(f.nativeRunning, isFalse);
          expect(f.wires.map((w) => w.prompts['shared']!.length), [1, 1]);
          await f.record(tester, 'accounts-$firstAccount', {
            'sameStoredDistinctAccounts': true,
            'disposedSecondContinued': true,
            'targetedCleanupOnly': true,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  for (final barrier in [false, true]) {
    testWidgets(
      'QUALITY root focus ignores nested same-ID route and real modal barrier=$barrier',
      (tester) async {
        final f = _Root();
        await f.mount(tester);
        try {
          final canonical = await f.open(tester, 'shared');
          final route = ModalRoute.of(canonical.context)!;
          final rootNavigator = Navigator.of(canonical.context);
          final nestedKey = GlobalKey<NavigatorState>();
          unawaited(
            rootNavigator.push(
              MaterialPageRoute<void>(
                builder: (_) => Navigator(
                  key: nestedKey,
                  onGenerateRoute: (_) => MaterialPageRoute<void>(
                    builder: (_) => ChatScreen(
                      connection: f.accounts.single,
                      session: Session.fromJson(
                        f.wires.single.session('shared'),
                      ),
                      turnApplicationController: f.controller,
                    ),
                  ),
                ),
              ),
            ),
          );
          await _animate(tester);
          expect(
            find.byType(ChatScreen, skipOffstage: false),
            findsNWidgets(2),
          );
          final nested = tester.state(find.byType(ChatScreen));
          expect(
            ModalRoute.of(nested.context)!.navigator,
            same(nestedKey.currentState),
          );
          expect(route.isCurrent, isFalse);
          if (barrier) {
            unawaited(
              showDialog<void>(
                context: nested.context,
                barrierDismissible: false,
                builder: (_) =>
                    const AlertDialog(content: Text('Owned nested modal')),
              ),
            );
            await _animate(tester);
          }
          f.tap('shared');
          f.tap('shared');
          await _animate(tester);
          expect(nested.mounted, isFalse);
          expect(route.isCurrent, isTrue);
          expect(tester.state(find.byType(ChatScreen)), same(canonical));
          expect(find.byType(ChatScreen, skipOffstage: false), findsOneWidget);
          expect(find.byType(AlertDialog, skipOffstage: false), findsNothing);
          expect(f.wires.single.prompts, isEmpty);
          await f.record(tester, 'nested-$barrier', {
            'nestedUnmounted': !nested.mounted,
            'exactRootState': true,
            'rootCurrent': route.isCurrent,
          });
        } finally {
          await f.close(tester);
        }
      },
    );
  }
}
