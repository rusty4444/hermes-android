// UNRECONCILED POLICY COPY. Raw /Volumes/Storage/Hermes/scratch/p2a-unreconciled-_flkt2h9/raw/independent_spec_cc009ac_request_start_test.dart.source
// SHA256 b20a79d490745fac3be5d87dff9519f16fba849ffe4e3361a35d874c04935f88; original unchanged; exact diff in policy evidence.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/desktop_gateway_client.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, send, until, widgetUntil;
import 'support/fake_voice_composer_adapter.dart';

// Independent actual route HTTP request-start ordering, not an injected stale observation.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          (_) async => null,
        );
  });
  tearDown(() {
    HttpOverrides.global = previous;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          null,
        );
  });
  for (final width in [400.0, 1000.0]) {
    testWidgets(
      'CC older real route refresh cannot supersede newer physical latest $width',
      (tester) async {
        await tester.binding.setSurfaceSize(Size(width, 1800));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = (await tester.runAsync(
          () => _Handoff.start(history: 'known', trackFlights: false),
        ))!;
        addTearDown(f.close);
        final routeApi = _PhysicalApi(f.wire.connection);
        addTearDown(routeApi.close);
        try {
          await tester.pumpWidget(
            MaterialApp(
              localizationsDelegates: AppLocalizations.localizationsDelegates,
              supportedLocales: AppLocalizations.supportedLocales,
              home: ChatScreen(
                connection: f.wire.connection,
                testApiClient: routeApi,
                session: const Session(
                  id: 'stored',
                  title: 'Canonical',
                  model: 'fixture',
                  source: 'test',
                  messageCount: 1,
                  isActive: false,
                  preview: '',
                  startedAt: 1,
                ),
                turnApplicationController: f.controller,
                testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
              ),
            ),
          );
          await widgetUntil(
            tester,
            () => f.canonical.snapshot.historyRows.isNotEmpty,
          );
          final mounted = tester.state(find.byType(ChatScreen));
          send(f.canonical, 'Donor prompt').ignore();
          await widgetUntil(tester, () => f.wire.prompts.length == 1);
          f.wire.finishReceived('Donor answer', failed: true);
          await widgetUntil(tester, () => !f.canonical.snapshot.hasActiveTurn);
          f.wire.releaseCreate();
          await widgetUntil(tester, () => f.wire.prompts.length == 2);
          f.wire.rows
            ..clear()
            ..addAll([
              _row(37, 'Old context'),
              _row(98, 'Donor prompt', role: 'user'),
              _row(99, 'Stored donor partial'),
              _row(100, 'Original prompt', role: 'user'),
              _row(101, 'Current canonical answer'),
            ]);
          f.wire.finishReceived('Current wire answer');
          await widgetUntil(
            tester,
            () =>
                !f.source.snapshot.hasActiveTurn &&
                f.source.snapshot.historyRows.last['id'] == 101,
          );
          await widgetUntil(
            tester,
            () => find
                .text('Current canonical answer', findRichText: true)
                .evaluate()
                .isNotEmpty,
          );
          // A real ChatScreen Refresh starts and captures the older latest rows.
          f.wire.holdNext = true;
          await tester.tap(find.byTooltip('Chat actions').hitTestable());
          await tester.pumpAndSettle();
          await tester.tap(find.text('Refresh').hitTestable());
          await widgetUntil(tester, () => f.wire.held.isCompleted);
          // A later physical HTTP GET succeeds; the owner accepts and renders it.
          f.wire.rows.addAll([
            _row(102, 'Other client prompt', role: 'user'),
            _row(103, 'Other client answer'),
          ]);
          final fresh = (await tester.runAsync(
            () => f.api!.getMessages('stored', latest: true),
          ))!;
          f.source.observeHistory(fresh);
          await tester.pump();
          expect(f.source.snapshot.historyRows.last['id'], 103);
          expect(
            f.source.snapshot.historyRows.map((r) => r['content']),
            contains('Other client answer'),
          );
          // Return the earlier route GET only after the newer accepted snapshot.
          f.wire.releaseHistory();
          await widgetUntil(
            tester,
            () => routeApi.completed == routeApi.flights.length,
          );
          await widgetUntil(tester, () => f.wire.heldDelivered.isCompleted);
          await tester.pump();
          await widgetUntil(
            tester,
            () => find.byType(CircularProgressIndicator).evaluate().isEmpty,
          );
          await tester.pump();
          expect(tester.state(find.byType(ChatScreen)), same(mounted));
          final s = f.source.snapshot;
          final presented = [
            ...s.historyRows,
            ...s.displayRows,
          ].map((r) => r['content']).toList();
          debugPrint(
            'CC_ROUTE_REQUEST_START width=$width accepted=${s.historyRows.map((r) => r['id']).toList()} presented=$presented',
          );
          expect(
            s.historyRows.last['id'],
            103,
            reason:
                'read authority must originate at the physical request start, not observeHistory arrival; this is the real ChatScreen fetch caller',
          );
          expect(presented, contains('Other client answer'));
          expect(
            find.text('Other client answer', findRichText: true),
            findsOneWidget,
          );
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await tester.runAsync(f.close);
          await tester.pump(const Duration(seconds: 16));
        }
      },
    );
  }
}

Map<String, dynamic> _row(int id, String text, {String role = 'assistant'}) => {
  'id': id,
  'role': role,
  'content': text,
};

class _Handoff {
  _Handoff(this.wire, this.controller);
  final _HistoryServer wire;
  final GatewayTurnApplicationController controller;
  late NormalGatewayApplicationSession session;
  late NormalGatewayChatOwner source;
  late NormalGatewayChatOwner canonical;
  final flights = <Future<List<Map<String, dynamic>>>>[];
  ApiClient? api;
  Future<void>? original;
  static Future<_Handoff> start({
    required String history,
    bool trackFlights = true,
  }) async {
    final f = _Handoff(
      await _HistoryServer.start(),
      GatewayTurnApplicationController(),
    );
    f.api = ApiClient(baseUrl: f.wire.connection.baseUrl, apiKey: 'fixture');
    // The optional seam tracks, but does not reorder or synthesize, actual
    // ApiClient HTTP flights. DesktopGatewayClient still owns stock wire I/O.
    f.session = trackFlights
        ? NormalGatewayApplicationSession(
            connection: f.wire.connection,
            scope: 'received-history',
            client: DesktopGatewayClient.fromConnection(f.wire.connection),
            history: (id) {
              final flight = f.api!.getMessages(id, limit: 50, latest: true);
              f.flights.add(flight);
              return flight;
            },
          )
        : f.controller.normalSessionFor(f.wire.connection);
    await f.session.ready;
    f.source = f.session.chatFor('local', title: 'Original');
    f.original = send(f.source, 'Original prompt')..ignore();
    await f.wire.createEntered.future;
    if (history == 'known') f.wire.rows.add(_row(37, 'Old context'));
    f.wire.historyUnavailable = history == 'unavailable';
    f.canonical = f.session.chatFor(
      'stored',
      storedSessionId: 'stored',
      title: 'Canonical',
    );
    try {
      f.canonical.observeHistory(
        await f.api!.getMessages('stored', latest: true),
      );
    } catch (_) {
      expect(history, 'unavailable');
    }
    return f;
  }

  Future<void> settleDonor({bool failed = false}) async {
    final sending = send(canonical, 'Donor prompt')..ignore();
    await wire.untilPrompts(1);
    wire.event('message.start', {}, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'Before tool'}, turnId: 'wire-1');
    wire.event('tool.start', {
      'tool': 'read_file',
      'tool_id': 'donor-tool',
    }, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'After tool'}, turnId: 'wire-1');
    wire.finishReceived('Donor answer', failed: failed);
    await sending;
    await until(() => !canonical.snapshot.hasActiveTurn && wire.reads >= 2);
    if (!wire.isHolding && flights.isNotEmpty) {
      await flights.last.catchError((Object _) => <Map<String, dynamic>>[]);
      await pumpEventQueue();
    }
  }

  Future<void> close() async {
    wire.releaseHistory();
    await session.close();
    await controller.close();
    api?.close();
    await wire.close();
    await original;
  }
}

class _HistoryServer extends BindingServer {
  _HistoryServer(super.server);
  int reads = 0;
  bool holdNext = false;
  int heldStatus = 200;
  final held = Completer<void>();
  final heldDelivered = Completer<void>();
  Completer<void>? _gate;
  bool get isHolding => _gate != null && !_gate!.isCompleted;
  static Future<_HistoryServer> start() async {
    final f = _HistoryServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    f.server.listen(f.handle);
    return f;
  }

  @override
  Future<void> handle(HttpRequest request) async {
    if (request.uri.path.endsWith('/messages')) {
      reads++;
      if (holdNext) {
        holdNext = false;
        _gate = Completer<void>();
        final captured = jsonEncode({'data': rows});
        held.complete();
        await _gate!.future;
        request.response.headers.contentType = ContentType.json;
        request.response.statusCode = heldStatus;
        request.response.write(captured);
        await request.response.close();
        heldDelivered.complete();
        return;
      }
    }
    return super.handle(request);
  }

  void releaseHistory() {
    if (isHolding) _gate!.complete();
  }

  void finishReceived(String text, {bool failed = false}) {
    running = false;
    final turn = 'wire-${prompts.length}';
    event('message.start', {}, turnId: turn);
    event('message.delta', {'text': text}, turnId: turn);
    event('message.complete', {'text': text}, turnId: turn);
    event(
      failed ? 'turn.error' : 'turn.end',
      failed ? {'status': 'failed', 'message': 'Interrupted donor'} : {},
      turnId: turn,
    );
  }
}

// Observes real ApiClient futures only; no response or ordering substitution.
class _PhysicalApi extends ApiClient {
  _PhysicalApi(SavedConnection connection)
    : super(baseUrl: connection.baseUrl, apiKey: 'fixture');
  final flights = <Future<List<Map<String, dynamic>>>>[];
  int completed = 0;
  @override
  Future<List<Map<String, dynamic>>> getMessages(
    String sessionId, {
    int? limit,
    int offset = 0,
    bool latest = false,
  }) {
    final flight = super.getMessages(
      sessionId,
      limit: limit,
      offset: offset,
      latest: latest,
    );
    flights.add(flight);
    flight.then((_) => completed++, onError: (Object _) => completed++);
    return flight;
  }
}
