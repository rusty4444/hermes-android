// UNRECONCILED POLICY COPY. Raw /Volumes/Storage/Hermes/scratch/p2a-unreconciled-_flkt2h9/raw/independent_spec_77413_adverse_test.dart.source
// SHA256 842fba03b54d2c9cbfaf67c6234c2996d88daf81d654e00c486994c9e8d28637; original unchanged; exact diff in policy evidence.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/widgets/gateway_insight_card.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/desktop_gateway_client.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/core/services/ws_client.dart';
import 'package:hermes_android/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, send, until, widgetUntil;
import 'support/fake_voice_composer_adapter.dart';

// Fresh independent SPEC schedules. Transport plumbing below is reused from
// the permanent fixture; these schedules and assertions are not producer cases.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          (_) async => null,
        );
  });
  tearDown(() {
    HttpOverrides.global = previous;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          null,
        );
  });

  for (final extra in ['later-user', 'late-refresh']) {
    test(
      'FRESH known failed donor preserves complete current canonical suffix $extra',
      () async {
        final f = await _Handoff.start(history: 'known');
        addTearDown(f.close);
        await f.settleDonor(failed: true);
        f.wire.releaseCreate();
        await f.wire.untilPrompts(2);
        f.wire.rows
          ..clear()
          ..addAll([
            _row(37, 'Old context'),
            _row(98, 'Donor prompt', role: 'user'),
            _row(99, 'Stored donor partial'),
            _row(100, 'Original prompt', role: 'user'),
            _row(101, 'Current canonical answer'),
            if (extra == 'later-user') ...[
              _row(102, 'Other client prompt', role: 'user'),
              _row(103, 'Other client answer'),
            ],
          ]);
        f.wire.finishReceived('Current wire answer');
        await until(() => !f.source.snapshot.hasActiveTurn);
        await f.flights.last;
        await pumpEventQueue();
        if (extra == 'late-refresh') {
          expect(
            f.source.snapshot.historyRows.map((r) => r['content']),
            contains('Current canonical answer'),
          );
          f.wire.rows.addAll([
            _row(102, 'Other client prompt', role: 'user'),
            _row(103, 'Other client answer'),
          ]);
          f.source.observeHistory(
            await f.api!.getMessages('stored', latest: true),
          );
        }
        final s = f.source.snapshot;
        expect(_contents(s), contains('Current wire answer'));
        final presented = [
          ...s.historyRows,
          ...s.displayRows,
        ].map((r) => r['content']).toList();
        debugPrint(
          'FRESH_SUFFIX $extra history=${s.historyRows} presented=$presented',
        );
        expect(s.historyRows.map((r) => r['id']), [
          37,
          98,
          99,
          100,
          101,
          102,
          103,
        ]);
        expect(
          s.displayRows.where((r) => r['content'] == 'Donor prompt'),
          hasLength(1),
        );
        expect(
          s.historyRows.where((r) => r['content'] == 'Donor prompt'),
          hasLength(1),
        );
        expect(presented, contains('Donor answer'));
        expect(
          s.displayRows.where((r) => r['content'] == 'Original prompt'),
          hasLength(1),
        );
        expect(
          s.historyRows.where((r) => r['content'] == 'Original prompt'),
          hasLength(1),
        );
        expect(
          presented,
          contains('Current canonical answer'),
          reason:
              'a later durable user must not truncate the already-identified current answer behind a retained failed donor',
        );
        expect(
          presented,
          contains('Other client answer'),
          reason:
              'a fresh successful latest observation must remain presentable after current projection retirement',
        );
        expect(f.wire.prompts.map((r) => r['text']), [
          'Donor prompt',
          'Original prompt',
        ]);
      },
    );
  }

  for (final width in [400.0, 1000.0]) {
    testWidgets(
      'FRESH same mounted donor reasoning keeps manual expansion $width',
      (tester) async {
        await tester.binding.setSurfaceSize(Size(width, 1800));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = (await tester.runAsync(
          () => _Handoff.start(history: 'known', trackFlights: false),
        ))!;
        addTearDown(f.close);
        try {
          await tester.pumpWidget(
            MaterialApp(
              localizationsDelegates: AppLocalizations.localizationsDelegates,
              supportedLocales: AppLocalizations.supportedLocales,
              home: ChatScreen(
                connection: f.wire.connection,
                session: const Session(
                  id: 'stored',
                  title: 'Canonical',
                  model: 'fixture',
                  source: 'test',
                  messageCount: 1,
                  isActive: false,
                  preview: '',
                  startedAt: 1,
                ),
                turnApplicationController: f.controller,
                testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
              ),
            ),
          );
          await widgetUntil(
            tester,
            () => f.canonical.snapshot.historyRows.isNotEmpty,
          );
          final mounted = tester.state(find.byType(ChatScreen));
          send(f.canonical, 'Donor prompt').ignore();
          await widgetUntil(tester, () => f.wire.prompts.length == 1);
          f.wire.event('message.start', {}, turnId: 'wire-1');
          f.wire.event('reasoning.delta', {
            'text': 'Manual reasoning',
          }, turnId: 'wire-1');
          f.wire.finishReceived('Donor answer');
          await widgetUntil(tester, () => !f.canonical.snapshot.hasActiveTurn);
          await widgetUntil(
            tester,
            () => find.byType(GatewayReasoningCard).evaluate().isNotEmpty,
          );
          Finder tile() => find.descendant(
            of: find.byType(GatewayReasoningCard),
            matching: find.byType(ExpansionTile),
          );
          bool expanded() =>
              tester.widget<ExpansionTile>(tile()).controller!.isExpanded;
          expect(expanded(), isFalse);
          await tester.tap(find.text('Reasoning'));
          await tester.pump(const Duration(milliseconds: 300));
          expect(expanded(), isTrue);
          final before = tester
              .widget<GatewayReasoningCard>(find.byType(GatewayReasoningCard))
              .id;
          f.wire.releaseCreate();
          await widgetUntil(tester, () => f.wire.prompts.length == 2);
          await tester.pump();
          expect(tester.state(find.byType(ChatScreen)), same(mounted));
          final after = tester
              .widget<GatewayReasoningCard>(find.byType(GatewayReasoningCard))
              .id;
          final donorExpanded = expanded();
          f.wire.event('reasoning.delta', {
            'text': 'Independent current reasoning',
          }, turnId: 'wire-2');
          await widgetUntil(
            tester,
            () => find.byType(GatewayReasoningCard).evaluate().length == 2,
          );
          final currentTile = find.descendant(
            of: find.byWidgetPredicate(
              (w) =>
                  w is GatewayReasoningCard &&
                  w.text == 'Independent current reasoning',
            ),
            matching: find.byType(ExpansionTile),
          );
          final currentExpanded = tester
              .widget<ExpansionTile>(currentTile)
              .controller!
              .isExpanded;
          debugPrint(
            'FRESH_PIN width=$width before=$before after=$after donorExpanded=$donorExpanded currentExpanded=$currentExpanded',
          );
          expect(
            [donorExpanded, currentExpanded],
            [true, false],
            reason:
                'same mounted route must retain the donor reasoning pin without lending it to an independent current scope',
          );
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await tester.runAsync(f.close);
          await tester.pump(const Duration(seconds: 16));
        }
      },
    );
  }

  for (final width in [400.0, 1000.0]) {
    testWidgets(
      'FRESH mounted current answer survives later-user canonical hydration $width',
      (tester) async {
        await tester.binding.setSurfaceSize(Size(width, 1800));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final f = (await tester.runAsync(
          () => _Handoff.start(history: 'known', trackFlights: false),
        ))!;
        addTearDown(f.close);
        try {
          await tester.pumpWidget(
            MaterialApp(
              localizationsDelegates: AppLocalizations.localizationsDelegates,
              supportedLocales: AppLocalizations.supportedLocales,
              home: ChatScreen(
                connection: f.wire.connection,
                session: const Session(
                  id: 'stored',
                  title: 'Canonical',
                  model: 'fixture',
                  source: 'test',
                  messageCount: 1,
                  isActive: false,
                  preview: '',
                  startedAt: 1,
                ),
                turnApplicationController: f.controller,
                testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
              ),
            ),
          );
          await widgetUntil(
            tester,
            () => f.canonical.snapshot.historyRows.isNotEmpty,
          );
          final mounted = tester.state(find.byType(ChatScreen));
          send(f.canonical, 'Donor prompt').ignore();
          await widgetUntil(tester, () => f.wire.prompts.length == 1);
          f.wire.finishReceived('Donor answer', failed: true);
          await widgetUntil(tester, () => !f.canonical.snapshot.hasActiveTurn);
          f.wire.releaseCreate();
          await widgetUntil(tester, () => f.wire.prompts.length == 2);
          f.wire.event('message.start', {}, turnId: 'wire-2');
          f.wire.event('message.delta', {
            'text': 'Current wire answer',
          }, turnId: 'wire-2');
          await widgetUntil(
            tester,
            () => find
                .text('Current wire answer', findRichText: true)
                .evaluate()
                .isNotEmpty,
          );
          expect(
            find.text('Current wire answer', findRichText: true),
            findsOneWidget,
          );
          f.wire.rows
            ..clear()
            ..addAll([
              _row(37, 'Old context'),
              _row(98, 'Donor prompt', role: 'user'),
              _row(99, 'Stored donor partial'),
              _row(100, 'Original prompt', role: 'user'),
              _row(101, 'Current canonical answer'),
              _row(102, 'Other client prompt', role: 'user'),
              _row(103, 'Other client answer'),
            ]);
          f.wire.holdNext = true;
          f.wire.finishReceived('Current wire answer');
          await widgetUntil(tester, () => f.wire.held.isCompleted);
          await widgetUntil(tester, () => !f.source.snapshot.hasActiveTurn);
          f.wire.releaseHistory();
          await widgetUntil(
            tester,
            () => f.source.snapshot.historyRows.last['id'] == 103,
          );
          await tester.pump();
          expect(tester.state(find.byType(ChatScreen)), same(mounted));
          expect(
            f.source.snapshot.historyRows.any(
              (r) => r['content'] == 'Current canonical answer',
            ),
            isTrue,
          );
          debugPrint(
            'FRESH_MOUNTED_HYDRATION width=$width wire=${find.text('Current wire answer', findRichText: true).evaluate().length} canonical=${find.text('Current canonical answer', findRichText: true).evaluate().length} display=${f.source.snapshot.displayRows}',
          );
          expect(
            find.text('Current canonical answer', findRichText: true),
            findsOneWidget,
            reason:
                'identified canonical current turn must replace, not erase, the current received answer when another durable user follows it',
          );
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await tester.runAsync(f.close);
          await tester.pump(const Duration(seconds: 16));
        }
      },
    );
  }

  for (final oldFails in [false, true]) {
    test(
      'FRESH old owned GET vs later failed/success lower-id read oldFails=$oldFails',
      () async {
        final f = await _Handoff.start(history: 'known');
        addTearDown(f.close);
        f.wire.heldStatus = oldFails ? 503 : 200;
        f.wire.holdNext = true;
        final settling = f.settleDonor();
        await f.wire.held.future;
        await settling;
        final oldFlight = f.flights.last;
        if (oldFails) {
          f.wire.rows
            ..clear()
            ..add(_row(7, 'Fresh compressed'));
          f.canonical.observeHistory(
            await f.api!.getMessages('stored', latest: true),
          );
        } else {
          f.wire.historyUnavailable = true;
          await expectLater(
            f.api!.getMessages('stored', latest: true),
            throwsA(isA<Object>()),
          );
          f.wire.historyUnavailable = false;
        }
        f.wire.releaseHistory();
        await oldFlight.catchError((Object _) => <Map<String, dynamic>>[]);
        await pumpEventQueue();
        expect(f.canonical.snapshot.historyRows.last['id'], oldFails ? 7 : 37);
        f.wire.releaseCreate();
        await f.wire.untilPrompts(2);
        expect(f.source.snapshot.rowFloor, oldFails ? 7 : 37);
        expect(
          (await f.session.pendingStore.load(f.session.scope)).single.rowFloor,
          oldFails ? 7 : 37,
        );
      },
    );
  }

  test(
    'FRESH qualified rejection callback unsubscribe prevents later delivery',
    () async {
      final s = _ownerSession();
      addTearDown(s.close);
      await s.ready;
      final source = s.chatFor('local', title: 'Source');
      final canonical = s.chatFor(
        'stored',
        storedSessionId: 'stored',
        title: 'Canonical',
      );
      source.reserve();
      canonical.reserve();
      Object? second;
      source.subscribe((snap) {
        if (snap.phase == NormalGatewayTurnPhase.failed) {
          source.unsubscribe(second!);
        }
      });
      final seen = <NormalGatewayTurnPhase>[];
      second = source.subscribe((snap) => seen.add(snap.phase));
      source.bindStoredSession('stored');
      seen.clear();
      await pumpEventQueue();
      expect(seen, isEmpty);
    },
  );
}

Iterable<String> _contents(NormalGatewayChatSnapshot s) =>
    s.displayRows.map((r) => r['content']?.toString() ?? '');
Map<String, dynamic> _row(int id, String text, {String role = 'assistant'}) => {
  'id': id,
  'role': role,
  'content': text,
};

NormalGatewayApplicationSession _ownerSession() =>
    NormalGatewayApplicationSession(
      connection: SavedConnection(
        id: 'owner-seam',
        label: 'Fixture',
        host: 'fixture.invalid',
        port: 8642,
        apiKey: 'fixture',
      ),
      scope: 'owner-seam',
      history: (_) async => [],
      resume: ({required localSessionId, required storedSessionId}) async =>
          const ResumedGatewaySession(
            runtimeSessionId: 'runtime',
            running: true,
          ),
      submit:
          ({
            required sessionId,
            required text,
            required onEvent,
            required onSent,
          }) async {},
    );

class _Handoff {
  _Handoff(this.wire, this.controller);
  final _HistoryServer wire;
  final GatewayTurnApplicationController controller;
  late NormalGatewayApplicationSession session;
  late NormalGatewayChatOwner source;
  late NormalGatewayChatOwner canonical;
  final flights = <Future<List<Map<String, dynamic>>>>[];
  ApiClient? api;
  Future<void>? original;
  static Future<_Handoff> start({
    required String history,
    bool trackFlights = true,
  }) async {
    final f = _Handoff(
      await _HistoryServer.start(),
      GatewayTurnApplicationController(),
    );
    f.api = ApiClient(baseUrl: f.wire.connection.baseUrl, apiKey: 'fixture');
    // The optional seam tracks, but does not reorder or synthesize, actual
    // ApiClient HTTP flights. DesktopGatewayClient still owns stock wire I/O.
    f.session = trackFlights
        ? NormalGatewayApplicationSession(
            connection: f.wire.connection,
            scope: 'received-history',
            client: DesktopGatewayClient.fromConnection(f.wire.connection),
            history: (id) {
              final flight = f.api!.getMessages(id, limit: 50, latest: true);
              f.flights.add(flight);
              return flight;
            },
          )
        : f.controller.normalSessionFor(f.wire.connection);
    await f.session.ready;
    f.source = f.session.chatFor('local', title: 'Original');
    f.original = send(f.source, 'Original prompt')..ignore();
    await f.wire.createEntered.future;
    if (history == 'known') f.wire.rows.add(_row(37, 'Old context'));
    f.wire.historyUnavailable = history == 'unavailable';
    f.canonical = f.session.chatFor(
      'stored',
      storedSessionId: 'stored',
      title: 'Canonical',
    );
    try {
      f.canonical.observeHistory(
        await f.api!.getMessages('stored', latest: true),
      );
    } catch (_) {
      expect(history, 'unavailable');
    }
    return f;
  }

  Future<void> settleDonor({bool failed = false}) async {
    final sending = send(canonical, 'Donor prompt')..ignore();
    await wire.untilPrompts(1);
    wire.event('message.start', {}, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'Before tool'}, turnId: 'wire-1');
    wire.event('tool.start', {
      'tool': 'read_file',
      'tool_id': 'donor-tool',
    }, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'After tool'}, turnId: 'wire-1');
    wire.finishReceived('Donor answer', failed: failed);
    await sending;
    await until(() => !canonical.snapshot.hasActiveTurn && wire.reads >= 2);
    if (!wire.isHolding && flights.isNotEmpty) {
      await flights.last.catchError((Object _) => <Map<String, dynamic>>[]);
      await pumpEventQueue();
    }
  }

  Future<void> close() async {
    wire.releaseHistory();
    await session.close();
    await controller.close();
    api?.close();
    await wire.close();
    await original;
  }
}

class _HistoryServer extends BindingServer {
  _HistoryServer(super.server);
  int reads = 0;
  bool holdNext = false;
  int heldStatus = 200;
  final held = Completer<void>();
  Completer<void>? _gate;
  bool get isHolding => _gate != null && !_gate!.isCompleted;
  static Future<_HistoryServer> start() async {
    final f = _HistoryServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    f.server.listen(f.handle);
    return f;
  }

  @override
  Future<void> handle(HttpRequest request) async {
    if (request.uri.path.endsWith('/messages')) {
      reads++;
      if (holdNext) {
        holdNext = false;
        _gate = Completer<void>();
        final captured = jsonEncode({'data': rows});
        held.complete();
        await _gate!.future;
        request.response.headers.contentType = ContentType.json;
        request.response.statusCode = heldStatus;
        request.response.write(captured);
        await request.response.close();
        return;
      }
    }
    return super.handle(request);
  }

  void releaseHistory() {
    if (isHolding) _gate!.complete();
  }

  void finishReceived(String text, {bool failed = false}) {
    running = false;
    final turn = 'wire-${prompts.length}';
    event('message.start', {}, turnId: turn);
    event('message.delta', {'text': text}, turnId: turn);
    event('message.complete', {'text': text}, turnId: turn);
    event(
      failed ? 'turn.error' : 'turn.end',
      failed ? {'status': 'failed', 'message': 'Interrupted donor'} : {},
      turnId: turn,
    );
  }
}
