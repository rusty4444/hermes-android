import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/android_launch_intent_service.dart';
import 'package:hermes_android/core/services/android_share_intent_service.dart';
import 'package:hermes_android/core/services/config_backup.dart';
import 'package:hermes_android/core/services/config_backup_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'independent_push_quality_edit_race_test.dart'
    show GatedSecrets, WriteGate;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  const secure = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  const share = MethodChannel(AndroidShareIntentService.channelName);
  const launch = MethodChannel(AndroidLaunchIntentService.channelName);
  tearDown(() {
    messenger.setMockMethodCallHandler(secure, null);
    messenger.setMockMethodCallHandler(share, null);
    messenger.setMockMethodCallHandler(launch, null);
  });

  test(
    'production secure-store wrappers refresh cold/stale caches and evict physical null',
    () async {
      final physical = <String, String>{};
      messenger.setMockMethodCallHandler(secure, (call) async {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        final key = args['key'] as String;
        switch (call.method) {
          case 'read':
            return physical[key];
          case 'write':
            physical[key] = args['value'] as String;
            return null;
          case 'delete':
            physical.remove(key);
            return null;
          default:
            throw StateError(call.method);
        }
      });
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final firstStore = FlutterSecureCredentialStore();
      final first = ConnectionManager(prefs, credentialStore: firstStore);
      await first.saveConnection(
        'Synthetic',
        'fixture.invalid',
        443,
        'first-key',
      );
      final id = first.getConnections().single.id;
      final secondStore = FlutterSecureCredentialStore();
      final second = ConnectionManager(prefs, credentialStore: secondStore);
      expect(second.getConnections().single.apiKey, isEmpty);
      await second.refreshConnectionCredentials(id);
      expect(second.getConnections().single.apiKey, 'first-key');
      await first.updateApiKey(id, 'replacement-key');
      expect(second.getConnections().single.apiKey, 'first-key');
      await second.refreshConnectionCredentials(id);
      expect(second.getConnections().single.apiKey, 'replacement-key');
      await first.updateApiKey(id, '');
      expect(physical, isEmpty);
      await second.refreshConnectionCredentials(id);
      expect(second.getConnections().single.apiKey, isEmpty);
    },
  );

  test(
    'real config import cannot bypass owned connection transaction through preference allowlist',
    () async {
      SharedPreferences.setMockInitialValues({'unrelated': 'keep'});
      final prefs = await SharedPreferences.getInstance();
      final secrets = GatedSecrets();
      final manager = ConnectionManager(prefs, credentialStore: secrets);
      await manager.saveConnection('A', 'a.invalid', 443, 'a-key');
      final a = manager.getConnections().single;
      final gate = WriteGate();
      secrets.gates.add(gate);
      final edit = manager.updateApiKey(a.id, 'owned-current-key');
      await gate.entered.future;
      final backup = ConfigBackup(
        createdAt: DateTime.fromMillisecondsSinceEpoch(0),
        appVersion: 'fixture',
        connections: [a.copyWith(label: 'imported-A')],
        preferences: {
          'saved_connections': <String>['must-not-be-written'],
          'theme_mode': 'dark',
        },
      );
      final service = ConfigBackupService(
        connectionManager: ConnectionManager(prefs, credentialStore: secrets),
        preferences: prefs,
      );
      var finished = false;
      final import = service.import(backup, mode: ConfigImportMode.merge).then((
        x,
      ) {
        finished = true;
        return x;
      });
      await Future<void>.value();
      expect(finished, isFalse);
      gate.release.complete();
      await edit;
      final result = await import;
      expect(result.preferencesSkipped, 1);
      expect(result.preferencesApplied, 1);
      expect(manager.getConnections().single.label, 'imported-A');
      expect(
        prefs.getStringList('saved_connections')!.single,
        isNot('must-not-be-written'),
      );
      expect(prefs.getString('theme_mode'), 'dark');
      expect(prefs.getString('unrelated'), 'keep');
      final exported = await service.export(appVersion: 'fixture');
      expect(exported.preferences.containsKey('saved_connections'), isFalse);
      expect(exported.connections.single.id, a.id);
      expect(exported.connections.single.apiKey, a.apiKey);
    },
  );

  for (final damage in ['json', 'type']) {
    testWidgets(
      'real startup recovery resets $damage metadata only and mounts hydrated Home',
      (tester) async {
        SharedPreferences.setMockInitialValues({
          'saved_connections': damage == 'json'
              ? <String>['invalid-json']
              : 'invalid-type',
          'unrelated': 'keep',
        });
        final secrets = GatedSecrets();
        secrets.values['unreferenced-fixture-secret'] = jsonEncode({
          'api_key': 'preserve',
        });
        final before = Map<String, String>.of(secrets.values);
        messenger.setMockMethodCallHandler(share, (_) async => null);
        messenger.setMockMethodCallHandler(launch, (_) async => null);
        var tries = 0;
        await tester.pumpWidget(
          StartupApp(
            createConnectionManager: (prefs) {
              tries++;
              return ConnectionManager.create(prefs, credentialStore: secrets);
            },
          ),
        );
        expect(find.byType(CircularProgressIndicator), findsOneWidget);
        await tester.pumpAndSettle();
        expect(find.byType(HermesApp), findsNothing);
        expect(find.text('Reset saved connections'), findsOneWidget);
        await tester.tap(find.text('Reset saved connections'));
        await tester.pumpAndSettle();
        expect(tries, 2);
        expect(find.byType(HermesApp), findsOneWidget);
        final prefs = await SharedPreferences.getInstance();
        expect(prefs.get('saved_connections'), isNull);
        expect(prefs.getString('unrelated'), 'keep');
        expect(secrets.values, before);
        final home = tester.widget<HomeScreen>(find.byType(HomeScreen));
        expect(home.connManager.getConnections(), isEmpty);
        await tester.pumpWidget(const SizedBox.shrink());
      },
    );
  }
}
