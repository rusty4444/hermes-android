// UNRECONCILED POLICY COPY. Raw /Volumes/Storage/Hermes/scratch/p2a-unreconciled-_flkt2h9/raw/history_authority_ambiguity_counterexample_test.dart.source
// SHA256 02a34c949b48a2681e7115f3bc737797013acac2de5eae6f02ee94c1687bff28; original unchanged; exact diff in policy evidence.
import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/desktop_gateway_client.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, send, until;

// Policy-adapted original diagnostic. The actual HTTP/WS inputs are unchanged;
// the two hidden provenance assignments must yield the same truthful C/R view.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() => HttpOverrides.global = previous);

  test('indistinguishable donor-versus-unrelated row provenance', () async {
    final donorPersisted = await _observeWorld();
    final donorMissing = await _observeWorld();
    expect(donorMissing, donorPersisted);
    final canonical = donorPersisted['canonical']! as List;
    expect(canonical.map((row) => (row as Map)['id']), [
      37,
      98,
      99,
      100,
      101,
      102,
      103,
    ]);
    // C includes every accepted row, followed separately by both received
    // scopes. Neither hidden provenance assignment changes this projection.
    expect(donorPersisted['presented'], [
      'Old context',
      'Donor prompt',
      'Canonical partial',
      'Current prompt',
      'Current canonical',
      'Later prompt',
      'Later answer',
      'Donor prompt',
      'Donor received',
      'Current prompt',
      'Current received',
    ]);
    // Equally valid provenance: donor persisted neither user nor assistant;
    // another client submitted identical text at 98/99. Complete accepted
    // later history now requires 98/99, in addition to the retained donor.
    // Repeated text is legal, and neither matching it nor counting roles is
    // correlation. The old raw diagnostic fails on cc009ac; this policy retains99.
    expect(
      donorMissing['presented'],
      contains('Canonical partial'),
      reason:
          'row99 is an unrelated client answer in the second world; '
          'the captured correlation-relevant observations equal the first world',
    );
  });
}

Future<Map<String, Object?>> _observeWorld() async {
  SharedPreferences.setMockInitialValues({});
  final server = await BindingServer.start();
  final api = ApiClient(baseUrl: server.connection.baseUrl, apiKey: 'fixture');
  final flights = <Future<List<Map<String, dynamic>>>>[];
  final session = NormalGatewayApplicationSession(
    connection: server.connection,
    scope: 'ambiguity',
    client: DesktopGatewayClient.fromConnection(server.connection),
    history: (id) {
      final flight = api.getMessages(id, limit: 50, latest: true);
      flights.add(flight);
      return flight;
    },
  );
  Future<void>? original;
  try {
    await session.ready;
    final source = session.chatFor('local', title: 'Original');
    original = send(source, 'Current prompt')..ignore();
    await server.createEntered.future;
    server.rows.add(_row(37, 'Old context'));
    final canonical = session.chatFor(
      'stored',
      storedSessionId: 'stored',
      title: 'Canonical',
    );
    canonical.observeHistory(await api.getMessages('stored', latest: true));
    final donor = send(canonical, 'Donor prompt')..ignore();
    await server.untilPrompts(1);
    server.event('message.start', {}, turnId: 'wire-1');
    server.event('reasoning.delta', {
      'text': 'Donor reasoning',
    }, turnId: 'wire-1');
    server.event('tool.start', {
      'tool': 'read_file',
      'tool_id': 'donor-tool',
    }, turnId: 'wire-1');
    server.event('message.delta', {'text': 'Donor received'}, turnId: 'wire-1');
    server.running = false;
    server.event('turn.error', {'message': 'failed'}, turnId: 'wire-1');
    await donor;
    await until(() => !canonical.snapshot.hasActiveTurn && flights.isNotEmpty);
    await flights.last;
    await pumpEventQueue();
    final donorFloor = canonical.snapshot.rowFloor;
    server.releaseCreate();
    await server.untilPrompts(2);
    final currentFloor = source.snapshot.rowFloor;
    server.rows
      ..clear()
      ..addAll([
        _row(37, 'Old context'),
        _row(98, 'Donor prompt', role: 'user'),
        _row(99, 'Canonical partial'),
        _row(100, 'Current prompt', role: 'user'),
        _row(101, 'Current canonical'),
        _row(102, 'Later prompt', role: 'user'),
        _row(103, 'Later answer'),
      ]);
    server.event('message.start', {}, turnId: 'wire-2');
    server.event('message.delta', {
      'text': 'Current received',
    }, turnId: 'wire-2');
    server.event('message.complete', {
      'text': 'Current received',
    }, turnId: 'wire-2');
    server.running = false;
    server.event('turn.end', {}, turnId: 'wire-2');
    await original;
    await until(() => !source.snapshot.hasActiveTurn && flights.length >= 2);
    await flights.last;
    await until(() => source.snapshot.historyRows.length == 7);
    final snapshot = source.snapshot;
    final result = <String, Object?>{
      'donorFloor': donorFloor,
      'currentFloor': currentFloor,
      'wirePrompts': server.prompts,
      'canonical': snapshot.historyRows,
      'presented': [
        ...snapshot.historyRows,
        ...snapshot.displayRows,
      ].map((row) => row['content']).toList(),
      'tools': snapshot.tools.map((tool) => tool.toolId).toList(),
      'reasoning': snapshot.timeline.runs.map((run) => run.text).toList(),
    };
    debugPrint('AMBIGUITY_OBSERVED $result');
    return result;
  } finally {
    await session.close();
    api.close();
    await server.close();
    await original;
  }
}

Map<String, dynamic> _row(
  int id,
  String content, {
  String role = 'assistant',
}) => {'id': id, 'role': role, 'content': content};
