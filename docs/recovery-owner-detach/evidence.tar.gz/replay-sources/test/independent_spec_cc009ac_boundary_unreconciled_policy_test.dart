// UNRECONCILED POLICY COPY. Raw /Volumes/Storage/Hermes/scratch/p2a-unreconciled-_flkt2h9/raw/independent_spec_cc009ac_boundary_test.dart.source
// SHA256 c1fa287e69c1fa786e36dc281a2b9096f2210bcc66154d23a3b5024039b7319b; original unchanged; exact diff in policy evidence.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/desktop_gateway_client.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, send, until, widgetUntil;
import 'support/fake_voice_composer_adapter.dart';
import 'support/unreconciled_policy.dart';
import 'package:hermes_android/core/utils/chat_display_items.dart';

// Independently derived boundary schedules; original nine unchanged.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          (_) async => null,
        );
  });
  tearDown(() {
    HttpOverrides.global = previous;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/image_picker'),
          null,
        );
  });
  for (final laterAtSettlement in [false, true]) {
    test(
      'CC boundary failed donor not persisted must not eat current response later=$laterAtSettlement',
      () async {
        final f = await _Handoff.start(history: 'known');
        addTearDown(f.close);
        await f.settleDonor(failed: true);
        f.wire.releaseCreate();
        await f.wire.untilPrompts(2);
        f.wire.rows
          ..clear()
          ..addAll([
            _row(37, 'Old context'),
            _row(98, 'Donor prompt', role: 'user'),
            // Failed donor has received material but no persisted assistant row.
            _row(100, 'Original prompt', role: 'user'),
            _row(101, 'Current canonical answer'),
            if (laterAtSettlement) ...[
              _row(102, 'Other client prompt', role: 'user'),
              _row(103, 'Other client answer'),
            ],
          ]);
        f.wire.finishReceived('Current wire answer');
        await until(() => !f.source.snapshot.hasActiveTurn);
        await f.flights.last;
        await pumpEventQueue();
        if (!laterAtSettlement) {
          expect(_contents(f.source.snapshot), contains('Current wire answer'));
          f.wire.rows.addAll([
            _row(102, 'Other client prompt', role: 'user'),
            _row(103, 'Other client answer'),
          ]);
          f.source.observeHistory(
            await f.api!.getMessages('stored', latest: true),
          );
        }
        final s = f.source.snapshot;
        expect(
          s.displayRows.where((r) => r['content'] == 'Current wire answer'),
          hasLength(1),
        );
        final presented = [
          ...s.historyRows,
          ...s.displayRows,
        ].map((r) => r['content']).toList();
        debugPrint(
          'CC_NO_DONOR later=$laterAtSettlement canonical=${s.historyRows} presented=$presented',
        );
        expect(s.historyRows.map((r) => r['id']), [37, 98, 100, 101, 102, 103]);
        expect(presented.where((v) => v == 'Donor answer'), hasLength(1));
        expect(f.wire.prompts.map((p) => p['text']), [
          'Donor prompt',
          'Original prompt',
        ]);
        expect(
          presented,
          contains('Original prompt'),
          reason:
              'a known numeric donor admission floor does not prove any donor response was persisted; never consume current user/answer as its interval',
        );
        expect(
          s.historyRows.where(
            (r) => r['content'] == 'Current canonical answer',
          ),
          hasLength(1),
          reason:
              'uncertain donor persistence must not erase both forms of the current answer',
        );
        expect(presented, contains('Other client answer'));
      },
    );
  }
  for (final width in [400.0, 1000.0]) {
    testWidgets('CC mounted current preserved without persisted donor $width', (
      tester,
    ) async {
      await tester.binding.setSurfaceSize(Size(width, 1800));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final f = (await tester.runAsync(
        () => _Handoff.start(history: 'known', trackFlights: false),
      ))!;
      addTearDown(f.close);
      try {
        await tester.pumpWidget(
          MaterialApp(
            localizationsDelegates: AppLocalizations.localizationsDelegates,
            supportedLocales: AppLocalizations.supportedLocales,
            home: ChatScreen(
              connection: f.wire.connection,
              session: const Session(
                id: 'stored',
                title: 'Canonical',
                model: 'fixture',
                source: 'test',
                messageCount: 1,
                isActive: false,
                preview: '',
                startedAt: 1,
              ),
              turnApplicationController: f.controller,
              testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
            ),
          ),
        );
        await widgetUntil(
          tester,
          () => f.canonical.snapshot.historyRows.isNotEmpty,
        );
        final mounted = tester.state(find.byType(ChatScreen));
        send(f.canonical, 'Donor prompt').ignore();
        await widgetUntil(tester, () => f.wire.prompts.length == 1);
        f.wire.finishReceived('Donor answer', failed: true);
        await widgetUntil(tester, () => !f.canonical.snapshot.hasActiveTurn);
        f.wire.releaseCreate();
        await widgetUntil(tester, () => f.wire.prompts.length == 2);
        f.wire.event('message.start', {}, turnId: 'wire-2');
        f.wire.event('message.delta', {
          'text': 'Current wire answer',
        }, turnId: 'wire-2');
        await widgetUntil(
          tester,
          () => find
              .text('Current wire answer', findRichText: true)
              .evaluate()
              .isNotEmpty,
        );
        expect(
          find.text('Current wire answer', findRichText: true),
          findsOneWidget,
        );
        f.wire.rows
          ..clear()
          ..addAll([
            _row(37, 'Old context'),
            _row(98, 'Donor prompt', role: 'user'),
            _row(100, 'Original prompt', role: 'user'),
            _row(101, 'Current canonical answer'),
            _row(102, 'Other client prompt', role: 'user'),
            _row(103, 'Other client answer'),
          ]);
        f.wire.holdNext = true;
        f.wire.finishReceived('Current wire answer');
        await widgetUntil(tester, () => f.wire.held.isCompleted);
        await widgetUntil(tester, () => !f.source.snapshot.hasActiveTurn);
        f.wire.releaseHistory();
        await widgetUntil(
          tester,
          () => f.source.snapshot.historyRows.last['id'] == 103,
        );
        await tester.pump();
        expect(tester.state(find.byType(ChatScreen)), same(mounted));
        final s = f.source.snapshot;
        expect(
          s.displayRows.where((r) => r['content'] == 'Current wire answer'),
          hasLength(1),
        );
        final presented = [
          ...s.historyRows,
          ...s.displayRows,
        ].map((r) => r['content']).toList();
        debugPrint(
          'CC_MOUNTED_NO_DONOR width=$width visibleWire=${find.text('Current wire answer', findRichText: true).evaluate().length} visibleCanonical=${find.text('Current canonical answer', findRichText: true).evaluate().length} presented=$presented',
        );
        expect(
          s.historyRows.where(
            (r) => r['content'] == 'Current canonical answer',
          ),
          hasLength(1),
          reason:
              'uncertain donor persistence must not erase both forms of the current answer',
        );
        expect(
          inChatSource(
            find.text('Current canonical answer', findRichText: true),
            ChatDisplaySource.canonical,
          ),
          findsOneWidget,
        );
        expect(
          inChatSource(
            find.text('Current wire answer', findRichText: true),
            ChatDisplaySource.received,
          ),
          findsOneWidget,
        );
        expect(find.text('Received · match unconfirmed'), findsWidgets);
      } finally {
        await tester.pumpWidget(const SizedBox.shrink());
        await tester.runAsync(f.close);
        await tester.pump(const Duration(seconds: 16));
      }
    });
  }
}

Iterable<String> _contents(NormalGatewayChatSnapshot s) =>
    s.displayRows.map((r) => r['content']?.toString() ?? '');
Map<String, dynamic> _row(int id, String text, {String role = 'assistant'}) => {
  'id': id,
  'role': role,
  'content': text,
};

class _Handoff {
  _Handoff(this.wire, this.controller);
  final _HistoryServer wire;
  final GatewayTurnApplicationController controller;
  late NormalGatewayApplicationSession session;
  late NormalGatewayChatOwner source;
  late NormalGatewayChatOwner canonical;
  final flights = <Future<List<Map<String, dynamic>>>>[];
  ApiClient? api;
  Future<void>? original;
  static Future<_Handoff> start({
    required String history,
    bool trackFlights = true,
  }) async {
    final f = _Handoff(
      await _HistoryServer.start(),
      GatewayTurnApplicationController(),
    );
    f.api = ApiClient(baseUrl: f.wire.connection.baseUrl, apiKey: 'fixture');
    // The optional seam tracks, but does not reorder or synthesize, actual
    // ApiClient HTTP flights. DesktopGatewayClient still owns stock wire I/O.
    f.session = trackFlights
        ? NormalGatewayApplicationSession(
            connection: f.wire.connection,
            scope: 'received-history',
            client: DesktopGatewayClient.fromConnection(f.wire.connection),
            history: (id) {
              final flight = f.api!.getMessages(id, limit: 50, latest: true);
              f.flights.add(flight);
              return flight;
            },
          )
        : f.controller.normalSessionFor(f.wire.connection);
    await f.session.ready;
    f.source = f.session.chatFor('local', title: 'Original');
    f.original = send(f.source, 'Original prompt')..ignore();
    await f.wire.createEntered.future;
    if (history == 'known') f.wire.rows.add(_row(37, 'Old context'));
    f.wire.historyUnavailable = history == 'unavailable';
    f.canonical = f.session.chatFor(
      'stored',
      storedSessionId: 'stored',
      title: 'Canonical',
    );
    try {
      f.canonical.observeHistory(
        await f.api!.getMessages('stored', latest: true),
      );
    } catch (_) {
      expect(history, 'unavailable');
    }
    return f;
  }

  Future<void> settleDonor({bool failed = false}) async {
    final sending = send(canonical, 'Donor prompt')..ignore();
    await wire.untilPrompts(1);
    wire.event('message.start', {}, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'Before tool'}, turnId: 'wire-1');
    wire.event('tool.start', {
      'tool': 'read_file',
      'tool_id': 'donor-tool',
    }, turnId: 'wire-1');
    wire.event('reasoning.delta', {'text': 'After tool'}, turnId: 'wire-1');
    wire.finishReceived('Donor answer', failed: failed);
    await sending;
    await until(() => !canonical.snapshot.hasActiveTurn && wire.reads >= 2);
    if (!wire.isHolding && flights.isNotEmpty) {
      await flights.last.catchError((Object _) => <Map<String, dynamic>>[]);
      await pumpEventQueue();
    }
  }

  Future<void> close() async {
    wire.releaseHistory();
    await session.close();
    await controller.close();
    api?.close();
    await wire.close();
    await original;
  }
}

class _HistoryServer extends BindingServer {
  _HistoryServer(super.server);
  int reads = 0;
  bool holdNext = false;
  int heldStatus = 200;
  final held = Completer<void>();
  Completer<void>? _gate;
  bool get isHolding => _gate != null && !_gate!.isCompleted;
  static Future<_HistoryServer> start() async {
    final f = _HistoryServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    f.server.listen(f.handle);
    return f;
  }

  @override
  Future<void> handle(HttpRequest request) async {
    if (request.uri.path.endsWith('/messages')) {
      reads++;
      if (holdNext) {
        holdNext = false;
        _gate = Completer<void>();
        final captured = jsonEncode({'data': rows});
        held.complete();
        await _gate!.future;
        request.response.headers.contentType = ContentType.json;
        request.response.statusCode = heldStatus;
        request.response.write(captured);
        await request.response.close();
        return;
      }
    }
    return super.handle(request);
  }

  void releaseHistory() {
    if (isHolding) _gate!.complete();
  }

  void finishReceived(String text, {bool failed = false}) {
    running = false;
    final turn = 'wire-${prompts.length}';
    event('message.start', {}, turnId: turn);
    event('message.delta', {'text': text}, turnId: turn);
    event('message.complete', {'text': text}, turnId: turn);
    event(
      failed ? 'turn.error' : 'turn.end',
      failed ? {'status': 'failed', 'message': 'Interrupted donor'} : {},
      turnId: turn,
    );
  }
}
