// Fresh schedules; reuses prior independent root fixture mechanics.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/screens/workspace_screen.dart';
import 'package:hermes_android/core/services/android_launch_intent_service.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/connection_keepalive_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/connection_mutation_barrier.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/gateway_turn_journal.dart';
import 'package:hermes_android/core/services/mobile_push_service.dart';

import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/main.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart' show BindingServer;
import 'support/memory_turn_journal_store.dart';
import 'support/inert_turn_application_session.dart';
import 'package:hermes_android/core/services/notification_approval_authority.dart';

class _RootServer extends BindingServer {
  _RootServer(super.server);
  static Future<_RootServer> start() async {
    final owner = _RootServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    owner.server.listen(owner.handle);
    return owner;
  }

  final requests = <String>[];
  String expectedApiKey = 'fixture';
  Completer<void>? nextMessagesGate;
  Completer<void>? messagesEntered;
  Completer<void>? nextOlderGate;
  Completer<void>? olderEntered;
  final messageOffsets = <int>[];
  final childRequests = <HttpRequest>[];
  bool childFinal = false;
  Completer<void>? nextSessionListGate;
  Completer<void>? sessionListEntered;
  @override
  Future<void> handle(HttpRequest request) async {
    requests.add(request.uri.toString());
    if (request.uri.path.startsWith('/api/sessions/child-root')) {
      childRequests.add(request);
      request.response.headers.contentType = ContentType.json;
      request.response.write(
        jsonEncode(
          request.uri.path.endsWith('/messages')
              ? {
                  'session_id': 'child-root',
                  'profile': 'root-profile',
                  'messages': [
                    {
                      'id': 1,
                      'role': 'assistant',
                      'content': childFinal
                          ? 'Child completed body'
                          : 'Child active body',
                    },
                  ],
                  'pagination': {
                    'limit': 50,
                    'offset': 0,
                    'order': 'latest',
                    'returned': 1,
                  },
                }
              : {
                  'id': 'child-root',
                  'source': 'subagent',
                  'profile': 'root-profile',
                },
        ),
      );
      await request.response.close();
      return;
    }
    if (request.uri.path.endsWith('/messages')) {
      final offset =
          int.tryParse(request.uri.queryParameters['offset'] ?? '0') ?? 0;
      final limit =
          int.tryParse(request.uri.queryParameters['limit'] ?? '50') ?? 50;
      messageOffsets.add(offset);
      final end = (rows.length - offset).clamp(0, rows.length);
      final start = (end - limit).clamp(0, end);
      final captured = [
        for (final r in rows.sublist(start, end)) Map<String, dynamic>.from(r),
      ];
      final gate = offset > 0 ? nextOlderGate : nextMessagesGate;
      if (gate != null) {
        if (offset > 0) {
          nextOlderGate = null;
          olderEntered!.complete();
        } else {
          nextMessagesGate = null;
          messagesEntered!.complete();
        }
        await gate.future;
      }
      request.response.headers.contentType = ContentType.json;
      request.response.write(jsonEncode({'data': captured}));
      await request.response.close();
      return;
    }
    if (request.uri.path == '/api/sessions') {
      // Old retained Home discovery and the replacement root lookup can both
      // read here. The original six controls still allow exactly fixture.
      expect(
        request.headers.value('authorization'),
        isIn({'Bearer fixture', 'Bearer $expectedApiKey'}),
      );
      final gate = nextSessionListGate;
      if (gate != null) {
        nextSessionListGate = null;
        sessionListEntered!.complete();
        await gate.future;
      }
      request.response.headers.contentType = ContentType.json;
      request.response.write(
        jsonEncode({
          'data': [
            if (creates > 0)
              {
                'id': 'stored',
                'title': 'Verified canonical',
                'model': 'fixture',
                'source': 'mobile',
                'message_count': rows.length,
                'started_at': 1,
              },
          ],
          'has_more': false,
        }),
      );
      await request.response.close();
      return;
    }
    await super.handle(request);
  }

  // Home/Workspace and recovery discovery may own independent control sockets.
  // Deliver a server session event on each open fixture socket; production
  // client runtime maps, not whichever socket was created last, admit it.
  @override
  void event(String type, Map<String, dynamic> payload, {String? turnId}) {
    for (final socket in sockets) {
      if (socket.readyState != WebSocket.open) continue;
      socket.add(
        jsonEncode({
          'jsonrpc': '2.0',
          'method': 'event',
          'params': {
            'type': type,
            'session_id': 'runtime',
            'turn_id': ?turnId,
            'payload': payload,
          },
        }),
      );
    }
  }

  void failTurn() {
    running = false;
    final id = 'wire-${prompts.length}';
    event('message.start', {}, turnId: id);
    event('turn.error', {'message': 'Fixture terminal failure'}, turnId: id);
  }
}

class _MemoryCredentials implements CredentialStore {
  _MemoryCredentials({Map<String, String>? physical}) : values = physical ?? {};
  final Map<String, String> values;
  final cache = <String, String>{};
  Completer<void>? readEntered;
  Completer<void>? readRelease;
  Completer<void>? writeEntered;
  Completer<void>? writeRelease;
  @override
  String? readCached(String key) => cache[key];
  @override
  Future<String?> read(String key) async {
    final value = values[key];
    final gate = readRelease;
    if (gate != null) {
      readRelease = null;
      readEntered!.complete();
      await gate.future;
    }
    if (value == null) {
      cache.remove(key);
    } else {
      cache[key] = value;
    }
    return value;
  }

  @override
  Future<void> write(String key, String value) async {
    if (writeRelease != null) {
      writeEntered!.complete();
      await writeRelease!.future;
      writeRelease = null;
    }
    values[key] = value;
    cache[key] = value;
  }

  @override
  Future<void> delete(String key) async {
    values.remove(key);
    cache.remove(key);
  }
}

class _RootAliasFixture {
  final notifications = TurnNotificationService();
  _RootAliasFixture({GatewayTurnApplicationController? controller})
    : injectedController = controller != null,
      controller =
          controller ??
          GatewayTurnApplicationController(
            journalFactory: () =>
                GatewayTurnJournal(store: MemoryTurnJournalStore()),
          );
  final GatewayTurnApplicationController controller;
  final bool injectedController;
  final credentials = _MemoryCredentials();
  final native = <String, dynamic>{'enabled': false};
  final nativeCalls = <MethodCall>[];
  final pluginCalls = <MethodCall>[];
  final live = <int, Map<String, dynamic>>{};
  final keepalive = <String>[];
  final pushRequests = <http.Request>[];
  final channel = const MethodChannel('test/spec-root-alias-push');
  static const plugin = MethodChannel(
    'dexterous.com/flutter/local_notifications',
  );
  final launch = AndroidLaunchIntentService();
  late _RootServer server;
  late ConnectionManager manager;
  late SavedConnection connection;
  late MobilePushService push;
  List<Map<String, dynamic>> feed = [];
  bool nativeRunning = false;
  String? recordedSchedule;
  Completer<Map<String, dynamic>>? snapshotGate;
  Completer<void>? snapshotEntered;
  Completer<void>? eventGate;
  Completer<void>? eventEntered;
  int snapshots = 0;
  Future<void> initialize(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    server = (await tester.runAsync(_RootServer.start))!;
    manager = ConnectionManager(
      await SharedPreferences.getInstance(),
      credentialStore: credentials,
    );
    await manager.saveConnection(
      'Root loopback',
      '127.0.0.1',
      server.server.port,
      'fixture',
      dashboardPort: server.server.port,
      dashboardProxied: true,
      gatewayProfile: 'root-profile',
    );
    connection = manager.getConnections().single;
    final messenger = tester.binding.defaultBinaryMessenger;
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      (_) async => null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      (_) async => 1,
    );
    messenger.setMockMethodCallHandler(plugin, (call) async {
      pluginCalls.add(call);
      if (call.method == 'show') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live[args['id'] as int] = args;
      } else if (call.method == 'cancel') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live.remove(args['id']);
      }
      return call.method == 'getNotificationAppLaunchDetails' ? null : true;
    });
    messenger.setMockMethodCallHandler(ConnectionKeepAliveService.channel, (
      call,
    ) async {
      keepalive.add(call.method);
      if (call.method == 'start') {
        nativeRunning = true;
      }
      if (call.method == 'stop') nativeRunning = false;
      return true;
    });
    messenger.setMockMethodCallHandler(channel, (call) async {
      nativeCalls.add(call);
      switch (call.method) {
        case 'snapshot':
          snapshots++;
          final gate = snapshotGate;
          if (gate != null) {
            snapshotGate = null;
            snapshotEntered!.complete();
            return gate.future;
          }
          return Map<String, dynamic>.from(native);
        case 'preferences':
          native.addAll(Map<String, dynamic>.from(call.arguments as Map));
          return Map<String, dynamic>.from(native);
        case 'takeTap':
          return native.remove('tap');
        case 'disable':
          native['enabled'] = false;
          native['active'] = false;
          native.remove('tap');
          return Map<String, dynamic>.from(native);
        default:
          throw StateError('Unexpected native command ${call.method}');
      }
    });
    push = MobilePushService(
      supported: true,
      channel: channel,
      clientFactory: (c) => DashboardClient(
        host: c.host,
        port: c.dashboardPort,
        proxied: c.dashboardProxied,
        gatewayProfile: c.gatewayProfile,
        httpClient: MockClient((request) async {
          pushRequests.add(request);
          final gate = eventGate;
          if (gate != null) {
            eventGate = null;
            eventEntered!.complete();
            await gate.future;
          }
          expect(request.method, 'GET');
          expect(request.url.path, '/api/plugins/mobile-push/events');
          expect(request.url.queryParameters['profile'], 'root-profile');
          return http.Response(
            jsonEncode({'events': feed, 'has_more': false, 'next_cursor': '1'}),
            200,
          );
        }),
      ),
    );
    launch.pendingQuickChat.value =
        true; // Fixture-owned launcher input, production Home/Workspace navigation.
    await tester.pumpWidget(
      HermesApp(
        connManager: manager,
        turnApplicationController: controller,
        notifications: notifications,
        mobilePush: push,
        launchIntents: launch,
      ),
    );
    await widgetUntil(
      tester,
      () => find.byType(ChatScreen).evaluate().isNotEmpty,
    );
    if (!injectedController) {
      await widgetUntil(
        tester,
        () => find
            .byKey(const ValueKey('legacy-transport-notice'))
            .evaluate()
            .isNotEmpty,
      );
    }
    await _drain(tester);
    expect(find.byType(HermesApp), findsOneWidget);
    expect(find.byType(WorkspaceScreen, skipOffstage: false), findsOneWidget);
    expect(
      tester
          .widget<WorkspaceScreen>(
            find.byType(WorkspaceScreen, skipOffstage: false),
          )
          .turnApplicationController,
      same(controller),
    );
  }

  Future<void> canonicalTap(
    WidgetTester tester, {
    required bool viaPush,
    int mountedChats = 2,
  }) async {
    if (viaPush) {
      final expiry = DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600;
      native.addAll({
        'enabled': true,
        'active': true,
        'connection': connection.id,
        'binding': MobilePushService.binding(connection),
        'installation': 'root-spec-installation',
        'nonce': 'root-spec-nonce',
        'generation': 7,
        'revision': 1,
        'endpoint': 'https://push.invalid/opaque',
        'sessions': ['stored'],
        'tap': {
          'nonce': 'root-spec-nonce',
          'generation': 7,
          'revision': 1,
          'event_id': 'root-spec-event',
          'expires_at': expiry,
        },
      });
      feed = [
        {
          'event_id': 'root-spec-event',
          'session_id': 'stored',
          'kind': 'input',
          'expires_at': expiry,
        },
      ];
      await tester.runAsync(push.refresh);
    } else {
      tap('stored');
    }
    await widgetUntil(
      tester,
      () =>
          find.byType(ChatScreen, skipOffstage: false).evaluate().length ==
          mountedChats,
    );
    await tester.pump(const Duration(seconds: 1));
    await _drain(tester);
  }

  void tap(String id) {
    notificationResponseHandler!(
      NotificationResponse(
        payload: jsonEncode({'connectionId': connection.id, 'sessionId': id}),
        notificationResponseType: NotificationResponseType.selectedNotification,
      ),
    );
  }

  Iterable<Map<String, dynamic>> get ongoing => live.values.where(
    (n) => (n['platformSpecifics'] as Map?)?['ongoing'] == true,
  );
  Iterable<Map<String, dynamic>> get terminals => pluginCalls
      .where((c) => c.method == 'show')
      .map((c) => Map<String, dynamic>.from(c.arguments as Map))
      .where(
        (n) =>
            (n['title'] == 'Hermes response ready' ||
            n['title'] == 'Hermes turn failed'),
      );
  Future<void> close(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    await _drain(tester);
    await tester.pumpWidget(const SizedBox.shrink());
    await _drain(tester);
    await controller.close();
    await tester.runAsync(server.close);
    await tester.pump(const Duration(seconds: 21));
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    expect(find.byType(HermesApp), findsNothing);
    expect(nativeRunning, isFalse);
    expect(ongoing, isEmpty);
    expect(
      prefs.getStringList(TurnNotificationService.ongoingIdsStorageKey) ??
          <String>[],
      isEmpty,
    );
    expect(pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
    expect(pendingNotificationApprovals.value, isEmpty);
    if (recordedSchedule != null) {
      await tester.runAsync(
        () => File('review-evidence/cleanup-$recordedSchedule.json')
            .writeAsString(
              jsonEncode({
                'rootUnmounted': true,
                'nativeRunning': nativeRunning,
                'ongoingCount': ongoing.length,
                'durableOngoingIds': prefs.getStringList(
                  TurnNotificationService.ongoingIdsStorageKey,
                ),
                'keepaliveCommands': keepalive,
              }),
            ),
      );
    }
    push.dispose();
    launch.dispose();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(plugin, null);
    messenger.setMockMethodCallHandler(
      ConnectionKeepAliveService.channel,
      null,
    );
    messenger.setMockMethodCallHandler(channel, null);
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      null,
    );
    debugDefaultTargetPlatformOverride = null;
  }
}

class _HeldApprovalSession extends InertTurnApplicationSession {
  final calls = <(String, String, String?)>[];
  Completer<bool>? held;
  @override
  Future<bool> tryRespondToApproval({
    required String sessionId,
    required String choice,
    String? requestId,
  }) async {
    calls.add((sessionId, choice, requestId));
    return held == null ? false : await held!.future;
  }
}

NotificationResponse _approval(
  SavedConnection c, {
  bool scoped = true,
  String action = 'approve',
  String session = 'stored',
}) => NotificationResponse(
  actionId: action,
  payload: jsonEncode({
    'connectionId': c.id,
    'sessionId': session,
    'requestId': 'approval-reused',
    if (scoped) ...NotificationApprovalAuthority.origin(c),
  }),
  notificationResponseType: NotificationResponseType.selectedNotificationAction,
);

Future<void> _drain(WidgetTester tester) async {
  for (var i = 0; i < 12; i++) {
    await tester.pump();
  }
  await tester.pump(const Duration(milliseconds: 350));
  await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  for (var i = 0; i < 6; i++) {
    await tester.pump();
  }
}

void _lifecycle(WidgetTester tester, AppLifecycleState target) {
  if (tester.binding.lifecycleState == target) return;
  if (target == AppLifecycleState.paused) {
    if (tester.binding.lifecycleState == AppLifecycleState.resumed) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.inactive) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  } else {
    if (tester.binding.lifecycleState == AppLifecycleState.paused) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.hidden) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
  }
}

Future<void> widgetUntil(WidgetTester tester, bool Function() condition) async {
  for (var i = 0; i < 3000; i++) {
    await tester.pump();
    if (condition()) return;
    await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  }
  fail('ROOT78 held-future condition did not arrive');
}

// Independently authored schedules on37. Fixture mechanics are explicitly
// reused from the committed root fixture; no producer assertions modified.
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });

  testWidgets(
    'INDEPENDENT37 actual root unrelated queued authority fault must not leak target mutation lease',
    (tester) async {
      final f = _RootAliasFixture();
      await f.initialize(tester);
      List<String>? saved;
      try {
        await f.manager.saveConnection(
          'Mutation target',
          f.connection.host,
          f.connection.port,
          'fixture',
          dashboardPort: f.connection.dashboardPort,
          dashboardProxied: true,
          gatewayProfile: 'target-profile',
        );
        final target = f.manager.getConnections().singleWhere(
          (c) => c.id != f.connection.id,
        );
        notificationResponseHandler!(_approval(f.connection));
        await widgetUntil(
          tester,
          () => pendingNotificationApprovals.value.length == 1,
        );
        final queued = pendingNotificationApprovals.value.single;
        _lifecycle(tester, AppLifecycleState.paused);
        await _drain(tester);
        saved = List<String>.from(
          f.manager.prefs.getStringList('saved_connections')!,
        );
        await f.manager.prefs.setStringList('saved_connections', ['{']);
        Object? fault;
        String? faultStack;
        try {
          await f.manager.updateApiKey(target.id, 'not-committed');
        } catch (error, stack) {
          fault = error;
          faultStack = stack.toString();
        }
        final pendingAfterFault = ConnectionMutationBarrier.isPending(
          target.id,
        );
        await f.manager.prefs.setStringList('saved_connections', saved);
        await f.manager.updateApiKey(target.id, 'successor-fixture');
        final current = f.manager.getConnections().singleWhere(
          (c) => c.id == target.id,
        );
        final pendingAfterSuccessor = ConnectionMutationBarrier.isPending(
          target.id,
        );
        final fact = {
          'faultType': fault.runtimeType.toString(),
          'faultStack': faultStack,
          'fault': fault.toString(),
          'unrelatedQueuedObjectSurvives': pendingNotificationApprovals.value
              .any((a) => identical(a, queued)),
          'pendingAfterFault': pendingAfterFault,
          'successorPhysicallyCommitted': current.apiKey == 'successor-fixture',
          'pendingAfterSuccessor': pendingAfterSuccessor,
          'successorCurrent': ConnectionMutationBarrier.isCurrent(
            target.id,
            ConnectionMutationBarrier.capture(target.id),
          ),
        };
        await tester.runAsync(
          () => File(
            'review-evidence/independent37-root-listener-leak.json',
          ).writeAsString(jsonEncode(fact)),
        );
        expect(fault, isA<CredentialStorageException>());
        expect(current.apiKey, 'successor-fixture');
        expect(
          pendingAfterFault,
          false,
          reason:
              'A real root pruning callback must not strand a mutation lease before begin returns it',
        );
        expect(pendingAfterSuccessor, false);
      } finally {
        if (saved != null) {
          await f.manager.prefs.setStringList('saved_connections', saved);
        }
        await f.close(tester);
      }
    },
  );

  testWidgets(
    'INDEPENDENT37 actual root queued authority must not block corrupt-metadata reset recovery',
    (tester) async {
      final f = _RootAliasFixture();
      await f.initialize(tester);
      List<String>? saved;
      try {
        notificationResponseHandler!(_approval(f.connection));
        await widgetUntil(
          tester,
          () => pendingNotificationApprovals.value.length == 1,
        );
        _lifecycle(tester, AppLifecycleState.paused);
        await _drain(tester);
        saved = List<String>.from(
          f.manager.prefs.getStringList('saved_connections')!,
        );
        await f.manager.prefs.setStringList('saved_connections', ['{']);
        Object? fault;
        String? faultStack;
        try {
          await f.manager.resetConnections();
        } catch (error, stack) {
          fault = error;
          faultStack = stack.toString();
        }
        final resetCleared =
            f.manager.prefs.getStringList('saved_connections') == null;
        await tester.runAsync(
          () => File('review-evidence/independent37-root-reset-recovery.json')
              .writeAsString(
                jsonEncode({
                  'faultType': fault.runtimeType.toString(),
                  'faultStack': faultStack,
                  'fault': fault.toString(),
                  'resetClearedCorruption': resetCleared,
                  'queuedActions': pendingNotificationApprovals.value.length,
                }),
              ),
        );
        expect(
          fault,
          isNull,
          reason:
              'resetConnections explicitly promises recovery from corrupt saved metadata',
        );
        expect(resetCleared, true);
      } finally {
        if (saved != null) {
          await f.manager.prefs.setStringList('saved_connections', saved);
        }
        await f.close(tester);
      }
    },
  );

  testWidgets(
    'INDEPENDENT37 held physical credential read cannot regain mutation authority through stale cache completion',
    (tester) async {
      // Qualified CredentialStore interface interleaving: this permits an old
      // captured read to finish after another wrapper's commit. It is not a
      // claim about FIFO Android secure-provider reply ordering.
      final sessions = <_HeldApprovalSession>[];
      final f = _RootAliasFixture(
        controller: GatewayTurnApplicationController(
          sessionFactory: (_) {
            final session = _HeldApprovalSession();
            sessions.add(session);
            return session;
          },
        ),
      );
      final held = Completer<void>();
      await f.initialize(tester);
      try {
        f.credentials.readEntered = Completer<void>();
        f.credentials.readRelease = held;
        notificationResponseHandler!(_approval(f.connection));
        await widgetUntil(tester, () => f.credentials.readEntered!.isCompleted);
        final other = ConnectionManager(
          f.manager.prefs,
          credentialStore: _MemoryCredentials(physical: f.credentials.values),
        );
        await other.updateApiKey(f.connection.id, 'replacement-fixture');
        held.complete();
        await _drain(tester);
        expect(
          f.manager.getConnections().single.apiKey,
          'fixture',
          reason:
              'The held old physical read really repopulated this independent stale cache',
        );
        expect(sessions.expand((s) => s.calls), isEmpty);
        expect(pendingNotificationApprovals.value, isEmpty);
        await f.manager.refreshConnectionCredentials(f.connection.id);
        final current = f.manager.getConnections().single;
        f.server.expectedApiKey = current.apiKey;
        notificationResponseHandler!(_approval(current, action: 'reject'));
        await widgetUntil(
          tester,
          () => pendingNotificationApprovals.value.length == 1,
        );
        expect(pendingNotificationApprovals.value.single.choice, 'deny');
        expect(
          pendingNotificationApprovals.value.single.authority!.isCurrentFor(
            current,
          ),
          true,
        );
        expect(sessions.expand((s) => s.calls).single.$2, 'deny');
        expect(tester.takeException(), isNull);
      } finally {
        if (!held.isCompleted) held.complete();
        await f.close(tester);
      }
    },
  );

  for (final origin in [
    'wrong-binding',
    'malformed-epoch',
    'same-process-stale',
  ]) {
    testWidgets(
      'INDEPENDENT37 invalid $origin has no automatic authority but body navigation remains',
      (tester) async {
        final session = _HeldApprovalSession();
        final f = _RootAliasFixture(
          controller: GatewayTurnApplicationController(
            sessionFactory: (_) => session,
          ),
        );
        await f.initialize(tester);
        try {
          final response = _approval(f.connection);
          final payload = jsonDecode(response.payload!) as Map<String, dynamic>;
          if (origin == 'wrong-binding') payload['approvalAccount'] = 'f' * 64;
          if (origin == 'malformed-epoch') {
            payload['approvalMutation'] = 'not-a-process-epoch';
          }
          if (origin == 'same-process-stale') {
            await f.manager.updateApiKey(f.connection.id, f.connection.apiKey);
          }
          notificationResponseHandler!(
            NotificationResponse(
              actionId: 'approve',
              payload: jsonEncode(payload),
              notificationResponseType:
                  NotificationResponseType.selectedNotificationAction,
            ),
          );
          await _drain(tester);
          expect(session.calls, isEmpty);
          expect(pendingNotificationApprovals.value, isEmpty);
          f.server.creates = 1;
          f.tap('stored');
          await widgetUntil(
            tester,
            () => tester
                .widgetList<ChatScreen>(find.byType(ChatScreen))
                .any((w) => w.session.id == 'stored'),
          );
          expect(session.calls, isEmpty);
          expect(tester.takeException(), isNull);
        } finally {
          await f.close(tester);
        }
      },
    );
  }

  testWidgets(
    'INDEPENDENT37 raw deferred actions survive intervening ordinary navigation independently',
    (tester) async {
      final session = _HeldApprovalSession();
      final f = _RootAliasFixture(
        controller: GatewayTurnApplicationController(
          sessionFactory: (_) => session,
        ),
      );
      await f.initialize(tester);
      try {
        _lifecycle(tester, AppLifecycleState.paused);
        await _drain(tester);
        notificationResponseHandler!(_approval(f.connection, session: 'one'));
        f.tap('ordinary');
        notificationResponseHandler!(
          _approval(f.connection, session: 'two', action: 'reject'),
        );
        notificationResponseHandler!(
          _approval(f.connection, session: 'legacy', scoped: false),
        );
        _lifecycle(tester, AppLifecycleState.resumed);
        await widgetUntil(
          tester,
          () => pendingNotificationApprovals.value.length == 2,
        );
        expect(
          pendingNotificationApprovals.value.map(
            (a) => (a.sessionId, a.choice),
          ),
          [('one', 'once'), ('two', 'deny')],
        );
        expect(session.calls.map((c) => (c.$1, c.$2)), [
          ('one', 'once'),
          ('two', 'deny'),
        ]);
        expect(f.server.prompts, isEmpty);
      } finally {
        await f.close(tester);
      }
    },
  );
}
