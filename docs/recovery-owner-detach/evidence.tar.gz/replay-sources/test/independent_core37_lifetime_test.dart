import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/models/received_scope_outcome.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/services/composer_draft_store.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/core/services/ws_client.dart';
import 'package:hermes_android/core/utils/chat_display_items.dart';
import 'package:hermes_android/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, widgetUntil;
import 'support/fake_voice_composer_adapter.dart';
import 'support/unreconciled_policy.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  final exports = <String>[];
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
    exports.clear();
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      (_) async => null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('dev.fluttercommunity.plus/share'),
      (call) async {
        if (call.method == 'share') {
          exports.add((call.arguments as Map)['text'] as String);
        }
        return 'success';
      },
    );
  });
  tearDown(() {
    HttpOverrides.global = previous;
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('dev.fluttercommunity.plus/share'),
      null,
    );
  });
  for (final width in [400.0, 1000.0]) {
    testWidgets(
      'CORE37 independent three stock outcomes retain exact scope through 404 and true reopen $width',
      (tester) async {
        await tester.binding.setSurfaceSize(Size(width, 3200));
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final wire = (await tester.runAsync(_StockServer.start))!;
        wire.creates = 1;
        wire.rows.add({
          'id': 101,
          'role': 'assistant',
          'content': 'Independent C baseline',
        });
        final controller = GatewayTurnApplicationController();
        Widget screen() => MaterialApp(
          localizationsDelegates: AppLocalizations.localizationsDelegates,
          supportedLocales: AppLocalizations.supportedLocales,
          home: ChatScreen(
            connection: wire.connection,
            session: Session(
              id: 'stored',
              title: 'Independent scope lifetime',
              model: 'fixture',
              source: 'test',
              messageCount: 1,
              isActive: false,
              preview: '',
              startedAt: 1,
            ),
            turnApplicationController: controller,
            testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
          ),
        );
        try {
          await tester.pumpWidget(screen());
          final normal = controller.normalSessionFor(wire.connection);
          final owner = normal.findChat('stored')!;
          await widgetUntil(
            tester,
            () =>
                owner.snapshot.historyRows.isNotEmpty &&
                find.byTooltip('Send').evaluate().isNotEmpty,
          );
          final state = tester.state(find.byType(ChatScreen));
          final composer = tester
              .widget<TextField>(find.byType(TextField))
              .controller!;
          final scroll = tester
              .widget<ListView>(find.byType(ListView).first)
              .controller!;
          final ids = <String>[];
          for (final status in ['error', 'completed', 'idle']) {
            await tester.enterText(find.byType(TextField), 'scope-$status');
            await tester.tap(find.byTooltip('Send').hitTestable());
            await widgetUntil(
              tester,
              () => wire.prompts.length == ids.length + 1,
            );
            ids.add(owner.snapshot.turnId!);
            wire.event('message.start', {}, turnId: 'wire-${ids.length}');
            wire.event('reasoning.delta', {
              'text': 'same reasoning',
            }, turnId: 'wire-${ids.length}');
            wire.event('message.delta', {
              'text': 'same retained body',
            }, turnId: 'wire-${ids.length}');
            wire.running = false;
            wire.status = status;
            if (status == 'completed') {
              wire.rows.addAll([
                {
                  'id': 102,
                  'role': 'user',
                  'content': 'independent saved prompt',
                },
                {
                  'id': 103,
                  'role': 'assistant',
                  'content': 'independent saved answer',
                },
              ]);
            }
            // No lifecycle turn.end. This hint must not create its own identity.
            wire.event('message.complete', {
              'text': 'same retained body',
              'status': status,
              if (status == 'error') 'error': 'known fixture error',
            });
            await widgetUntil(tester, () => !owner.snapshot.hasActiveTurn);
            await tester.pumpAndSettle();
            await tester.pump(const Duration(seconds: 8));
            await tester.pumpAndSettle();
          }
          expect(wire.prompts.map((p) => p['text']), [
            'scope-error',
            'scope-completed',
            'scope-idle',
          ]);
          final before = owner.snapshot;
          expect(before.receivedOutcomes.map((f) => f.id), ids);
          expect(before.receivedOutcomes.map((f) => f.outcome), [
            ReceivedLifecycleOutcome.failed,
            ReceivedLifecycleOutcome.completed,
            ReceivedLifecycleOutcome.unknown,
          ]);
          expect(before.receivedOutcomes.map((f) => f.scopes.length), [
            2,
            2,
            2,
          ]);
          final rowScopes = before.displayRows
              .map((r) => r['_normal_projection_id'])
              .toSet();
          expect(
            before.receivedOutcomes.every(
              (f) => f.scopes.every(rowScopes.contains),
            ),
            true,
          );
          expect(
            before.displayRows.where(
              (r) =>
                  r['role'] == 'assistant' &&
                  r['content'] == 'same retained body',
            ),
            hasLength(3),
          );
          expect(
            before.timeline.runs.where((r) => r.text == 'same reasoning'),
            hasLength(3),
          );
          final reservation = owner.reserve()!;
          owner.cancelPreparation(reservation);
          expect(
            owner.snapshot.receivedOutcomes,
            orderedEquals(before.receivedOutcomes),
          );
          wire.historyUnavailable = true;
          await tester.tap(find.byTooltip('Chat actions').hitTestable());
          await tester.pumpAndSettle();
          await tester.tap(find.text('Refresh').hitTestable());
          await tester.pumpAndSettle();
          expect(tester.state(find.byType(ChatScreen)), same(state));
          expect(
            tester.widget<TextField>(find.byType(TextField)).controller,
            same(composer),
          );
          expect(
            tester.widget<ListView>(find.byType(ListView).first).controller,
            same(scroll),
          );
          expect(
            owner.snapshot.receivedOutcomes,
            orderedEquals(before.receivedOutcomes),
          );
          await tester.enterText(find.byType(TextField), 'retained new draft');
          await tester.pumpWidget(const SizedBox.shrink());
          await tester.pump();
          await tester.pumpWidget(screen());
          await widgetUntil(
            tester,
            () =>
                find.byType(TextField).evaluate().isNotEmpty &&
                tester
                        .widget<TextField>(find.byType(TextField))
                        .controller!
                        .text ==
                    'retained new draft',
          );
          expect(tester.state(find.byType(ChatScreen)), isNot(same(state)));
          expect(normal.findChat('stored'), same(owner));
          expect(
            owner.snapshot.receivedOutcomes,
            orderedEquals(before.receivedOutcomes),
          );
          await tester.tap(find.byTooltip('Chat actions').hitTestable());
          await tester.pumpAndSettle();
          await tester.tap(find.text('Export / share').hitTestable());
          await tester.pumpAndSettle();
          final output = exports.single;
          final r = output
              .split('## Received output — match to saved history unconfirmed')
              .last;
          for (final label in [
            'Turn failed',
            'Turn completed',
            'Turn ended — outcome unconfirmed',
          ]) {
            expect(
              r.split(label),
              hasLength(2),
              reason: 'exact one operation fact: $label',
            );
          }
          expect(r.indexOf('Turn failed'), lessThan(r.indexOf('scope-error')));
          expect(
            r.indexOf('Turn completed'),
            lessThan(r.indexOf('scope-completed')),
          );
          expect(
            r.indexOf('Turn ended — outcome unconfirmed'),
            lessThan(r.indexOf('scope-idle')),
          );
          expect(
            output.indexOf('Independent C baseline'),
            lessThan(output.indexOf('## Received output')),
          );
          expect(r.split('same retained body'), hasLength(4));
          expect(
            inChatSource(
              find.text('Turn failed · Local prompt context'),
              ChatDisplaySource.received,
            ),
            findsOneWidget,
          );
          expect(
            inChatSource(
              find.text('Turn completed · Local prompt context'),
              ChatDisplaySource.received,
            ),
            findsOneWidget,
          );
          expect(wire.prompts, hasLength(3));
          expect(tester.takeException(), isNull);
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await tester.runAsync(() async {
            await controller.close();
            await wire.close();
          });
          await tester.pump(const Duration(seconds: 16));
        }
      },
    );
  }

  for (final lateFailure in [true, false]) {
    test(
      'CORE37 actual manager credential ABA closes old owner without replay or stale outcome lateFailure=$lateFailure',
      () async {
        final c = SavedConnection(
          id: 'independent-mutation',
          label: 'Fixture',
          host: 'fixture.invalid',
          port: 8642,
          apiKey: 'fixture-A',
        );
        SharedPreferences.setMockInitialValues({
          'saved_connections': [
            jsonEncode({...c.toMap(), 'api_key': c.apiKey}),
          ],
        });
        final prefs = await SharedPreferences.getInstance();
        final manager = await ConnectionManager.create(
          prefs,
          credentialStore: _MemoryCredentials(),
        );
        final controller = GatewayTurnApplicationController();
        addTearDown(controller.close);
        final ack = Completer<void>();
        final sent = Completer<void>();
        var submissions = 0;
        Future<void> submit({
          required String sessionId,
          required String text,
          required StreamCallback onEvent,
          required void Function() onSent,
        }) {
          submissions++;
          onSent();
          sent.complete();
          return ack.future;
        }

        Future<ResumedGatewaySession> resume({
          required String localSessionId,
          required String storedSessionId,
        }) async =>
            ResumedGatewaySession(runtimeSessionId: 'runtime', running: true);
        final old = controller.normalSessionFor(
          manager.getConnections().single,
          submit: submit,
          resume: resume,
          history: (_) async => [],
        );
        await old.ready;
        final owner = old.chatFor(
          'local',
          storedSessionId: 'stored',
          title: 'Old owner',
        );
        owner.observeHistory([
          {'id': 37, 'role': 'assistant', 'content': 'baseline'},
        ]);
        final read = owner.beginHistoryRead('stored');
        final sending = owner.submitPrepared(
          reservation: owner.reserve()!,
          text: 'Never replay',
          localContent: 'Never replay',
        );
        await sent.future;
        final turn = owner.turnId;
        old.receiveEvent(
          'local',
          StreamEvent(
            type: 'message.delta',
            data: {'text': 'old received'},
            turnId: 'old-wire',
          ),
        );
        await ComposerDraftStore.save(
          connectionId: c.id,
          sessionId: 'stored',
          text: 'explicit independent draft',
        );
        final receipt = (await old.pendingStore.load(old.scope)).single;
        expect(receipt.turnId, turn);
        expect(receipt.rowFloor, 37);
        await manager.updateApiKey(c.id, 'fixture-B');
        await manager.updateApiKey(c.id, 'fixture-A');
        expect(manager.getConnections().single.apiKey, c.apiKey);
        final replacement = controller.normalSessionFor(
          manager.getConnections().single,
          submit: submit,
          resume: resume,
          history: (_) async => [],
        );
        await replacement.ready;
        expect(replacement, isNot(same(old)));
        expect(old.isClosed, true);
        expect(read.isCurrent, false);
        expect(owner.reserve(), isNull);
        final restored = replacement.findChat('stored')!;
        final before = restored.snapshot;
        expect(before.turnId, turn);
        expect(before.hasActiveTurn, true);
        expect(
          before.receivedOutcomes,
          isEmpty,
          reason: 'account/owner end legitimately ends volatile output',
        );
        expect(owner.snapshot.displayRows, isEmpty);
        ack.complete();
        await sending;
        old.receiveEvent(
          'local',
          StreamEvent(
            type: 'turn.end',
            data: {'status': lateFailure ? 'error' : 'completed'},
            turnId: 'old-wire',
          ),
        );
        await Future<void>.delayed(Duration.zero);
        expect(restored.snapshot.turnId, turn);
        expect(restored.snapshot.hasActiveTurn, true);
        expect(restored.snapshot.receivedOutcomes, isEmpty);
        expect(
          (await replacement.pendingStore.load(
            replacement.scope,
          )).single.turnId,
          turn,
        );
        expect(
          await ComposerDraftStore.read(
            connectionId: c.id,
            sessionId: 'stored',
          ),
          'explicit independent draft',
        );
        expect(submissions, 1);
      },
    );
  }

  for (final finalOutcome in [true, false]) {
    test(
      'CORE37 independent owner multialias, snapshot immutability and actual row eviction outcome=$finalOutcome',
      () async {
        final fixture = _OwnerFixture();
        addTearDown(fixture.session.close);
        await fixture.session.ready;
        await fixture.turn('first', false);
        final first = fixture.owner.snapshot;
        final oldFact = first.receivedOutcomes.single;
        expect(() => oldFact.scopes.add('forged'), throwsUnsupportedError);
        expect(() => first.receivedOutcomes.clear(), throwsUnsupportedError);
        final incoming = fixture.session.chatFor(
          'second-local',
          title: 'incoming',
        );
        incoming.bindStoredSession('stored');
        expect(
          fixture.session.findChat('stored')!.snapshot.receivedOutcomes.single,
          same(oldFact),
        );
        for (var i = 0; i < 132; i++) {
          await fixture.turn('turn-$i', i.isEven);
          final s = fixture.owner.snapshot;
          final scopes = s.displayRows
              .map((r) => r['_normal_projection_id'])
              .toSet();
          expect(
            s.receivedOutcomes.every((f) => f.scopes.every(scopes.contains)),
            true,
          );
          expect(
            s.receivedOutcomes.map((f) => f.id).toSet().length,
            s.receivedOutcomes.length,
          );
        }
        await fixture.turn('last', finalOutcome);
        final s = fixture.owner.snapshot;
        expect(s.receivedOutcomes.any((f) => f.id == oldFact.id), false);
        expect(first.receivedOutcomes.single, same(oldFact));
        expect(
          s.receivedOutcomes.last.outcome,
          finalOutcome
              ? ReceivedLifecycleOutcome.completed
              : ReceivedLifecycleOutcome.failed,
        );
        fixture.emit('turn.error', {'error': 'late prior'}, 'wire-1');
        expect(
          fixture.owner.snapshot.receivedOutcomes,
          orderedEquals(s.receivedOutcomes),
        );
        final sections = buildNormalChatDisplaySections(
          canonicalRows: [
            {'id': 9999, 'role': 'assistant', 'content': 'independent saved'},
          ],
          receivedRows: s.displayRows,
          receivedTimeline: s.timeline,
          receivedTools: s.tools,
          receivedOutcomes: s.receivedOutcomes,
        );
        expect(sections.map((x) => x.source), [
          ChatDisplaySource.canonical,
          ChatDisplaySource.received,
        ]);
        final rendered = sections.last;
        expect(
          rendered.outcomes.values.map((f) => f.id).toSet(),
          s.receivedOutcomes.map((f) => f.id).toSet(),
        );
        expect(rendered.outcomes.values.length, s.receivedOutcomes.length);
        await fixture.session.close();
        expect(fixture.owner.snapshot.receivedOutcomes, isEmpty);
      },
    );
  }
}

class _MemoryCredentials implements CredentialStore {
  final values = <String, String>{};
  @override
  String? readCached(String key) => values[key];
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async {
    values[key] = value;
  }

  @override
  Future<void> delete(String key) async {
    values.remove(key);
  }
}

class _OwnerFixture {
  late final session = NormalGatewayApplicationSession(
    connection: SavedConnection(
      id: 'independent37',
      label: 'Fixture',
      host: 'fixture.invalid',
      port: 1,
      apiKey: 'fixture',
    ),
    scope: 'independent37',
    submit:
        ({
          required sessionId,
          required text,
          required onEvent,
          required onSent,
        }) async {
          count++;
          onSent();
        },
    resume: ({required localSessionId, required storedSessionId}) async =>
        ResumedGatewaySession(runtimeSessionId: 'runtime', running: true),
    history: (_) async => [],
  );
  late final owner = session.chatFor(
    'local',
    storedSessionId: 'stored',
    title: 'Independent owner',
  );
  int count = 0;
  void emit(String type, Map<String, dynamic> data, String turn) => session
      .receiveEvent('local', StreamEvent(type: type, data: data, turnId: turn));
  Future<void> turn(String prompt, bool success) async {
    final current = session.findChat('stored') ?? owner;
    current.observeHistory([]);
    await current.submitPrepared(
      reservation: current.reserve()!,
      text: prompt,
      localContent: prompt,
    );
    emit('message.delta', {'text': 'body-$count'}, 'wire-$count');
    emit('turn.end', {
      'status': success ? 'completed' : 'error',
      if (!success) 'error': 'known failure',
    }, 'wire-$count');
    for (var i = 0; i < 100 && current.snapshot.hasActiveTurn; i++) {
      await Future<void>.delayed(Duration.zero);
    }
    expect(current.snapshot.hasActiveTurn, false);
  }
}

class _StockServer extends BindingServer {
  _StockServer(super.server);
  String status = 'idle';
  bool closing = false;
  @override
  Future<void> close() async {
    closing = true;
    await super.close();
  }

  static Future<_StockServer> start() async {
    final server = _StockServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    server.server.listen(server.handle);
    return server;
  }

  @override
  Future<void> handle(HttpRequest request) async {
    if (request.uri.path != '/api/ws') {
      return super.handle(request);
    }
    final socket = await WebSocketTransformer.upgrade(request);
    sockets.add(socket);
    socket.add(
      jsonEncode({
        'jsonrpc': '2.0',
        'method': 'event',
        'params': {'type': 'gateway.ready', 'payload': {}},
      }),
    );
    socket.listen((raw) {
      final frame = jsonDecode(raw as String) as Map;
      debugPrint(
        'CORE37-SOCKET method=${frame['method']} id=${frame['id']} closing=$closing state=${socket.readyState}',
      );
      if (closing) {
        return;
      }
      if (frame['method'] == null) {
        return;
      }
      final result = <String, dynamic>{'ok': true};
      if (frame['method'] == 'session.resume') {
        resumes++;
        result.addAll({
          'session_id': 'runtime',
          'stored_session_id': 'stored',
          'running': running,
          'status': running ? 'running' : status,
          if (status == 'error')
            'inflight': {'status': 'error', 'error': 'known fixture error'},
        });
      } else if (frame['method'] == 'prompt.submit') {
        prompts.add(Map<String, dynamic>.from(frame['params'] as Map));
        running = true;
        status = 'running';
      }
      if (socket.readyState == WebSocket.open) {
        socket.add(
          jsonEncode({'jsonrpc': '2.0', 'id': frame['id'], 'result': result}),
        );
      }
    });
  }
}
