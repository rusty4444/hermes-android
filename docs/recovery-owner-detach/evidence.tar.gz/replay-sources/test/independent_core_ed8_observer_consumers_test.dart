import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/models/received_scope_outcome.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/composer_draft_store.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/connection_mutation_barrier.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/core/services/notification_approval_authority.dart';
import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/core/services/ws_client.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'mobile_push_service_test.dart' show MemorySecrets;
import 'support/mutation_observer_root_fixture.dart';

class _PromptRig {
  final sent = Completer<void>();
  final ack = Completer<void>();
  int calls = 0;
  final bool held;
  _PromptRig({this.held = false});

  Future<void> submit({
    required String sessionId,
    required String text,
    required StreamCallback onEvent,
    required void Function() onSent,
  }) async {
    calls++;
    onSent();
    if (!sent.isCompleted) sent.complete();
    if (held) await ack.future;
  }

  Future<ResumedGatewaySession> resume({
    required String localSessionId,
    required String storedSessionId,
  }) async => ResumedGatewaySession(runtimeSessionId: 'runtime', running: true);

  NormalGatewayApplicationSession session(
    GatewayTurnApplicationController controller,
    SavedConnection connection,
  ) => controller.normalSessionFor(
    connection,
    submit: submit,
    resume: resume,
    history: (_) async => [],
  );
}

NotificationApprovalAuthority? _authority(
  SavedConnection c,
  NormalGatewayApplicationSession session,
) {
  final origin = NotificationApprovalAuthority.origin(c);
  return NotificationApprovalAuthority.capture(
    connection: c,
    accountBinding: origin['approvalAccount'],
    originMutation: origin['approvalMutation'],
    owner: session,
    ownerIsCurrent: () => !session.isClosed,
    refresh: () async => true,
  );
}

void _emit(
  NormalGatewayApplicationSession session,
  String local,
  String type,
  Map<String, dynamic> data,
  String wire,
) => session.receiveEvent(
  local,
  StreamEvent(type: type, data: data, turnId: wire),
);

class _HeldCredentials extends MemorySecrets {
  Completer<void>? entered;
  Completer<void>? release;
  @override
  Future<void> write(String key, String value) async {
    final gate = release;
    if (gate != null) {
      release = null;
      entered!.complete();
      await gate.future;
      throw PlatformException(code: 'synthetic-provider-private-payload');
    }
    await super.write(key, value);
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });

  for (final lateFailure in [false, true]) {
    testWidgets(
      'COREed8 real root corrupt observer plus A held ACK and B retained owner lateFailure=$lateFailure',
      (tester) async {
        final f = MutationObserverRootFixture();
        await f.initialize(tester);
        List<String>? saved;
        final rig = _PromptRig(held: true);
        Future<void>? sending;
        try {
          await f.manager.saveConnection(
            'Core A',
            f.connection.host,
            f.connection.port,
            'fixture-A',
            dashboardPort: f.connection.dashboardPort,
            dashboardProxied: true,
            gatewayProfile: 'core-a-profile',
          );
          final a = f.manager.getConnections().singleWhere(
            (c) => c.id != f.connection.id,
          );
          final old = rig.session(f.controller, a);
          await old.ready;
          final owner = old.chatFor(
            'a-local',
            storedSessionId: 'a-stored',
            title: 'A owner',
          );
          owner.observeHistory([
            {'id': 37, 'role': 'assistant', 'content': 'A canonical baseline'},
          ]);
          sending = owner.submitPrepared(
            reservation: owner.reserve()!,
            text: 'A one physical submission',
            localContent: 'A one physical submission',
          );
          await rig.sent.future;
          _emit(old, 'a-local', 'message.delta', {
            'text': 'A private body',
          }, 'a-wire');
          final read = owner.beginHistoryRead('a-stored');
          expect(read.isCurrent, isTrue);
          final aAuthority = _authority(a, old)!;
          final receipt = (await old.pendingStore.load(old.scope)).single;
          expect(receipt.rowFloor, 37);
          final bSession = f.controller.normalSessionFor(f.connection);
          await bSession.ready;
          final bOwner = bSession.chatFor(
            'b-control',
            storedSessionId: 'b-stored',
            title: 'B owner',
          );
          bOwner.observeHistory([
            {'id': 88, 'role': 'assistant', 'content': 'B independent data'},
          ]);
          final bBefore = bOwner.snapshot;
          await ComposerDraftStore.save(
            connectionId: f.connection.id,
            sessionId: 'b-stored',
            text: 'B independent draft',
          );
          final queuedB = await f.queueAndPause(tester);
          saved = List<String>.from(
            f.manager.prefs.getStringList('saved_connections')!,
          );
          await f.manager.prefs.setStringList('saved_connections', ['{']);
          await expectLater(
            f.manager.updateApiKey(a.id, 'must-not-commit'),
            throwsA(
              isA<CredentialStorageException>().having(
                (e) => e.toString(),
                'own sanitized I/O error',
                'Saved connection metadata could not be read safely.',
              ),
            ),
          );
          expect(ConnectionMutationBarrier.isPending(a.id), isFalse);
          expect(aAuthority.isCurrent, isFalse);
          expect(pendingNotificationApprovals.value.single, same(queuedB));
          await f.manager.prefs.setStringList('saved_connections', saved);
          final replacement = rig.session(f.controller, a);
          await replacement.ready;
          expect(replacement, isNot(same(old)));
          expect(old.isClosed, isTrue);
          expect(read.isCurrent, isFalse);
          expect(owner.reserve(), isNull);
          final restored = replacement.findChat('a-stored')!;
          expect(restored.turnId, receipt.turnId);
          expect(restored.snapshot.rowFloor, 37);
          expect(restored.snapshot.hasActiveTurn, isTrue);
          expect(restored.snapshot.receivedOutcomes, isEmpty);
          rig.ack.complete();
          await sending;
          _emit(old, 'a-local', 'message.delta', {
            'text': 'late A payload',
          }, 'a-wire');
          _emit(old, 'a-local', 'turn.end', {
            'status': lateFailure ? 'error' : 'completed',
          }, 'a-wire');
          await MutationObserverRootFixture.drain(tester);
          final unchanged = (await replacement.pendingStore.load(
            replacement.scope,
          )).single;
          expect(unchanged.turnId, receipt.turnId);
          expect(unchanged.rowFloor, 37);
          expect(restored.snapshot.hasActiveTurn, isTrue);
          expect(restored.snapshot.receivedOutcomes, isEmpty);
          expect(owner.snapshot.displayRows, isEmpty);
          // A real physical same-ID/same-configuration successor rotates epochs.
          await f.manager.updateApiKey(a.id, 'fixture-A');
          final freshRig = _PromptRig();
          final current = freshRig.session(f.controller, a);
          await current.ready;
          expect(current, isNot(same(replacement)));
          expect(current.hasCurrentAccount, isTrue);
          final fresh = current.chatFor(
            'fresh-local',
            storedSessionId: 'fresh-stored',
            title: 'Fresh A',
          );
          fresh.observeHistory([]);
          await fresh.submitPrepared(
            reservation: fresh.reserve()!,
            text: 'Fresh explicit A prompt',
            localContent: 'Fresh explicit A prompt',
          );
          _emit(current, 'fresh-local', 'message.delta', {
            'text': 'fresh A body',
          }, 'fresh-wire');
          _emit(current, 'fresh-local', 'turn.end', {
            'status': 'completed',
          }, 'fresh-wire');
          await MutationObserverRootFixture.until(
            tester,
            () => !fresh.snapshot.hasActiveTurn,
          );
          expect(
            fresh.snapshot.receivedOutcomes.single.outcome,
            ReceivedLifecycleOutcome.completed,
          );
          expect(freshRig.calls, 1);
          expect(rig.calls, 1, reason: 'No automatic replay of uncertain A');
          final remaining = await current.pendingStore.load(current.scope);
          expect(remaining.map((m) => m.turnId), [receipt.turnId]);
          expect(f.controller.normalSessionFor(f.connection), same(bSession));
          expect(bSession.findChat('b-stored'), same(bOwner));
          expect(bOwner.snapshot.historyRows, bBefore.historyRows);
          expect(bOwner.snapshot.displayRows, bBefore.displayRows);
          expect(bOwner.snapshot.receivedOutcomes, bBefore.receivedOutcomes);
          expect(
            await ComposerDraftStore.read(
              connectionId: f.connection.id,
              sessionId: 'b-stored',
            ),
            'B independent draft',
          );
          expect(pendingNotificationApprovals.value.single, same(queuedB));
          expect(queuedB.authority!.isCurrentFor(f.connection), isTrue);
          expect(tester.takeException(), isNull);
        } finally {
          if (!rig.ack.isCompleted) rig.ack.complete();
          await sending;
          if (saved != null) {
            await f.manager.prefs.setStringList('saved_connections', saved);
          }
          await f.close(tester);
        }
      },
    );
  }

  test(
    'COREed8 held failing physical edit keeps current admission closed until queued successor drains',
    () async {
      final store = _HeldCredentials();
      final manager = ConnectionManager(
        await SharedPreferences.getInstance(),
        credentialStore: store,
      );
      await manager.saveConnection('A', 'a.invalid', 443, 'original');
      await manager.saveConnection('B', 'b.invalid', 443, 'unrelated');
      final a = manager.getConnections().singleWhere((c) => c.label == 'A');
      final b = manager.getConnections().singleWhere((c) => c.label == 'B');
      final controller = GatewayTurnApplicationController();
      addTearDown(controller.close);
      final rig = _PromptRig();
      final old = rig.session(controller, a);
      final sibling = rig.session(controller, b);
      await old.ready;
      await sibling.ready;
      final oldAuthority = _authority(a, old)!;
      final siblingAuthority = _authority(b, sibling)!;
      final entered = Completer<void>();
      final release = Completer<void>();
      store.entered = entered;
      store.release = release;
      var callbacks = 0;
      void fault() => throw StateError('optional-private-observer');
      void healthy() => callbacks++;
      ConnectionMutationBarrier.addListener(fault);
      ConnectionMutationBarrier.addListener(healthy);
      Future<Object?>? failed;
      Future<void>? successor;
      try {
        failed = manager
            .updateApiKey(a.id, 'failure')
            .then<Object?>((_) => null, onError: (Object e) => e);
        await entered.future;
        final epoch = ConnectionMutationBarrier.capture(a.id);
        expect(oldAuthority.isCurrent, isFalse);
        expect(_authority(a, old), isNull);
        expect(siblingAuthority.isCurrent, isTrue);
        final interim = rig.session(controller, a);
        await interim.ready;
        expect(old.isClosed, isTrue);
        expect(interim.hasCurrentAccount, isFalse);
        successor = manager.updateApiKey(a.id, 'successor');
        expect(ConnectionMutationBarrier.isPending(a.id), isTrue);
        expect(ConnectionMutationBarrier.isCurrent(a.id, epoch), isFalse);
        expect(_authority(a, interim), isNull);
        release.complete();
        final failure = await failed;
        expect(failure, isA<CredentialStorageException>());
        expect(
          failure.toString(),
          'Connection credentials could not be saved safely.',
        );
        await successor;
        final currentConnection = manager.getConnections().singleWhere(
          (c) => c.id == a.id,
        );
        expect(currentConnection.apiKey, 'successor');
        final current = rig.session(controller, currentConnection);
        await current.ready;
        expect(interim.isClosed, isTrue);
        expect(current.hasCurrentAccount, isTrue);
        expect(_authority(currentConnection, current)!.isCurrent, isTrue);
        expect(oldAuthority.isCurrent, isFalse);
        expect(siblingAuthority.isCurrent, isTrue);
        expect(rig.session(controller, b), same(sibling));
        final owner = current.chatFor(
          'fresh',
          storedSessionId: 'fresh-stored',
          title: 'Current A',
        );
        final reservation = owner.reserve();
        expect(reservation, isNotNull);
        owner.cancelPreparation(reservation!);
        expect(owner.snapshot.hasActiveTurn, isFalse);
        expect(ConnectionMutationBarrier.isPending(a.id), isFalse);
        expect(callbacks, 4);
        expect(rig.calls, 0);
      } finally {
        if (!release.isCompleted) release.complete();
        await failed;
        await successor;
        ConnectionMutationBarrier.removeListener(fault);
        ConnectionMutationBarrier.removeListener(healthy);
      }
    },
  );
}
