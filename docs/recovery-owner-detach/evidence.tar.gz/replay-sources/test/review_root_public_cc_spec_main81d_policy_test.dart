// Fresh schedules; reuses prior independent root fixture mechanics.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/core/widgets/gateway_activity_card.dart';
import 'package:hermes_android/core/widgets/gateway_insight_card.dart';
import 'package:hermes_android/core/screens/workspace_screen.dart';
import 'package:hermes_android/core/services/android_launch_intent_service.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/composer_draft_store.dart';
import 'package:hermes_android/core/services/connection_keepalive_service.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/gateway_turn_journal.dart';
import 'package:hermes_android/core/services/mobile_push_service.dart';

import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:hermes_android/main.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, widgetUntil;
import 'support/memory_turn_journal_store.dart';

class _RootServer extends BindingServer {
  _RootServer(super.server);
  static Future<_RootServer> start() async {
    final owner = _RootServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    owner.server.listen(owner.handle);
    return owner;
  }

  final requests = <String>[];
  Completer<void>? nextSessionListGate;
  Completer<void>? sessionListEntered;
  @override
  Future<void> handle(HttpRequest request) async {
    requests.add(request.uri.toString());
    if (request.uri.path == '/api/sessions') {
      expect(request.headers.value('authorization'), 'Bearer fixture');
      final gate = nextSessionListGate;
      if (gate != null) {
        nextSessionListGate = null;
        sessionListEntered!.complete();
        await gate.future;
      }
      request.response.headers.contentType = ContentType.json;
      request.response.write(
        jsonEncode({
          'data': [
            if (creates > 0)
              {
                'id': 'stored',
                'title': 'Verified canonical',
                'model': 'fixture',
                'source': 'mobile',
                'message_count': rows.length,
                'started_at': 1,
              },
          ],
          'has_more': false,
        }),
      );
      await request.response.close();
      return;
    }
    await super.handle(request);
  }

  // Home/Workspace and recovery discovery may own independent control sockets.
  // Deliver a server session event on each open fixture socket; production
  // client runtime maps, not whichever socket was created last, admit it.
  @override
  void event(String type, Map<String, dynamic> payload, {String? turnId}) {
    for (final socket in sockets) {
      if (socket.readyState != WebSocket.open) continue;
      socket.add(
        jsonEncode({
          'jsonrpc': '2.0',
          'method': 'event',
          'params': {
            'type': type,
            'session_id': 'runtime',
            'turn_id': ?turnId,
            'payload': payload,
          },
        }),
      );
    }
  }

  void failTurn() {
    running = false;
    final id = 'wire-${prompts.length}';
    event('message.start', {}, turnId: id);
    event('turn.error', {'message': 'Fixture terminal failure'}, turnId: id);
  }
}

class _MemoryCredentials implements CredentialStore {
  final values = <String, String>{};
  @override
  String? readCached(String key) => values[key];
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async => values[key] = value;
  @override
  Future<void> delete(String key) async => values.remove(key);
}

class _RootAliasFixture {
  final controller = GatewayTurnApplicationController(
    journalFactory: () => GatewayTurnJournal(store: MemoryTurnJournalStore()),
  );
  final native = <String, dynamic>{'enabled': false};
  final nativeCalls = <MethodCall>[];
  final pluginCalls = <MethodCall>[];
  final live = <int, Map<String, dynamic>>{};
  final keepalive = <String>[];
  final pushRequests = <http.Request>[];
  final channel = const MethodChannel('test/spec-root-alias-push');
  static const plugin = MethodChannel(
    'dexterous.com/flutter/local_notifications',
  );
  final launch = AndroidLaunchIntentService();
  late _RootServer server;
  late ConnectionManager manager;
  late SavedConnection connection;
  late MobilePushService push;
  List<Map<String, dynamic>> feed = [];
  bool nativeRunning = false;
  String? recordedSchedule;
  Completer<Map<String, dynamic>>? snapshotGate;
  Completer<void>? snapshotEntered;
  Completer<void>? eventGate;
  Completer<void>? eventEntered;
  int snapshots = 0;
  Future<void> initialize(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    server = (await tester.runAsync(_RootServer.start))!;
    manager = ConnectionManager(
      await SharedPreferences.getInstance(),
      credentialStore: _MemoryCredentials(),
    );
    await manager.saveConnection(
      'Root loopback',
      '127.0.0.1',
      server.server.port,
      'fixture',
      dashboardPort: server.server.port,
      dashboardProxied: true,
      gatewayProfile: 'root-profile',
    );
    connection = manager.getConnections().single;
    final messenger = tester.binding.defaultBinaryMessenger;
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      (_) async => null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      (_) async => 1,
    );
    messenger.setMockMethodCallHandler(plugin, (call) async {
      pluginCalls.add(call);
      if (call.method == 'show') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live[args['id'] as int] = args;
      } else if (call.method == 'cancel') {
        final args = Map<String, dynamic>.from(call.arguments as Map);
        live.remove(args['id']);
      }
      return call.method == 'getNotificationAppLaunchDetails' ? null : true;
    });
    messenger.setMockMethodCallHandler(ConnectionKeepAliveService.channel, (
      call,
    ) async {
      keepalive.add(call.method);
      if (call.method == 'start') {
        nativeRunning = true;
      }
      if (call.method == 'stop') nativeRunning = false;
      return true;
    });
    messenger.setMockMethodCallHandler(channel, (call) async {
      nativeCalls.add(call);
      switch (call.method) {
        case 'snapshot':
          snapshots++;
          final gate = snapshotGate;
          if (gate != null) {
            snapshotGate = null;
            snapshotEntered!.complete();
            return gate.future;
          }
          return Map<String, dynamic>.from(native);
        case 'preferences':
          native.addAll(Map<String, dynamic>.from(call.arguments as Map));
          return Map<String, dynamic>.from(native);
        case 'takeTap':
          return native.remove('tap');
        case 'disable':
          native['enabled'] = false;
          native['active'] = false;
          native.remove('tap');
          return Map<String, dynamic>.from(native);
        default:
          throw StateError('Unexpected native command ${call.method}');
      }
    });
    push = MobilePushService(
      supported: true,
      channel: channel,
      clientFactory: (c) => DashboardClient(
        host: c.host,
        port: c.dashboardPort,
        proxied: c.dashboardProxied,
        gatewayProfile: c.gatewayProfile,
        httpClient: MockClient((request) async {
          pushRequests.add(request);
          final gate = eventGate;
          if (gate != null) {
            eventGate = null;
            eventEntered!.complete();
            await gate.future;
          }
          expect(request.method, 'GET');
          expect(request.url.path, '/api/plugins/mobile-push/events');
          expect(request.url.queryParameters['profile'], 'root-profile');
          return http.Response(
            jsonEncode({'events': feed, 'has_more': false, 'next_cursor': '1'}),
            200,
          );
        }),
      ),
    );
    launch.pendingQuickChat.value =
        true; // Fixture-owned launcher input, production Home/Workspace navigation.
    await tester.pumpWidget(
      HermesApp(
        connManager: manager,
        turnApplicationController: controller,
        mobilePush: push,
        launchIntents: launch,
      ),
    );
    await widgetUntil(
      tester,
      () => find.byType(ChatScreen).evaluate().isNotEmpty,
    );
    await widgetUntil(
      tester,
      () => find
          .byKey(const ValueKey('legacy-transport-notice'))
          .evaluate()
          .isNotEmpty,
    );
    await _drain(tester);
    expect(find.byType(HermesApp), findsOneWidget);
    expect(find.byType(WorkspaceScreen, skipOffstage: false), findsOneWidget);
    expect(
      tester
          .widget<WorkspaceScreen>(
            find.byType(WorkspaceScreen, skipOffstage: false),
          )
          .turnApplicationController,
      same(controller),
    );
  }

  Future<void> canonicalTap(
    WidgetTester tester, {
    required bool viaPush,
    int mountedChats = 2,
  }) async {
    if (viaPush) {
      final expiry = DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600;
      native.addAll({
        'enabled': true,
        'active': true,
        'connection': connection.id,
        'binding': MobilePushService.binding(connection),
        'installation': 'root-spec-installation',
        'nonce': 'root-spec-nonce',
        'generation': 7,
        'revision': 1,
        'endpoint': 'https://push.invalid/opaque',
        'sessions': ['stored'],
        'tap': {
          'nonce': 'root-spec-nonce',
          'generation': 7,
          'revision': 1,
          'event_id': 'root-spec-event',
          'expires_at': expiry,
        },
      });
      feed = [
        {
          'event_id': 'root-spec-event',
          'session_id': 'stored',
          'kind': 'input',
          'expires_at': expiry,
        },
      ];
      await tester.runAsync(push.refresh);
    } else {
      tap('stored');
    }
    await widgetUntil(
      tester,
      () =>
          find.byType(ChatScreen, skipOffstage: false).evaluate().length ==
          mountedChats,
    );
    await tester.pump(const Duration(seconds: 1));
    await _drain(tester);
  }

  void tap(String id) {
    notificationResponseHandler!(
      NotificationResponse(
        payload: jsonEncode({'connectionId': connection.id, 'sessionId': id}),
        notificationResponseType: NotificationResponseType.selectedNotification,
      ),
    );
  }

  Iterable<Map<String, dynamic>> get ongoing => live.values.where(
    (n) => (n['platformSpecifics'] as Map?)?['ongoing'] == true,
  );
  Iterable<Map<String, dynamic>> get terminals => pluginCalls
      .where((c) => c.method == 'show')
      .map((c) => Map<String, dynamic>.from(c.arguments as Map))
      .where(
        (n) =>
            (n['title'] == 'Hermes response ready' ||
            n['title'] == 'Hermes turn failed'),
      );
  Future<void> close(WidgetTester tester) async {
    _lifecycle(tester, AppLifecycleState.resumed);
    await _drain(tester);
    await tester.pumpWidget(const SizedBox.shrink());
    await _drain(tester);
    await controller.close();
    await tester.runAsync(server.close);
    await tester.pump(const Duration(seconds: 16));
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    expect(find.byType(HermesApp), findsNothing);
    expect(nativeRunning, isFalse);
    expect(ongoing, isEmpty);
    expect(
      prefs.getStringList(TurnNotificationService.ongoingIdsStorageKey) ??
          <String>[],
      isEmpty,
    );
    expect(pluginCalls.where((c) => c.method == 'cancelAll'), isEmpty);
    if (recordedSchedule != null) {
      await tester.runAsync(
        () => File('review-evidence/cleanup-$recordedSchedule.json')
            .writeAsString(
              jsonEncode({
                'rootUnmounted': true,
                'nativeRunning': nativeRunning,
                'ongoingCount': ongoing.length,
                'durableOngoingIds': prefs.getStringList(
                  TurnNotificationService.ongoingIdsStorageKey,
                ),
                'keepaliveCommands': keepalive,
              }),
            ),
      );
    }
    push.dispose();
    launch.dispose();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(plugin, null);
    messenger.setMockMethodCallHandler(
      ConnectionKeepAliveService.channel,
      null,
    );
    messenger.setMockMethodCallHandler(channel, null);
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/image_picker'),
      null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('flutter_tts'),
      null,
    );
    debugDefaultTargetPlatformOverride = null;
  }
}

Future<void> _drain(WidgetTester tester) async {
  for (var i = 0; i < 12; i++) {
    await tester.pump();
  }
  await tester.pump(const Duration(milliseconds: 350));
  await tester.runAsync(() => Future<void>.delayed(Duration.zero));
  for (var i = 0; i < 6; i++) {
    await tester.pump();
  }
}

void _lifecycle(WidgetTester tester, AppLifecycleState target) {
  if (tester.binding.lifecycleState == target) return;
  if (target == AppLifecycleState.paused) {
    if (tester.binding.lifecycleState == AppLifecycleState.resumed) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.inactive) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
  } else {
    if (tester.binding.lifecycleState == AppLifecycleState.paused) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    }
    if (tester.binding.lifecycleState == AppLifecycleState.hidden) {
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    }
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
  }
}

void _seedPush(_RootAliasFixture f, {int? expiry}) {
  final deadline =
      expiry ?? DateTime.now().millisecondsSinceEpoch ~/ 1000 + 3600;
  f.native.addAll({
    'enabled': true,
    'active': true,
    'connection': f.connection.id,
    'binding': MobilePushService.binding(f.connection),
    'installation': 'root-spec-installation',
    'nonce': 'root-spec-nonce',
    'generation': 7,
    'revision': 1,
    'endpoint': 'https://push.invalid/opaque',
    'sessions': ['stored'],
    'tap': {
      'nonce': 'root-spec-nonce',
      'generation': 7,
      'revision': 1,
      'event_id': 'independent-event',
      'expires_at': deadline,
    },
  });
  f.feed = [
    {
      'event_id': 'independent-event',
      'session_id': 'stored',
      'kind': 'input',
      'expires_at': deadline,
    },
  ];
}

Future<String> _startSource(WidgetTester tester, _RootAliasFixture f) async {
  final id = tester.widget<ChatScreen>(find.byType(ChatScreen)).session.id;
  await tester.enterText(find.byType(TextField), 'Independent source request');
  await tester.tap(find.byTooltip('Send'));
  await widgetUntil(tester, () => f.server.createEntered.isCompleted);
  return id;
}

Future<void> _cover(WidgetTester tester, State state) async {
  Navigator.of(state.context).push<void>(
    MaterialPageRoute(
      builder: (_) => const Scaffold(body: Text('Independent retained cover')),
    ),
  );
  await tester.pump();
  await tester.pump(const Duration(seconds: 1));
  await _drain(tester);
  expect(ModalRoute.of(state.context)!.isCurrent, isFalse);
}

Future<void> _record(
  WidgetTester tester,
  _RootAliasFixture f,
  String name,
  Map<String, dynamic> facts,
) async {
  f.recordedSchedule = name;
  final data = {
    'schedule': name,
    ...facts,
    'keepalive': f.keepalive,
    'native': f.nativeCalls
        .map((c) => {'method': c.method, 'arguments': c.arguments})
        .toList(),
    'plugin': f.pluginCalls
        .map((c) => {'method': c.method, 'arguments': c.arguments})
        .toList(),
    'pushURLs': f.pushRequests.map((r) => r.url.toString()).toList(),
    'httpPaths': f.server.requests,
    'wirePrompts': f.server.prompts,
    'mountedIds': tester
        .widgetList<ChatScreen>(find.byType(ChatScreen, skipOffstage: false))
        .map((c) => c.session.id)
        .toList(),
  };
  await tester.runAsync(
    () => File(
      'review-evidence/independent-$name.json',
    ).writeAsString(jsonEncode(data)),
  );
}

Finder _tools() => find.byType(GatewayActivityCard);
bool _toolExpanded(WidgetTester tester) => tester
    .widget<ExpansionTile>(
      find.descendant(of: _tools(), matching: find.byType(ExpansionTile)),
    )
    .controller!
    .isExpanded;
Finder _reason() => find.byWidgetPredicate(
  (w) =>
      w is GatewayReasoningCard &&
      w.text.contains('Independent donor reasoning'),
);
bool _reasonExpanded(WidgetTester tester) => tester
    .widget<ExpansionTile>(
      find.descendant(of: _reason(), matching: find.byType(ExpansionTile)),
    )
    .controller!
    .isExpanded;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });
  for (final width in [400.0, 1000.0]) {
    for (final failedHistory in [false, true]) {
      for (final revokedPush in [false, true]) {
        testWidgets(
          'FRESH root canonical visit tokens late-ID retained pin draft scroll historyFailed=$failedHistory revokedPush=$revokedPush width=$width',
          (tester) async {
            await tester.binding.setSurfaceSize(Size(width, 1800));
            addTearDown(() => tester.binding.setSurfaceSize(null));
            final f = _RootAliasFixture();
            await f.initialize(tester);
            final nativeGate = Completer<Map<String, dynamic>>();
            try {
              final localId = await _startSource(tester, f);
              await f.canonicalTap(tester, viaPush: false);
              final canonicalState = tester.state(find.byType(ChatScreen));
              final canonicalRoute = ModalRoute.of(canonicalState.context)!;
              final normal = f.controller.normalSessionFor(f.connection);
              final canonical = normal.findChat('stored')!;
              await tester.enterText(
                find.byType(TextField),
                'Independent canonical active request',
              );
              await tester.tap(find.byTooltip('Send'));
              await widgetUntil(tester, () => f.server.prompts.length == 1);
              f.server.event('message.start', {}, turnId: 'wire-1');
              f.server.event('reasoning.delta', {
                'text': 'Independent donor reasoning',
              }, turnId: 'wire-1');
              f.server.event('tool.start', {
                'tool': 'terminal',
                'detail': 'Original anonymous detail',
              }, turnId: 'wire-1');
              await widgetUntil(
                tester,
                () =>
                    _tools().evaluate().isNotEmpty &&
                    _reason().evaluate().isNotEmpty,
              );
              expect(_toolExpanded(tester), isFalse);
              expect(_reasonExpanded(tester), isFalse);
              final reasonId = tester
                  .widget<GatewayReasoningCard>(_reason())
                  .id;
              await tester.tap(
                find.descendant(
                  of: _reason(),
                  matching: find.text('Reasoning'),
                ),
              );
              await tester.pump(const Duration(milliseconds: 350));
              await tester.tap(find.text('Tool activity'));
              await tester.pump(const Duration(milliseconds: 350));
              expect(_toolExpanded(tester), isTrue);
              expect(_reasonExpanded(tester), isTrue);
              await tester.enterText(
                find.byType(TextField),
                'Independent retained next draft',
              );
              // Enough prose to evict detailed cards from the real sliver.
              f.server.event('message.delta', {
                'text': List.generate(
                  80,
                  (i) => 'Fresh root retained line $i.',
                ).join('\n\n'),
              }, turnId: 'wire-1');
              await _drain(tester);
              final scroll = tester
                  .stateList<ScrollableState>(
                    find.descendant(
                      of: find.byType(ChatScreen),
                      matching: find.byType(Scrollable),
                    ),
                  )
                  .firstWhere((s) => s.position.maxScrollExtent > 300);
              await tester.drag(
                find.byType(ListView).first,
                const Offset(0, 400),
              );
              scroll.position.jumpTo(120);
              await _drain(tester);
              final before = scroll.position.pixels;
              f.tap(localId);
              await widgetUntil(
                tester,
                () =>
                    find
                        .byType(ChatScreen, skipOffstage: false)
                        .evaluate()
                        .length ==
                    3,
              );
              await tester.pump(const Duration(seconds: 1));
              await _drain(tester);
              final localState = tester.state(find.byType(ChatScreen));
              expect(localState, isNot(same(canonicalState)));
              f.server.historyUnavailable = failedHistory;
              f.server.releaseCreate();
              await widgetUntil(
                tester,
                () => identical(
                  normal.findChat(localId),
                  normal.findChat('stored'),
                ),
              );
              // Binding reattaches to a long streamed view at the live end.
              // Reveal the early card through the actual lazy list first.
              final localScroll = tester
                  .stateList<ScrollableState>(
                    find.descendant(
                      of: find.byType(ChatScreen),
                      matching: find.byType(Scrollable),
                    ),
                  )
                  .firstWhere((s) => s.position.axis == Axis.vertical);
              localScroll.position.jumpTo(0);
              await _drain(tester);
              await widgetUntil(tester, () => _tools().evaluate().isNotEmpty);
              expect(
                _toolExpanded(tester),
                isFalse,
                reason:
                    'new actual State must not borrow canonical manual choice',
              );
              // Pin explicitly closed, not merely the default, independently.
              await tester.tap(find.text('Tool activity'));
              await tester.pump(const Duration(milliseconds: 350));
              await tester.tap(find.text('Tool activity'));
              await tester.pump(const Duration(milliseconds: 350));
              f.server.event('tool.progress', {
                'tool': 'terminal',
                'tool_id': 'fresh-late-tool',
                'detail': 'Learned durable detail',
              }, turnId: 'wire-1');
              await widgetUntil(
                tester,
                () => canonical.snapshot.tools.any(
                  (a) => a.toolId == 'fresh-late-tool',
                ),
              );
              await _drain(tester);
              localScroll.position.jumpTo(0);
              await _drain(tester);
              expect(_toolExpanded(tester), isFalse);
              expect(find.text('Terminal: Working'), findsOneWidget);
              expect(find.text('Learned durable detail'), findsNothing);
              await _cover(tester, localState);
              if (revokedPush) {
                _seedPush(f);
                f.snapshotGate = nativeGate;
                f.snapshotEntered = Completer<void>();
                // Push refresh first reads native state. Capture that read, then
                // use the ordinary alias tap while the old proof is outstanding.
                final refresh = f.push.refresh();
                await widgetUntil(tester, () => f.snapshotEntered!.isCompleted);
                final captured = Map<String, dynamic>.from(f.native);
                final disabling = f.push.disable();
                await widgetUntil(tester, () => f.native['enabled'] == false);
                f.tap(localId);
                nativeGate.complete(captured);
                await tester.runAsync(() async {
                  await disabling;
                  await refresh;
                });
              } else {
                f.tap('stored');
              }
              await widgetUntil(tester, () => canonicalRoute.isCurrent);
              await tester.pump(const Duration(seconds: 1));
              await _drain(tester);
              expect(
                tester.state(find.byType(ChatScreen)),
                same(canonicalState),
              );
              expect(localState.mounted, isFalse);
              expect(
                find.byType(ChatScreen, skipOffstage: false),
                findsNWidgets(2),
              );
              expect(scroll.mounted, isTrue);
              final afterFocus = scroll.position.pixels;
              final routeWasCurrent = canonicalRoute.isCurrent;
              expect(afterFocus, closeTo(before, 1));
              expect(
                tester
                    .widget<TextField>(find.byType(TextField))
                    .controller!
                    .text,
                'Independent retained next draft',
              );
              // Bring the actual lazy cards back into view, preserving their pins.
              scroll.position.jumpTo(0);
              await _drain(tester);
              expect(_toolExpanded(tester), isTrue);
              expect(_reasonExpanded(tester), isTrue);
              expect(
                tester.widget<GatewayReasoningCard>(_reason()).id,
                reasonId,
              );
              expect(find.text('Learned durable detail'), findsOneWidget);
              expect(
                f.server.prompts,
                hasLength(1),
                reason: 'retired prewire source is never replayed',
              );
              _lifecycle(tester, AppLifecycleState.paused);
              await _drain(tester);
              expect(f.nativeRunning, isTrue);
              expect(f.ongoing, hasLength(1));
              expect(
                await tester.runAsync(
                  () => ComposerDraftStore.read(
                    connectionId: f.connection.id,
                    sessionId: 'stored',
                  ),
                ),
                'Independent retained next draft',
              );
              f.server.running = false;
              f.server.event('tool.complete', {
                'tool': 'terminal',
                'tool_id': 'fresh-late-tool',
                'summary': 'Final retained tool summary',
              }, turnId: 'wire-1');
              f.server.event('message.complete', {
                'text': 'Final received answer with lagging history',
              }, turnId: 'wire-1');
              f.server.event('turn.end', {
                'status': 'completed',
              }, turnId: 'wire-1');
              await widgetUntil(tester, () => !f.controller.hasActiveTurn);
              await _drain(tester);
              expect(f.terminals, hasLength(1));
              expect(f.ongoing, isEmpty);
              expect(f.nativeRunning, isFalse);
              _lifecycle(tester, AppLifecycleState.resumed);
              await _drain(tester);
              Navigator.of(canonicalState.context).pop();
              await tester.pump();
              await tester.pump(const Duration(seconds: 1));
              await _drain(tester);
              expect(canonicalState.mounted, isFalse);
              f.tap('stored');
              await widgetUntil(
                tester,
                () =>
                    find
                        .byType(ChatScreen, skipOffstage: false)
                        .evaluate()
                        .length ==
                    2,
              );
              await tester.pump(const Duration(seconds: 1));
              await _drain(tester);
              final reopened = tester.state(find.byType(ChatScreen));
              expect(reopened, isNot(same(canonicalState)));
              // Lazy scrolling may be restored; reveal the original tool group.
              final reopenedScroll = tester
                  .stateList<ScrollableState>(
                    find.descendant(
                      of: find.byType(ChatScreen),
                      matching: find.byType(Scrollable),
                    ),
                  )
                  .firstWhere((s) => s.position.axis == Axis.vertical);
              reopenedScroll.position.jumpTo(0);
              await _drain(tester);
              expect(_toolExpanded(tester), isFalse);
              expect(
                _reasonExpanded(tester),
                isFalse,
                reason: 'MAIN81D third policy layer: true disposal resets reasoning choice too, never its retained body or same-visit identity',
              );
              expect(find.text('Terminal: Completed'), findsOneWidget);
              expect(find.text('Final retained tool summary'), findsNothing);
              await tester.tap(find.text('Tool activity'));
              await tester.pump(const Duration(milliseconds: 350));
              expect(find.text('Final retained tool summary'), findsOneWidget);
              expect(
                tester
                    .widget<TextField>(find.byType(TextField))
                    .controller!
                    .text,
                'Independent retained next draft',
              );
              expect(f.server.prompts, hasLength(1));
              await _record(
                tester,
                f,
                'fresh-visit-$width-$failedHistory-$revokedPush',
                {
                  'retainedRouteCurrentAtFocus': routeWasCurrent,
                  'exactStatePreservedBeforeDisposal': true,
                  'localDisposed': !localState.mounted,
                  'canonicalDisposed': !canonicalState.mounted,
                  'reopenNewState': true,
                  'withinVisitToolOpen': true,
                  'reopenToolClosed': true,
                  'reasoningStillOpen': true,
                  'reasoningId': reasonId,
                  'scrollBefore': before,
                  'scrollAfterFocus': afterFocus,
                  'historyUnavailable': failedHistory,
                  'draft': tester
                      .widget<TextField>(find.byType(TextField))
                      .controller!
                      .text,
                },
              );
            } finally {
              if (!nativeGate.isCompleted) {
                nativeGate.complete(Map<String, dynamic>.from(f.native));
              }
              await f.close(tester);
            }
          },
        );
      }
    }
  }
}
