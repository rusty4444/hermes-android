import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() => HttpOverrides.global = previous);

  for (final canonicalBeforeReply in [false, true]) {
    test(
      'real binding wire: canonical before create reply=$canonicalBeforeReply converges owners',
      () async {
        final server = await _BindingServer.start();
        final controller = GatewayTurnApplicationController();
        addTearDown(() async {
          await controller.close();
          await server.close();
        });
        final session = controller.normalSessionFor(server.connection);
        await session.ready;
        final local = session.chatFor('local', title: 'Original draft');
        final ensuring = session.client!.ensureSession('local');
        Object? error;
        final checked = ensuring.then<void>(
          (_) {},
          onError: (Object e) {
            error = e;
          },
        );
        await server.createEntered.future;
        if (canonicalBeforeReply) {
          session.chatFor(
            'stored',
            storedSessionId: 'stored',
            title: 'Opened from list',
          );
        }
        server.releaseCreate();
        await checked;
        final canonical = session.chatFor(
          'stored',
          storedSessionId: 'stored',
          title: 'Canonical',
        );
        // The historical probe's two retries expected zero wire frames only
        // because the old bind failed. On the corrected client they submit and
        // wait for a terminal this old fixture never emits. Keep that original
        // file intact; this adaptation isolates its original binding assertion.
        final retryErrors = <Object>[];
        debugPrint(
          'WIRE_COLLISION before=$canonicalBeforeReply error=$error localStored=${local.storedSessionId} transportStored=${session.client!.storedSessionKeyFor('local')} sameOwner=${identical(local, canonical)} retryErrors=$retryErrors phase=${local.phase} wire=${local.wireEmitted} prompts=${server.prompts}',
        );
        expect(error, isNull);
        expect(local.storedSessionId, 'stored');
        expect(identical(local, canonical), isTrue);
        expect(server.prompts, 0);
      },
    );
  }
}

class _BindingServer {
  final HttpServer server;
  final sockets = <WebSocket>[];
  final createEntered = Completer<void>();
  late void Function() releaseCreate;
  int prompts = 0;
  _BindingServer(this.server);
  SavedConnection get connection => SavedConnection(
    id: 'quality-binding-wire',
    label: 'Fixture',
    host: '127.0.0.1',
    port: server.port,
    apiKey: 'fixture',
    dashboardPortOverride: server.port,
    dashboardProxied: true,
  );
  static Future<_BindingServer> start() async {
    final owner = _BindingServer(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    owner.server.listen(owner.handle);
    return owner;
  }

  Future<void> handle(HttpRequest request) async {
    if (request.uri.path == '/api/auth/ws-ticket') {
      request.response.headers.contentType = ContentType.json;
      request.response.write('{"ticket":"fixture"}');
      await request.response.close();
      return;
    }
    if (request.uri.path != '/api/ws') {
      request.response.statusCode = 404;
      await request.response.close();
      return;
    }
    final socket = await WebSocketTransformer.upgrade(request);
    sockets.add(socket);
    socket.add(
      jsonEncode({
        'jsonrpc': '2.0',
        'method': 'event',
        'params': {'type': 'gateway.ready', 'payload': {}},
      }),
    );
    socket.listen((raw) {
      final frame = jsonDecode(raw as String) as Map;
      final method = frame['method'];
      if (method == null) return;
      final result = <String, dynamic>{'jsonrpc': '2.0', 'id': frame['id']};
      if (method == 'session.resume') {
        result['error'] = {'code': 4007, 'message': 'session not found'};
      } else if (method == 'session.create') {
        result['result'] = {
          'session_id': 'runtime',
          'stored_session_id': 'stored',
          'message_count': 0,
          'messages': [],
        };
        final encoded = jsonEncode(result);
        releaseCreate = () => socket.add(encoded);
        createEntered.complete();
        return;
      } else {
        if (method == 'prompt.submit') prompts++;
        result['result'] = {'ok': true};
      }
      socket.add(jsonEncode(result));
    });
  }

  Future<void> close() async {
    for (final socket in sockets) {
      await socket.close();
    }
    await server.close(force: true);
  }
}
