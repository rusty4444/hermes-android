import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hermes_android/core/screens/chat_screen.dart';
import 'package:hermes_android/l10n/app_localizations.dart';
import 'support/fake_voice_composer_adapter.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/connection_manager.dart';
import 'package:hermes_android/core/services/desktop_gateway_client.dart';
import 'package:hermes_android/core/services/gateway_turn_application_controller.dart';
import 'package:hermes_android/core/services/normal_gateway_application_session.dart';
import 'package:hermes_android/core/services/normal_gateway_pending_store.dart';
import 'package:hermes_android/core/services/ws_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences_platform_interface/shared_preferences_platform_interface.dart';

import 'normal_gateway_alias_handoff_wire_test.dart'
    show BindingServer, send, until, widgetUntil;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() => HttpOverrides.global = previous);

  testWidgets(
    'SPEC mounted canonical ChatScreen keeps received settled answer during original bind',
    (tester) async {
      const picker = MethodChannel('plugins.flutter.io/image_picker');
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
        picker,
        (_) async => null,
      );
      addTearDown(
        () => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
          picker,
          null,
        ),
      );
      await tester.binding.setSurfaceSize(const Size(400, 1000));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final wire = (await tester.runAsync(_HistoryWire.start))!;
      final controller = GatewayTurnApplicationController();
      addTearDown(() async {
        await controller.close();
        await wire.close();
      });
      final session = controller.normalSessionFor(wire.connection);
      var ready = false;
      session.ready.then((_) => ready = true);
      await widgetUntil(tester, () => ready);
      final source = session.chatFor('local', title: 'Original');
      send(source, 'Original pending').ignore();
      await widgetUntil(tester, () => wire.createEntered.isCompleted);
      // Another client writes only after the encoded empty allocation reply.
      wire.rows.add(_row(37, 'Existing context'));
      await tester.pumpWidget(
        MaterialApp(
          localizationsDelegates: AppLocalizations.localizationsDelegates,
          supportedLocales: AppLocalizations.supportedLocales,
          home: ChatScreen(
            connection: wire.connection,
            session: const Session(
              id: 'stored',
              title: 'Canonical',
              model: 'fixture',
              source: 'test',
              messageCount: 1,
              isActive: false,
              preview: '',
              startedAt: 1,
            ),
            turnApplicationController: controller,
            testVoiceComposerAdapter: FakeVoiceComposerAdapter(),
          ),
        ),
      );
      final canonical = session.findChat('stored')!;
      await widgetUntil(
        tester,
        () => canonical.snapshot.historyRows.isNotEmpty,
      );
      final mountedState = tester.state(find.byType(ChatScreen));
      final prior = send(canonical, 'Earlier canonical prompt');
      prior.ignore();
      await widgetUntil(tester, () => wire.prompts.length == 1);
      wire.finishWithoutPersist('Visible received canonical answer');
      await widgetUntil(tester, () => !canonical.snapshot.hasActiveTurn);
      await widgetUntil(
        tester,
        () => find
            .text('Visible received canonical answer', findRichText: true)
            .evaluate()
            .isNotEmpty,
      );
      expect(
        find.text('Visible received canonical answer', findRichText: true),
        findsOneWidget,
      );
      wire.releaseCreate();
      await widgetUntil(tester, () => wire.prompts.length == 2);
      await tester.pump();
      expect(tester.state(find.byType(ChatScreen)), same(mountedState));
      debugPrint(
        'MOUNTED_SETTLED_TAIL visible=${find.text('Visible received canonical answer', findRichText: true).evaluate().length} display=${canonical.snapshot.displayRows}',
      );
      expect(
        find.text('Visible received canonical answer', findRichText: true),
        findsOneWidget,
        reason:
            'the same mounted real route must not lose a received answer while its HTTP persistence still lags',
      );
      await tester.pumpWidget(const SizedBox.shrink());
      await controller.close();
      await tester.runAsync(wire.close);
      await tester.pump(const Duration(seconds: 16));
    },
  );

  for (final known in [false, true]) {
    test(
      'SPEC settled canonical received tail survives pending-original handoff known=$known',
      () async {
        final wire = await _HistoryWire.start();
        wire.historyUnavailable = !known;
        final controller = GatewayTurnApplicationController();
        addTearDown(() async {
          await controller.close();
          await wire.close();
        });
        final session = controller.normalSessionFor(wire.connection);
        await session.ready;
        final source = session.chatFor('local', title: 'Original');
        final original = send(source, 'Original pending');
        original.ignore();
        await wire.createEntered.future;
        if (known) wire.rows.add(_row(37, 'Known old context'));
        final canonical = session.chatFor(
          'stored',
          storedSessionId: 'stored',
          title: 'Canonical',
        );
        final prior = send(canonical, 'Earlier canonical prompt');
        prior.ignore();
        await wire.untilPrompts(1);
        wire.event('message.start', {}, turnId: 'wire-1');
        wire.event('reasoning.delta', {
          'text': 'Retain earlier reasoning',
        }, turnId: 'wire-1');
        wire.event('tool.start', {
          'tool': 'read_file',
          'tool_id': 'earlier-tool',
        }, turnId: 'wire-1');
        wire.finishWithoutPersist('Earlier received answer');
        await prior;
        await until(
          () => !canonical.snapshot.hasActiveTurn && wire.historyReads >= 2,
        );
        expect(
          canonical.snapshot.displayRows.any(
            (r) => r['content'] == 'Earlier received answer',
          ),
          isTrue,
        );
        expect(canonical.snapshot.tools, isNotEmpty);
        expect(
          canonical.snapshot.displayRows.any(
            (r) => r['_gateway_reasoning'] == 'Retain earlier reasoning',
          ),
          isTrue,
        );
        wire.releaseCreate();
        await wire.untilPrompts(2);
        final state = source.snapshot;
        debugPrint(
          'SETTLED_TAIL known=$known floor=${state.rowFloor} display=${state.displayRows} tools=${state.tools.length} runs=${state.timeline.runs.length}',
        );
        expect(
          state.displayRows.any(
            (r) => r['content'] == 'Earlier received answer',
          ),
          isTrue,
          reason:
              'alias selection cannot erase an independently received settled response during ordinary persistence lag',
        );
        expect(state.tools.any((t) => t.toolId == 'earlier-tool'), isTrue);
        expect(
          state.displayRows.any(
            (r) => r['_gateway_reasoning'] == 'Retain earlier reasoning',
          ),
          isTrue,
        );
        expect(wire.prompts.map((p) => p['text']), [
          'Earlier canonical prompt',
          'Original pending',
        ]);
        await controller.close();
        await original;
      },
    );
  }

  test(
    'SPEC old physical settled GET cannot supersede newer latest observation before handoff',
    () async {
      final wire = await _HistoryWire.start();
      final client = DesktopGatewayClient.fromConnection(wire.connection);
      final api = ApiClient(
        baseUrl: wire.connection.baseUrl,
        apiKey: 'fixture',
      );
      final flights = <Future<List<Map<String, dynamic>>>>[];
      final session = NormalGatewayApplicationSession(
        connection: wire.connection,
        scope: 'freshness',
        client: client,
        history: (id) {
          final flight = api.getMessages(id, limit: 50, latest: true);
          flights.add(flight);
          return flight;
        },
      );
      addTearDown(() async {
        wire.releaseHeldHistory();
        await session.close();
        api.close();
        await wire.close();
      });
      await session.ready;
      final source = session.chatFor('local', title: 'Original');
      final original = send(source, 'New pending');
      original.ignore();
      await wire.createEntered.future;
      wire.rows.add(_row(37, 'Old persisted context'));
      final canonical = session.chatFor(
        'stored',
        storedSessionId: 'stored',
        title: 'Canonical',
      );
      final prior = send(canonical, 'Prior prompt');
      prior.ignore();
      await wire.untilPrompts(1);
      wire.holdNextHistory = true;
      wire.finishWithoutPersist('Prior received');
      await prior;
      await wire.historyHeld.future;
      final oldFlight = flights.last;
      wire.rows
        ..clear()
        ..addAll([
          _row(98, 'Prior prompt', role: 'user'),
          _row(99, 'Prior durable answer'),
        ]);
      final routeApi = ApiClient(
        baseUrl: wire.connection.baseUrl,
        apiKey: 'fixture',
      );
      canonical.observeHistory(
        await routeApi.getMessages('stored', limit: 50, latest: true),
      );
      routeApi.close();
      expect(canonical.snapshot.historyRows.last['id'], 99);
      wire.releaseHeldHistory();
      await oldFlight;
      await pumpEventQueue();
      wire.releaseCreate();
      await wire.untilPrompts(2);
      final markers = await session.pendingStore.load('freshness');
      final admittedFloor = source.snapshot.rowFloor;
      final beforeFinish = wire.historyReads;
      wire.finishWithoutPersist('Current received must survive');
      await original;
      await until(
        () =>
            !source.snapshot.hasActiveTurn && wire.historyReads > beforeFinish,
      );
      await flights.last;
      await pumpEventQueue();
      final retained = source.snapshot.displayRows.any(
        (row) => row['content'] == 'Current received must survive',
      );
      debugPrint(
        'OLD_SETTLED_GET floor=$admittedFloor receipt=${markers.single.rowFloor} retainedCurrent=$retained history=${source.snapshot.historyRows} display=${source.snapshot.displayRows}',
      );
      expect(
        admittedFloor,
        99,
        reason:
            'an older internally-owned GET cannot become the newest observation merely by completing last',
      );
      expect(markers.single.rowFloor, 99);
      expect(retained, isTrue);
      await session.close();
    },
  );

  for (final latest in ['empty', 'unidentified', 'failed']) {
    test(
      'SPEC fresh canonical prewire boundary $latest does not invent numeric authority',
      () async {
        final wire = await _HistoryWire.start();
        final controller = GatewayTurnApplicationController();
        addTearDown(() async {
          await controller.close();
          await wire.close();
        });
        final session = controller.normalSessionFor(wire.connection);
        await session.ready;
        final source = session.chatFor('local', title: 'Source');
        source.observeHistory([_row(37, 'Older context')]);
        final pending = send(source, 'One prompt');
        pending.ignore();
        await wire.createEntered.future;
        final canonical = session.chatFor(
          'stored',
          storedSessionId: 'stored',
          title: 'Canonical',
        );
        wire.historyUnavailable = latest == 'failed';
        if (latest == 'unidentified') {
          wire.rows.add({
            'role': 'assistant',
            'content': 'Unknown row identity',
          });
        }
        final api = ApiClient(
          baseUrl: wire.connection.baseUrl,
          apiKey: 'fixture',
        );
        try {
          canonical.observeHistory(
            await api.getMessages('stored', limit: 50, latest: true),
          );
        } catch (_) {
          expect(latest, 'failed');
        } finally {
          api.close();
        }
        wire.releaseCreate();
        await wire.untilPrompts(1);
        final int? expected = latest == 'empty'
            ? 0
            : latest == 'failed'
            ? 37
            : null;
        expect(source.snapshot.rowFloor, expected);
        expect(
          (await session.pendingStore.load(session.scope)).single.rowFloor,
          expected,
        );
        expect(wire.prompts, hasLength(1));
        await controller.close();
        await pending;
      },
    );
  }

  for (final sourceEarliest in [false, true]) {
    test(
      'SPEC widened child multi-observation interval keeps first durable anchor sourceEarliest=$sourceEarliest',
      () async {
        final f = _Owners();
        addTearDown(f.session.close);
        await f.session.ready;
        final source = f.session.chatFor('local', title: 'Source');
        final canonical = f.session.chatFor(
          'stored',
          storedSessionId: 'stored',
          title: 'Canonical',
        );
        final first = sourceEarliest ? 'local' : 'stored';
        final second = sourceEarliest ? 'stored' : 'local';
        void child(String alias, String id, String goal) =>
            f.session.receiveEvent(
              alias,
              StreamEvent(
                type: 'subagent.progress',
                data: {
                  'subagent_id': 'same-task',
                  'child_session_id': id,
                  'goal': goal,
                },
              ),
            );
        // The source/store alias seam deliberately covers both owners having
        // observed an interval; it is not stock create publishing its ID post-WAL.
        child(first, 'first-root', 'First goal');
        child(second, 'middle-tip', 'Second goal');
        child(first, 'latest-tip', 'Last goal');
        source.bindStoredSession('stored');
        final task = canonical.snapshot.subagents.single;
        debugPrint(
          'CHILD_INTERVAL earliestSource=$sourceEarliest anchor=${task.childSessionId} latest=${task.latestChildSessionId} goal=${task.goal}',
        );
        expect(
          task.childSessionId,
          'first-root',
          reason:
              'first durable anchor is immutable, not selected by which aggregate has the latest update',
        );
        expect(task.latestChildSessionId, 'latest-tip');
        expect(task.goal, 'Last goal');
      },
    );
  }

  test(
    'SPEC old queued rejection is fenced from a newer admission before its microtask',
    () async {
      final f = _Owners();
      addTearDown(f.session.close);
      await f.session.ready;
      final source = f.session.chatFor('local', title: 'Source');
      final canonical = f.session.chatFor(
        'stored',
        storedSessionId: 'stored',
        title: 'Canonical',
      );
      source.reserve();
      final oldCanonical = canonical.reserve()!;
      final seen = <NormalGatewayChatSnapshot>[];
      source.subscribe(seen.add);
      source.bindStoredSession('stored');
      canonical.cancelPreparation(oldCanonical);
      final next = canonical.reserve()!;
      final nextTurn = canonical.turnId;
      seen.clear();
      await pumpEventQueue();
      debugPrint(
        'QUEUED_REJECTION newTurn=$nextTurn seen=${seen.map((s) => '${s.turnId}:${s.phase.name}').toList()}',
      );
      expect(
        seen.every(
          (state) =>
              state.turnId == nextTurn &&
              state.phase == NormalGatewayTurnPhase.preparing,
        ),
        isTrue,
        reason:
            'queued prior rejection may not publish an obsolete turn after a new admission exists',
      );
      canonical.cancelPreparation(next);
    },
  );

  test(
    'SPEC reload failure does not trust cache or poison queued same-store successor',
    () async {
      final prefs = await SharedPreferences.getInstance();
      final platform = _ReloadFailure(
        await SharedPreferencesStorePlatform.instance.getAll(),
      );
      final original = SharedPreferencesStorePlatform.instance;
      SharedPreferencesStorePlatform.instance = platform;
      addTearDown(() => SharedPreferencesStorePlatform.instance = original);
      final a = NormalGatewayPendingStore(preferences: () async => prefs);
      final b = NormalGatewayPendingStore(preferences: () async => prefs);
      platform.failNext = true;
      final first = a.put(_marker('a', 'a-turn'));
      final second = b.put(_marker('b', 'b-turn'));
      await expectLater(first, throwsStateError);
      await second;
      expect(platform.writes, 1);
      expect((await a.load('scope')).map((r) => r.turnId), ['b-turn']);
    },
  );

  test(
    'SPEC existing null WAL floor stays immutable through later canonical read',
    () async {
      final f = _Owners(history: (_) async => throw StateError('unavailable'));
      addTearDown(f.session.close);
      await f.session.ready;
      final source = f.session.chatFor(
        'local',
        storedSessionId: 'prealias',
        title: 'Source',
      );
      f.send(source).ignore();
      await f.submitted.future;
      expect(source.snapshot.rowFloor, isNull);
      final canonical = f.session.chatFor(
        'stored',
        storedSessionId: 'stored',
        title: 'Canonical',
      );
      canonical.observeHistory([_row(99, 'Later context')]);
      source.bindStoredSession('stored');
      expect(source.snapshot.rowFloor, isNull);
      expect((await f.store.load('scope')).single.rowFloor, isNull);
    },
  );

  test(
    'SPEC ambiguous three-receipt restart cannot settle by its own live bookends',
    () async {
      final store = NormalGatewayPendingStore();
      for (final id in ['a', 'b', 'c']) {
        await store.put(
          _marker(id, '$id-turn', phase: id == 'b' ? 'emitted' : 'write_ahead'),
        );
      }
      final f = _Owners();
      addTearDown(f.session.close);
      await f.session.ready;
      final owner = f.session.findChat('stored')!;
      expect(owner.turnId, 'b-turn');
      expect(owner.snapshot.rowFloor, isNull);
      f.session.receiveEvent(
        'stored',
        StreamEvent(type: 'message.start', data: {}, turnId: 'observed'),
      );
      f.session.receiveEvent(
        'stored',
        StreamEvent(type: 'turn.end', data: {}, turnId: 'observed'),
      );
      await pumpEventQueue();
      expect(owner.snapshot.hasActiveTurn, isTrue);
      expect(await store.load('scope'), hasLength(3));
      f.resume.complete(
        const ResumedGatewaySession(
          runtimeSessionId: 'runtime',
          running: false,
          status: 'completed',
        ),
      );
      await until(() => !owner.snapshot.hasActiveTurn);
      expect(owner.phase, NormalGatewayTurnPhase.reconciledUnknown);
      expect(await store.load('scope'), isEmpty);
      expect(f.submissions, 0);
    },
  );
}

class _HistoryWire extends BindingServer {
  _HistoryWire(super.server);
  int historyReads = 0;
  bool holdNextHistory = false;
  final historyHeld = Completer<void>();
  Completer<void>? gate;
  static Future<_HistoryWire> start() async {
    final f = _HistoryWire(
      await HttpServer.bind(InternetAddress.loopbackIPv4, 0),
    );
    f.server.listen(f.handle);
    return f;
  }

  @override
  Future<void> handle(HttpRequest request) async {
    if (request.uri.path.endsWith('/messages')) {
      historyReads++;
      if (holdNextHistory) {
        holdNextHistory = false;
        gate = Completer<void>();
        final captured = jsonEncode({'data': rows});
        historyHeld.complete();
        await gate!.future;
        request.response.headers.contentType = ContentType.json;
        request.response.write(captured);
        await request.response.close();
        return;
      }
    }
    return super.handle(request);
  }

  void releaseHeldHistory() {
    if (gate != null && !gate!.isCompleted) gate!.complete();
  }

  void finishWithoutPersist(String text) {
    running = false;
    final turn = 'wire-${prompts.length}';
    event('message.start', {}, turnId: turn);
    event('message.delta', {'text': text}, turnId: turn);
    event('message.complete', {'text': text}, turnId: turn);
    event('turn.end', {}, turnId: turn);
  }
}

class _Owners {
  final store = NormalGatewayPendingStore();
  late final NormalGatewayApplicationSession session;
  final submitted = Completer<void>();
  final resume = Completer<ResumedGatewaySession>();
  final rpc = Completer<void>();
  int submissions = 0;
  _Owners({NormalGatewayHistory? history}) {
    session = NormalGatewayApplicationSession(
      connection: SavedConnection(
        id: 'unit-alias',
        label: 'Unit',
        host: 'fixture.invalid',
        port: 8642,
        apiKey: 'fixture',
      ),
      scope: 'scope',
      pendingStore: store,
      history: history ?? (_) async => [_row(99, 'Context')],
      resume: ({required localSessionId, required storedSessionId}) =>
          resume.future,
      submit:
          ({
            required sessionId,
            required text,
            required onEvent,
            required onSent,
          }) {
            submissions++;
            if (!submitted.isCompleted) submitted.complete();
            return rpc.future;
          },
    );
  }
  Future<void> send(NormalGatewayChatOwner owner) => owner.submitPrepared(
    reservation: owner.reserve()!,
    text: 'Prompt',
    localContent: 'Prompt',
  );
}

class _ReloadFailure extends InMemorySharedPreferencesStore {
  _ReloadFailure(super.data) : super.withData();
  bool failNext = false;
  int writes = 0;
  @override
  Future<Map<String, Object>> getAll() async {
    if (failNext) {
      failNext = false;
      throw StateError('physical reload failed');
    }
    return super.getAll();
  }

  @override
  Future<bool> setValue(String valueType, String key, Object value) {
    writes++;
    return super.setValue(valueType, key, value);
  }
}

Map<String, dynamic> _row(
  int id,
  String content, {
  String role = 'assistant',
}) => {'id': id, 'role': role, 'content': content};
NormalGatewayPendingMarker _marker(
  String id,
  String turn, {
  String phase = 'write_ahead',
}) => NormalGatewayPendingMarker(
  scope: 'scope',
  localSessionId: id,
  storedSessionId: 'stored',
  turnId: turn,
  rowFloor: 37,
  phase: phase,
  createdAt: 1,
  updatedAt: 1,
);
