import gzip, hashlib, io, json, shutil, tarfile
from pathlib import Path
R=Path(__file__).parent; S=Path('/Volumes/Storage/Hermes/workspace/hermes-android-recovery-owner-detach'); D=S/'docs/recovery-owner-detach'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(R/'VERIFICATION.json',D/'verification.json')
shutil.copy2(R/'CASE-IDS.json.gz',D/'case-ids.json.gz')
shutil.copy2(R.parent/'recovery-owner-detach-setup.py',R/'setup-script.py')
items={}
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.log','.diff'] and p.name not in ['EVIDENCE-MANIFEST.json','ARTIFACT-CHECK.json','POST-COMMIT.json']:
  items[str(p.relative_to(R))]=p
for p in (R/'raw-before').rglob('*'):
 if p.is_file():items[str(p.relative_to(R))]=p
for d in R.glob('*-widget-evidence'):
 for p in d.rglob('*'):
  if p.is_file():items[str(p.relative_to(R))]=p
for p in json.loads((R/'REPLAY-SOURCES.json').read_text()):items['replay-sources/'+p]=R/'app'/p
for p in json.loads((R/'CANDIDATE-DART-SOURCES.json').read_text()):items['candidate-source/'+p]=S/p
items['HANDOFF.md']=D/'HANDOFF.md'
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(items.items())}
(R/'EVIDENCE-MANIFEST.json').write_text(json.dumps(manifest,indent=2));items['EVIDENCE-MANIFEST.json']=R/'EVIDENCE-MANIFEST.json'
with (D/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,p in sorted(items.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(D/'evidence.tar.gz','r:gz') as t:
 got={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert all(got[k]==v['sha256'] for k,v in manifest.items())
assert len(got)==len(items)
hashes={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.name!='ARTIFACT-HASHES.json'}
(D/'ARTIFACT-HASHES.json').write_text(json.dumps(hashes,indent=2))
(R/'ARTIFACT-CHECK.json').write_text(json.dumps({'committed_artifact_hashes':hashes,'archive_entries':len(got),'archive_hash_mismatches':[]},indent=2))
print(json.dumps({'files':hashes,'archive_entries':len(got),'archive_hash_mismatches':[]},indent=2))
