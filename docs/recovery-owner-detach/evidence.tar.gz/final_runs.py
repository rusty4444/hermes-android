import json, os, shutil, subprocess
from pathlib import Path
R=Path(__file__).parent; S=Path('/Volumes/Storage/Hermes/workspace/hermes-android-recovery-owner-detach'); A=R/'app'
env=dict(os.environ,**json.loads((R/'env.json').read_text()))
paths=['lib/core/services/gateway_turn_application_controller.dart','test/gateway_turn_recovery_owner_detach_test.dart','test/recovery_owner_root_teardown_test.dart','test/ws_server_requests_test.dart']
for p in paths:shutil.copy2(S/p,A/p)
p=subprocess.run(['/opt/homebrew/bin/dart','format',*paths],cwd=A,env=env,capture_output=True,text=True)
(R/'format-final-write.log').write_text(p.stdout+p.stderr); print(p.stdout+p.stderr); assert p.returncode==0
for path in paths:shutil.copy2(A/path,S/path)
def run(name,*args):
 subprocess.run(['python3',str(R/'run.py'),name,*args],cwd=S,env=env,check=True)
run('fatal-analysis-final','analyze','--no-pub','--fatal-infos','lib','test')
run('affected-controls-final','test','--no-pub','--concurrency=2','--reporter=json',
 'test/gateway_turn_recovery_owner_detach_test.dart','test/recovery_owner_root_teardown_test.dart','test/ws_server_requests_test.dart','test/gateway_turn_application_controller_test.dart',
 'test/independent_ed8_no_fault_control_test.dart','test/independent_ed8_teardown_diagnostic_test.dart','test/independent_ed8_observer_spec_test.dart','test/independent_ed8_no_mutation_teardown_test.dart',
 'test/independent_core_ed8_observer_consumers_test.dart','test/independent37_root_adverse_test.dart','test/independent_core37_lifetime_test.dart','test/independent_root78_valid_origin_test.dart')
run('full-exact-final','test','--no-pub','--concurrency=2','--reporter=json')
p=subprocess.run(['/opt/homebrew/bin/dart','format','--output=none','--set-exit-if-changed',*paths],cwd=A,env=env,capture_output=True,text=True)
(R/'format-final.log').write_text(p.stdout+p.stderr); print(p.stdout+p.stderr)
(R/'format-final-receipt.json').write_text(json.dumps({'args':p.args,'cwd':str(A),'exit':p.returncode},indent=2)); assert p.returncode==0
subprocess.run(['git','diff','--check'],cwd=S,check=True)
