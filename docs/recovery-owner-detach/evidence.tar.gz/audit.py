import collections, difflib, gzip, hashlib, json, os, plistlib, shutil, subprocess
from pathlib import Path
R=Path(__file__).parent; A=R/'app'; S=Path('/Volumes/Storage/Hermes/workspace/hermes-android-recovery-owner-detach')
BASE='ed8db9f12b07e2392edfc7dab41b586b22167f23'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
keys=lambda cases:{(c['path'],c['name']) for c in cases}
read=lambda name:json.loads((R/name).read_text())
volume=plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))
assert volume['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
assert Path('/Users/sam.russell/.hermes/cache/scratch').resolve()==R.parent
baseline=read('SOURCE-BEFORE.json')
expected_changes=['lib/core/services/gateway_turn_application_controller.dart','test/ws_server_requests_test.dart']
new_tests=['test/gateway_turn_recovery_owner_detach_test.dart','test/recovery_owner_root_teardown_test.dart']
paths=expected_changes+new_tests
sources={}
git_blobs={}
for row in subprocess.check_output(['git','ls-tree','-rz',BASE],cwd=S).split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1);git_blobs[p.decode()]=meta.decode().split()[2]
assert len(git_blobs)==len(baseline)==615
for root,label in [(S,'worktree'),(A,'tested_archive')]:
 changed=[p for p,h in baseline.items() if sha(root/p)!=h]
 assert changed==expected_changes,changed
 for p,b in git_blobs.items():
  data=(root/p).read_bytes(); actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert (actual!=b)==(p in expected_changes),p
 sources[label]={'path':str(root),'base_blobs':len(baseline),'base_lib_blobs':sum(p.startswith('lib/') for p in baseline),'changed_base_blobs':changed,'unchanged_base_blobs':len(baseline)-len(changed),'candidate_dart_hashes':{p:sha(root/p) for p in paths}}
assert sources['worktree']['candidate_dart_hashes']==sources['tested_archive']['candidate_dart_hashes']
cache_before=read('CACHE-BEFORE.json')
cache_after={p:{'sha256':sha(Path(p)),'mtime_ns':Path(p).stat().st_mtime_ns} for p in cache_before}
assert cache_before==cache_after
(R/'CACHE-AFTER.json').write_text(json.dumps(cache_after,indent=2))
replays=read('REPLAY-SOURCES.json');assert all(sha(A/p)==h for p,h in replays.items())
raw_before=read('RAW-ARCHIVE-HASHES.json');assert all(sha(R/p)==h for p,h in raw_before.items())
full=read('full-exact-final-receipt.json');focus=read('affected-controls-final-receipt.json');red=read('raw-five-red-receipt.json')
for d,n in [(full,2553),(focus,45)]:
 assert d['count']==d['unique']==n and d['results']=={'success':n} and d['exit']==0 and d['done']['success'] and not d['errors'] and not d['skips'] and not d['loader_errors'] and not d['timeout']
# Independently enforce all start/done identities, including successful loaders.
events=[]
for l in (R/'full-exact-final.log').read_text().splitlines():
 try:events.append(json.loads(l))
 except ValueError:pass
starts={e['test']['id']:e['test'] for e in events if e.get('type')=='testStart'}
dones={e['testID']:e for e in events if e.get('type')=='testDone'}
assert set(starts)==set(dones)
assert all(e['result']=='success' and not e.get('skipped',False) for e in dones.values())
assert events[-1]['type']=='done' and events[-1]['success']
ck=keys(full['cases']);assert len(ck)==2553
frozen=json.loads(gzip.decompress((A/'docs/mutation-observer-isolation/case-ids.json.gz').read_bytes()))
accepted=json.loads((R/'raw-before/EXPECTED-CASES.json').read_text())
prior=json.loads(gzip.decompress((A/'docs/main-81d-integration/case-ids.json.gz').read_bytes()))
assert len(keys(frozen))==2540 and len(keys(accepted))==2511 and len(keys(prior))==2443
assert keys(frozen)<=ck and keys(accepted)<=ck and keys(prior)<=ck
producer=json.loads((A/'docs/mutation-observer-isolation/verification.json').read_text()); cohorts={}
for name,c in producer['overlapping_cohorts_do_not_sum'].items():
 selected=[x for x in full['cases'] if x['path'] in c['files']]
 assert len(selected)==c['count'] and all(x['result']=='success' for x in selected)
 cohorts[name]={'count':len(selected),'all_success':True,'files':c['files']}
added=[c for c in full['cases'] if (c['path'],c['name']) not in keys(frozen)]
assert len(added)==13
permanent=[c for c in added if c['path'] in new_tests or c['path']=='test/ws_server_requests_test.dart']
raw=[c for c in added if Path(c['path']).name.startswith('independent_ed8_')]
core=[c for c in added if c['path']=='test/independent_core_ed8_observer_consumers_test.dart']
assert len(permanent)==5 and len(raw)==5 and len(core)==3
assert red['unique']==5 and red['results']=={'error':4,'success':1} and red['exit']==1 and not red['done']['success'] and red['loader_errors']==0 and red['skips']==0
for name in ['_CoordinatorGatewayTurnApplicationSession._requireOpen','_CoordinatorGatewayTurnApplicationSession.removeAsyncEventListener','_ChatScreenState.dispose','finalizeTree']:
 assert name in (R/'raw-five-red.log').read_text(),name
unitred=read('permanent-unit-red-loopback-receipt.json');assert unitred['unique']==2 and unitred['results']=={'error':2} and all('session is closed' in e['error'] for e in unitred['errors'])
factpath='independent-ed8-teardown-diagnostic.json'
redfacts=json.loads((R/'raw-five-red-widget-evidence'/factpath).read_text())
greenfacts=json.loads((R/'full-exact-final-widget-evidence'/factpath).read_text())
assert redfacts['rootMountedAfterUnmount'] and redfacts['handlerStillRegistered']
assert not greenfacts['rootMountedAfterUnmount'] and not greenfacts['handlerStillRegistered']
assert {k:v for k,v in redfacts.items() if k not in ['rootMountedAfterUnmount','handlerStillRegistered']}=={k:v for k,v in greenfacts.items() if k not in ['rootMountedAfterUnmount','handlerStillRegistered']}
for facts in [redfacts,greenfacts]:
 assert facts['queueEmptyAfterUnmount'] and facts['freshChoiceBeforeUnmount']=='deny' and facts['freshExactObjectDifferent'] and facts['oldEpochRevoked'] and not facts['mutationPending']
# Existing WS test bodies/assertions are literally unchanged; only new tests and
# explicitly opt-in fixture scheduling/response observation were added.
oldws=subprocess.check_output(['git','show',BASE+':test/ws_server_requests_test.dart'],cwd=S,text=True)
newws=(S/'test/ws_server_requests_test.dart').read_text()
marker="  test('WsClient advertises and answers server initiated requests'"
end='Future<void> _waitFor('
assert oldws[oldws.index(marker):oldws.index(end)]==newws[newws.index(marker):newws.index(end)]
(R/'PERMANENT-FIXTURE.diff').write_text(subprocess.check_output(['git','diff','--','test/ws_server_requests_test.dart'],cwd=S,text=True))
primary=(A/'test/independent_ed8_no_fault_control_test.dart').read_text()
(R/'RAW-TO-PERMANENT-ROOT.diff').write_text(''.join(difflib.unified_diff(primary.splitlines(True),(S/'test/recovery_owner_root_teardown_test.dart').read_text().splitlines(True),fromfile='unchanged-raw-independent-ed8-no-fault-control',tofile='permanent-root-teardown-and-new-root-handler-regressions')))
assert read('fatal-analysis-final-receipt.json')['exit']==0 and 'No issues found!' in (R/'fatal-analysis-final.log').read_text()
assert read('format-final-receipt.json')['exit']==0
subprocess.run(['git','diff','--check'],cwd=S,check=True)
subprocess.run(['git','merge-base','--is-ancestor','81d10e7fbdc0ddd499d77a104d05f1d61b70808d',BASE],cwd=S,check=True)
assert 'version: 2.1.32+2175' in (A/'pubspec.yaml').read_text()
repos=[]
for p in ['/Volumes/Storage/Hermes/workspace/hermes-android-post-2.1.32-integration','/Volumes/Storage/Hermes/workspace/hermes-android-mutation-observer-isolation']:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip(); status=subprocess.check_output(['git','status','--porcelain'],cwd=p,text=True)
 assert head==BASE and not status
 repos.append({'path':p,'revision':head,'clean':True})
env=dict(os.environ,**read('env.json'))
toolchain=subprocess.run(['/opt/homebrew/bin/flutter','--version','--machine'],cwd=A,env=env,capture_output=True,text=True,check=True)
(R/'TOOLCHAIN.json').write_text(toolchain.stdout)
summary=lambda d:{k:d[k] for k in ['name','args','cwd','exit','timeout','count','unique','results','skips','loader_errors','done']}
receipt={'scope':'producer execution only; no self-SPEC/QUALITY approval; Parent preflight then fresh affected Root+CORE SPEC then QUALITY required','base':BASE,'direct_parent_required':True,'workspace':str(S),'evidence_root':str(R),'volume_uuid':volume['VolumeUUID'],'sources':sources,'cache':{'third_party_dart':sum('pub-cache' in p for p in cache_before),'dependency_sdk_dart_superset':len(cache_before),'hash_mtime_mismatches':[]},'replays':replays,'full':summary(full),'focused':summary(focus),'raw_red':summary(red),'unit_red':summary(unitred),'full_start_done_assertions':{'all_starts_done':True,'cases':len(full['cases']),'loaders':sum(x['name'].startswith('loading ') for x in starts.values()),'errors':0,'skips':0},'inventories':{'frozen':len(keys(frozen)),'accepted':len(keys(accepted)),'accepted_old_tracked':2404,'accepted_independent':107,'prior':len(keys(prior)),'missing':[],'added':added,'new_permanent':permanent,'reused_root5':raw,'reused_core3':core},'overlapping_cohorts_do_not_sum':cohorts,'red_facts':redfacts,'green_facts':greenfacts,'readonly_repositories':repos,'unchanged_existing_ws_tests':True,'qualifications':['Dart/mock native + memory secrets + real root/controller/manager/loopback; no device/provider acceptance.','Permanent root cases rehost reviewer schedule, not new independent evidence.','Held-close unit fixture is stock/no-v2 and asserts cleanup flight plus preserved admission denial; v2 replacement/listener/request success is separately exercised over WS.','Existing 21-second widget fake-clock timeout drain retained unchanged; no new product timeout or correctness sleep.','Initial owned unit setup used unconfigured auth and failed at Session token not found; corrected only to existing loopback BindingServer before actual two-case closure red.','Initial new wire fixture used nonexistent dashboardPort constructor parameter; one loader failure preserved then corrected to actual dashboardPortOverride.','Initial wire equality assertion incorrectly assumed owner-qualified opaque IDs repeat; actual UUID owner namespace differed as designed. Changed only this new fixture expectation to require shared raw IDs and distinct owner-qualified handles; raw primary is untouched.','First analysis reported unused import and two missing new-test braces; corrected and exact final analysis/focus/full/format repeated.','Initial formatter in unconfigured worktree warned about flutter_lints resolution; final formatter ran in configured owned archive with zero changes/no warning.','No build/native/server/device/sign/install/publish/TUI/live credentials/Vault/model-default/other-profile actions.']}
(R/'VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
(R/'SOURCE-CACHE-AFTER.json').write_text(json.dumps({'sources':sources,'cache':receipt['cache'],'volume_uuid':volume['VolumeUUID'],'raw_archive_mismatches':[]},indent=2))
(R/'CASE-IDS.json.gz').write_bytes(gzip.compress(json.dumps(full['cases'],indent=2).encode(),mtime=0))
(R/'CANDIDATE-DART-SOURCES.json').write_text(json.dumps({p:sha(S/p) for p in paths},indent=2))
print(json.dumps({'full':summary(full),'focused':summary(focus),'cache':receipt['cache'],'changed_base_blobs':expected_changes,'new_permanent':permanent,'red_facts':redfacts,'green_facts':greenfacts,'inventories':{k:v for k,v in receipt['inventories'].items() if isinstance(v,int)}},indent=2))
