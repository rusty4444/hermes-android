// New ed8 SPEC schedules. Reuses the delivered real-root fixture mechanics;
// the first optional observer is a deliberately widened supplemental fault.
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/connection_mutation_barrier.dart';
import 'package:hermes_android/core/services/notification_approval_authority.dart';
import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'support/mutation_observer_root_fixture.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides? previous;
  setUp(() {
    SharedPreferences.setMockInitialValues({
      'verbose_mode': false,
      BackgroundWorkPrefsStore.storageKey: true,
    });
    backgroundWorkEnabled.value = true;
    notificationPrefs.value = NotificationPrefs.defaults;
    pendingNotificationApprovals.value = const [];
    previous = HttpOverrides.current;
    HttpOverrides.global = null;
  });
  tearDown(() {
    HttpOverrides.global = previous;
    debugDefaultTargetPlatformOverride = null;
  });
  for (final kind in ['Error', 'arbitrary-object']) {
    testWidgets(
      'INDEPENDENT-ed8 prior $kind observer cannot starve real root revocation or fresh same-ID action',
      (tester) async {
        final f = MutationObserverRootFixture();
        final facts = <(bool, bool)>[];
        void failing() {
          if (kind == 'Error') throw StateError('synthetic-sensitive-observer');
          throw Object();
        }

        void healthy() {
          facts.add((
            ConnectionMutationBarrier.isPending(f.connection.id),
            pendingNotificationApprovals.value.isEmpty,
          ));
        }

        ConnectionMutationBarrier.addListener(failing);
        await f.initialize(tester);
        ConnectionMutationBarrier.addListener(healthy);
        var closed = false;
        try {
          final oldOrigin = NotificationApprovalAuthority.origin(f.connection);
          final old = await f.queueAndPause(tester);
          final oldEpoch = ConnectionMutationBarrier.capture(f.connection.id);
          final mutation = f.manager.updateApiKey(
            f.connection.id,
            f.connection.apiKey,
          );
          // These facts are synchronously observable before mutation I/O awaits.
          expect(ConnectionMutationBarrier.isPending(f.connection.id), isTrue);
          expect(old.authority!.isCurrent, isFalse);
          expect(pendingNotificationApprovals.value, isEmpty);
          expect(facts.first, (true, true));
          await mutation;
          final current = f.manager.getConnections().single;
          expect(current.apiKey, f.connection.apiKey);
          expect(ConnectionMutationBarrier.isPending(current.id), isFalse);
          expect(
            ConnectionMutationBarrier.isCurrent(current.id, oldEpoch),
            isFalse,
          );
          expect(old.authority!.isCurrent, isFalse);
          expect(facts, everyElement((true, true)));
          MutationObserverRootFixture.lifecycle(
            tester,
            AppLifecycleState.resumed,
          );
          await MutationObserverRootFixture.drain(tester);
          NotificationResponse response(Map<String, String> origin) =>
              NotificationResponse(
                actionId: 'reject',
                payload: jsonEncode({
                  'connectionId': current.id,
                  'sessionId': 'stored',
                  'requestId': 'approval-reused',
                  ...origin,
                }),
                notificationResponseType:
                    NotificationResponseType.selectedNotificationAction,
              );
          notificationResponseHandler!(response(oldOrigin));
          await MutationObserverRootFixture.drain(tester);
          expect(pendingNotificationApprovals.value, isEmpty);
          notificationResponseHandler!(
            response(NotificationApprovalAuthority.origin(current)),
          );
          await MutationObserverRootFixture.until(
            tester,
            () => pendingNotificationApprovals.value.length == 1,
          );
          final fresh = pendingNotificationApprovals.value.single;
          expect(fresh, isNot(same(old)));
          expect(fresh.choice, 'deny');
          expect(fresh.authority!.isCurrentFor(current), isTrue);
          await f.close(tester);
          closed = true;
          expect(notificationResponseHandler, isNull);
          expect(pendingNotificationApprovals.value, isEmpty);
          ConnectionMutationBarrier.removeListener(healthy);
          await f.manager.updateApiKey(current.id, current.apiKey);
          expect(ConnectionMutationBarrier.isPending(current.id), isFalse);
          expect(tester.takeException(), isNull);
          await tester.runAsync(
            () => File('review-evidence/independent-ed8-$kind.json')
                .writeAsString(
                  jsonEncode({
                    'synchronousHealthyObservations': [
                      for (final fact in facts)
                        {'pending': fact.$1, 'queueEmpty': fact.$2},
                    ],
                    'staleRejected': true,
                    'freshExactObjectDifferent': !identical(old, fresh),
                    'freshChoice': fresh.choice,
                    'rootTeardownClearedOwnedQueue': true,
                    'handlerUnregistered': notificationResponseHandler == null,
                    'postTeardownRealMutationCompleted': true,
                  }),
                ),
          );
        } finally {
          ConnectionMutationBarrier.removeListener(failing);
          ConnectionMutationBarrier.removeListener(healthy);
          if (!closed) await f.close(tester);
        }
      },
    );
  }
}
