# Fresh affected combined CORE SPEC — PASS

## Target, scope and finding

- Exact target: **`ed8db9f12b07e2392edfc7dab41b586b22167f23`**; direct parent: `37f52c1b84a1e7a1ca93c8e573e8e79badd030fc`.
- **PASS for the fresh affected combined CORE SPEC scope. No blocking CORE violation found.** The optional-observer change repairs the lease/recovery boundary without changing authoritative mutation I/O or the approved CORE policies.
- This does **not** grant the parallel ROOT/public verdict, QUALITY, whole-candidate acceptance or deployment/release approval. No implementation fix was made. Parent owns transitions.
- Owned exact Git archive: `/Volumes/Storage/Hermes/scratch/core-ed8-spec-r98vb3vq/app`. Producer/integration/earlier-review sources were read-only. Version remains `2.1.32+2175`; no new public/main check or identity claim.

## Carry-forward proof, not a restarted architecture/oracle review

Read the complete explicit37 CORE PASS report and receipt. Independently archived ed8 and checked its Git blob identities. Of all **606 prior tracked blobs**, only the named barrier differs; **605** are byte-identical to exact37 Git. All **139 lib blobs** are accounted for, with **138 unchanged**. The nine additions are five new handoff artifacts and four test/helper files.

The unchanged approved production, all old test assertions and the four-layer provenance/archive bytes therefore carry forward under the explicit37 approval. `PROVENANCE-CARRY-FORWARD.json` records the prior approval hashes and source basis. This is fresh byte proof, **not** a claim to have newly repeated37's full raw-oracle/deleted-assertion audit. No old C/R/public policy was reopened or weakened.

Freshly reran the preserved original CORE20, CORE37 six-case probe, minimal valid-origin ROOT8 and original ROOT37 seven-case probe. Their sources were copied/checked byte-exact, not newly authored. Original CORE file SHA values were independently derived from exact source and are in the receipt; supplied hand-typed hashes were not accepted as verification.

## Shared mutation boundary and impacted consumers

- `connection_mutation_barrier.dart:22–38`: the only production delta is per-listener `try/catch` (7 insertions/1 deletion). The complete unique-ID epoch/refcount loop remains before the first callback. Snapshot delivery, duplicates, overlapping/nested leases, synchronous reentrancy and idempotent exact release are unchanged. A throwing Error or Exception no longer starves siblings or prevents return of the caller's lease.
- The diagnostic choice is **none**: zero extra state/logging, no formatting of observer exceptions, global handler, warning suppression or asynchronous rethrow. The catch surrounds only optional synchronous delivery, not the manager's storage action.
- `connection_manager.dart:595–625,666–703,722–810`: outer pending ownership still starts synchronously, the one shared saved-list queue still owns fresh reload/baseline/action, and exact `finally` release follows action/rollback/native acknowledgement. Real prerequisite reads and credential/metadata write errors remain separately sanitized and propagated. Pending native END replay remains owned by the existing exact mutation token. The permanent queued-write/native-END-ack test and full prerequisite/list/secure-storage controls freshly pass; channels and credentials are fixtures, not physical Android/provider proof.
- `main.dart:404,490–495,749–770` → `NotificationApprovalAuthority.isCurrent` → real saved-list lookup is the actual throwing observer path. Unknown corrupt metadata does not become blanket revocation or fail-open approval. Reused exact ROOT37 facts now show the caller's own sanitized metadata error, pending-after-fault=false, physical successor=true, pending-after-successor=false, successor-current=true, and corrupt-key reset=true. This failure occurs **before native BEGIN**, not after an omitted END. The unrelated queued B object survives unchanged.
- Traced every shared-barrier production consumer: manager, root listener, notification authority, MobilePush and both application-controller/session paths. Notification authority checks the epoch and pending flag before owner lookup, checks again after refresh, and retains captured manager/dispatch-owner and exact-object acknowledgement. MobilePush retains captured mutation checks around credential refresh, enable tickets, native/HTTP awaits, pending consent and reconciliation. These were not replaced with cached authority.
- `gateway_turn_application_controller.dart:161–183,202–246` and normal-session account capture retain same-ID/ABA replacement. Factory lookup synchronously closes the obsolete normal owner before cleanup. New tests distinguish **immediate notification-epoch revocation** from **normal history-token invalidation through controller replacement/close**; they do not pretend the history token alone directly observes mutation epochs. No claim that a normal owner is autonomously closed without that existing controller boundary.
- Re-read the normal submit/onSent/ACK/recovery/current-generation gates, alias/import outcome transfer and pruning, authoritative settlement, and account close. Late old callbacks cannot borrow the replacement owner's receipt/outcome. The new cases preserve exact uncertain turn/floor37, prevent automatic replay, allow a fresh explicit successor to settle and retain unrelated account ownership/data/draft. Existing CORE37 physical resume/reopen/export and 134-turn alias/outcome controls were freshly replayed, not newly written.
- Draft handles still distinguish explicit edit authority from hydration/checkpoint/dispose. The physical shared serialized queue and identity-checked completed-tail release remain intact; this delta neither claims a writer nor adds a queue. Alias convergence/rejection/clear/ACK-loss contracts are unchanged and included in the full accepted run.

## Unchanged CORE contracts retained and freshly regressed

The approved C/R/B/WAL/draft/children/public implementation is byte-identical outside the shared boundary, and its complete accepted inventory is freshly green:

- C remains the complete accepted loaded/paged server-ordered durable-ID window. R remains the one bounded app-owned received source; C then labelled R then Aux, source-local uniqueness, permitted cross-source same-body repetition, no guessed text/UUID/floor/ordinal match, canonical-copy buffer, donor hiding or materialized-success retirement. Existing run/text/tombstone/pin/row/tool/task bounds and source-qualified outer/stable inner keys are unchanged.
- B remains physical offset-zero request-start authority across awaits/cold paging/error/defer/reentrant delivery. Accepted successful observations supersede; mere issued/failed reads do not. Older pages do not promote latest authority; route/window/loader/scroll cleanup stays identity-owned. Tokenless observation remains a trusted compatibility seam, not physical-freshness evidence.
- Immutable prewire floor/WAL,200-empty versus404/error, pre-ACK recovery capture, prompt-RPC-not-terminal, no terminal self-correlation and no replay remain unchanged. No prompt/body journal, model HTTP synthetic row or independent status map was introduced.
- `ReceivedScopeOutcome` remains immutable UI-only operation/scopes/typed completed-failed-unknown, retained/pruned with its existing row/run container and rendered/exported once with the same localized source caption. Unknown is not definite failure; prewire rejection is not a failed server turn; older failed same-body output survives later success. Account close may end volatile R; same-owner route pop/reopen may not.
- Child lifetime/hydration and the same-controller anchor/latest-tip GET-only modal are unchanged. Main173 compact display and main174 actual-visit reasoning/tools defaults/manual choices/inner keys and outer visit-scope replacement remain the approved byte-exact contracts. State/controller/composer/scroll120, alias/pin/lazy/covered-route and noReplay/noSynthetic controls remain in the executed accepted inventory. Current-owned voice/unread is not derived from canonical repetition, imported donor or status-only captions; no physical TTS claim.

These are scoped carry-forward plus fresh regressions, not a new universal proof of every historical or unsupported embedder ordering.

## Three newly authored deterministic schedules

File: `/Volumes/Storage/Hermes/scratch/core-ed8-spec-r98vb3vq/app/test/independent_core_ed8_observer_consumers_test.dart`

SHA-256: **`b8218602557e7fd18510e5f5b4a9a876d25340b220485101784b976a23835cb3`**.

1. Two late-terminal variants combine the **actual mounted HermesApp/root-owned unrelated queued B/default B controller** with A's held pre-ACK owner submission, physical malformed saved-list fault, real failed A edit, same-config replacement/restored WAL, old success/failure callbacks, a real same-ID/same-configuration successor edit and fresh explicit A settlement. Assert exact B object/owner/history/presentation/outcome/durable draft preservation; old A cannot reserve after close; old late callbacks cannot remove or change the uncertain receipt/floor37 or attach an outcome/body to the successor. Fresh A settles once and retires only its own marker; uncertain A is never replayed.
2. Held failing credential write plus queued physical successor, with a throwing optional observer and healthy sibling. Old captured approval authority is immediately false; a fresh capture while pending is rejected; the interim controller owner remains account-noncurrent; unrelated B authority/session remains current. After sanitized failure/rollback and successor drain, fresh current A can reserve/cancel, old authority remains false, all leases are released and four healthy observer deliveries are observed.

Fixture mechanics are reused explicitly. A prompt/resume, credential provider and direct event delivery are controlled seams; B root/queue and manager paths are real production code. Metadata corruption is injected through physical preferences, not claimed stock-UI-generated. Assertions are **outside** deliberately caught optional callbacks; those callbacks only collect facts/increment counters. No assertion suppression, global warning/error handler, queue reset or invented authority baseline.

## Fresh execution and exact accounting

| Gate | Actual result |
|---|---|
| Initial complete existing accepted/reused/permanent inventory |2540/2540 pass; exit0; terminal success;0 errors/skips/loaders|
| Final expanded focused consumer regression |**446/446 pass**; exit0; terminal success;0 errors/skips/loaders|
| Final full suite with exact final new probe |**2543/2543 pass**; exit0; terminal success;0 errors/skips/loaders|
| Final fatal whole-lib/all-test analysis |exit0; `No issues found!`|
| Final no-write format: changed production + four added Dart files + new reviewer probe |6 checked,0 changes; exit0|
| Exact target Git whitespace |exit0|

All2511 accepted identities (2404 old tracked +107 accepted independent) and every prior2443 identity are present. All2540 producer inventory identities are present. The final2543 also comprises eight new tracked permanent regressions, reused minimal ROOT8, reused ROOT37 seven, reused CORE37 six, and **only three newly independent schedules**. It is not2543 newly independent cases. Overlapping cohorts retained425/B38/C-R26/Root59/compact11/reasoning16/cleanup13/CORE20 were checked programmatically and must not be summed. Root59 remains46 literal +13 main81d policy-copy schedules; cleanup13 is not26.

Actual commands, serial per app with max2 workers and `--no-pub`:

```sh
/opt/homebrew/bin/flutter test --no-pub --concurrency=2 --reporter=json <exact focused paths in receipt>
/opt/homebrew/bin/flutter test --no-pub --concurrency=2 --reporter=json
/opt/homebrew/bin/flutter analyze --no-pub --fatal-infos lib test
/opt/homebrew/bin/dart format --output=none --set-exit-if-changed <six exact paths in receipt>
```

`gates.py`, `run.py` and per-run receipts retain full argv, real child exit, exact unique path/name/status IDs, errors/loaders and terminal events. The wrappers do not convert a failing child into acceptance. Flutter3.44.0/Dart3.12.0 from actual output; supplied Python3.14.7 used for filtered archive extraction.

Own harness disclosures: the first new3/focused393/full2543 passed, but fatal analysis found **one brace-style info** in the new reviewer's teardown. Preserved `BEFORE-BRACE-PROBE.dart` and `*-before-brace` logs/receipts; changed only braces, no assertion/suppression, then reran exact final focused446/full2543/fatal analysis/format. Initial focus selection had two absent optional filename candidates rejected before Flutter launch, not loader failures; final focus uses discovered actual transaction/prerequisite names plus secure-storage controls. No product error was hidden.

No fresh37 red replay was required or claimed. Historical raw removed-API4 loaders, raw13 post-assert timer issue, raw ROOT8's superseded unscoped-admission failures and old fixture preflights retain their explicit37 qualifications; they were not rerun or relabelled unchanged-green here. Parent/producer preflight results are not this independent acceptance.

## Integrity, artifacts and limits

Before/after all tooling, **615 tracked blobs/139 lib** match in this private archive and both clean exact-ed8 supplied worktrees. All15 accepted independent replay files and the three separately reused probe files retain their expected bytes; final new probe matches `FINAL-NEW-PROBE-SOURCE.dart`. All **7416 third-party Dart hashes/nanosecond mtimes**, and all **9554 dependency/SDK Dart superset entries**, match independent before/after snapshots. This is source/cache integrity, not an unlimited heap/SDK-artifact guarantee.

Storage UUID checked before writes and final audit: `F7E08904-541C-463A-8BD5-284D3C146333`. Both package config and graph plus plugin metadata were supplied from read-only configured repair78 dependencies; main rootUri=`../`, other package URIs resolved against their original config. Writable HOME/PUB_CACHE are owned siblings outside the app. No pub get/install/update or borrowed source/cache modification.

Primary artifacts, all under `/Volumes/Storage/Hermes/scratch/core-ed8-spec-r98vb3vq/`:

- `CORE-SPEC-REPORT.md`, `CORE-SPEC-RECEIPT.json`, `fresh-case-ids.json`, `PROVENANCE-CARRY-FORWARD.json`.
- `full-final{.log,-receipt.json}`, `focused-final{.log,-receipt.json}`, `analysis-final.log`, `format-final.log`, and preserved before-brace runs.
- `SOURCE-MANIFEST.json`, `CACHE-BEFORE.json`, `CACHE-AFTER.json`, `setup.json`, `ACCEPTED-SOURCES.json`, `REUSED-SOURCES.json`, `exact-source.tar`.
- Final runnable new probe and `FINAL-NEW-PROBE-SOURCE.dart`; exact reused ROOT37 facts under `app/review-evidence/independent37-root-{listener-leak,reset-recovery}.json`.

No new blocker or demanded production change. Future added optional observers must preserve independent lease ownership and sibling delivery; expanded provider/OS-kill/device acceptance requires its separate real boundary, not an arbitrary reordered mock. No new native36/server126, APK/build/sign/install, device/provider/distributor/OS-kill/real voice/real credentials evidence. No Vault/live server/config/model/default/fallback/other-profile/TUI/main/push/tag/PR/release action. TUI remains paused. ROOT/public and QUALITY remain separate parent-owned gates.
