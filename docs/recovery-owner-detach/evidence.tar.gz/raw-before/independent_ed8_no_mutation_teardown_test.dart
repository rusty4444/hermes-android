// No-mutation control for the exact real-root lifecycle fixture.
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hermes_android/core/services/background_work_prefs.dart';
import 'package:hermes_android/core/services/notification_prefs.dart';
import 'package:hermes_android/core/services/turn_notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'support/mutation_observer_root_fixture.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets(
    'CONTROL unchanged real root queue and teardown unregister safely',
    (tester) async {
      SharedPreferences.setMockInitialValues({
        'verbose_mode': false,
        BackgroundWorkPrefsStore.storageKey: true,
      });
      backgroundWorkEnabled.value = true;
      notificationPrefs.value = NotificationPrefs.defaults;
      pendingNotificationApprovals.value = const [];
      final previous = HttpOverrides.current;
      HttpOverrides.global = null;
      final f = MutationObserverRootFixture();
      try {
        await f.initialize(tester);
        await f.queueAndPause(tester);
        await f.close(tester);
        expect(notificationResponseHandler, isNull);
        expect(pendingNotificationApprovals.value, isEmpty);
        expect(tester.takeException(), isNull);
      } finally {
        HttpOverrides.global = previous;
        debugDefaultTargetPlatformOverride = null;
      }
    },
  );
}
