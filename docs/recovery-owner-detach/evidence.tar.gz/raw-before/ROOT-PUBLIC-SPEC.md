# Independent ROOT / PUBLIC / APPROVAL-AUTHORITY SPEC — REQUEST_CHANGES

## Frozen identity and scope

- Target: **ed8db9f12b07e2392edfc7dab41b586b22167f23**. Direct parent: **37f52c1b84a1e7a1ca93c8e573e8e79badd030fc**.
- **ROOT37-1 / P2 is independently verified repaired.** Its original seven-case source is byte-unchanged and reproduces 5 passes / 2 primary assertion errors on exact37, then 7 passes on exacted8.
- **Combined scope: REQUEST_CHANGES for ROOT-ED8-1 / P2**, a separately discovered real-owner teardown failure. It also reproduces on37; it is **not introduced by ed8's observer catch**, not the old lost-lease defect, and not a demonstrated wrong-account answer.
- Scope is ROOT/public/approval-authority SPEC, including required root teardown/unregistration. No implementation, deep CORE approval, QUALITY, release/candidate approval or deployment.
- Owned evidence root (**R/**): `/Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2`. Exact target: **R/app/**. Exact comparator: **R/base-app/**. Both were created from owned Git archives, not by executing in producer/integration or older review trees.

## ROOT-ED8-1 — P2: closed recovery owner aborts retained-route and root disposal

### Production locations

1. `lib/core/services/gateway_turn_application_controller.dart:161–175`: `sessionFor` detects a changed account mutation even with an identical configuration key, removes and synchronously starts closing the previous recovery session.
2. `lib/main.dart:825–830`: a fresh scoped action captures normal and recovery dispatch owners. Its real `sessionFor(connection)` call performs that replacement while an earlier mounted ChatScreen still retains the old session and callback registrations.
3. `lib/core/services/gateway_turn_application_controller.dart:414–443`: `removeAsyncEventListener` calls `_requireOpen`, which throws for that closed old owner. Other listener-removal methods already have different closed-owner handling; this finding concerns the executed async-listener path.
4. `lib/core/screens/chat_screen.dart:1206–1234`: route disposal calls that removal on its retained owner. The exception interrupts disposal before remaining registrations, view/draft/controller cleanup and `super.dispose` complete.
5. `lib/main.dart:1153–1195`: the consequent widget-tree finalization abort prevents root disposal/unregistration in the executed schedule. The retained root remains mounted and its global notification handler remains installed after the requested unmount and fixture drain.

### Actual input → production path → observed result

The decisive no-fault probe uses the delivered real-root fixture: actual HermesApp, default production session factories and real ConnectionManager with loopback HTTP/WS, fixture credentials/channels/journal. **No throwing optional observer, fake session owner, corrupt metadata, arbitrary authority callback or production adapter is installed.** An unused inherited `failing` function in the control is never registered/called; its only reference is harmless listener removal in final cleanup.

1. Mount the root and its actual quick-chat route; admit a current scoped B approval through `notificationResponseHandler`, then pause.
2. Execute real `updateApiKey(B, existingApiKey)`. This is a physical same-value saved-account mutation, not a hand-edited epoch. Assert synchronous pending state, old authority revocation and removal of the exact old queued action **outside** callbacks; await the real commit and assert pending clears.
3. Resume. Replay captured old origin: it cannot gain automatic authority. Deliver a fresh current scoped `reject` with the same connection/session/request IDs. A distinct current queued object with choice `deny` is admitted; dispatch captures/replaces the recovery owner through the actual root path.
4. Unmount through the same fixture's normal `pumpWidget(SizedBox.shrink())` path. The old retained ChatScreen tries to unregister from its closed production recovery session.

Raw production stack in both target and parent logs:

```text
_CoordinatorGatewayTurnApplicationSession._requireOpen
_CoordinatorGatewayTurnApplicationSession.removeAsyncEventListener
_ChatScreenState.dispose
StatefulElement.unmount
... BuildOwner.finalizeTree ...
MutationObserverRootFixture.close
```

Actual exception: **`Bad state: Gateway turn application session is closed.`** The final `notificationResponseHandler == null` expectation fails. The fact-only diagnostic copy records, on exact37 and exacted8:

```json
{"rootMountedAfterUnmount":true,"handlerStillRegistered":true,"queueEmptyAfterUnmount":true,"freshChoiceBeforeUnmount":"deny","freshExactObjectDifferent":true,"oldEpochRevoked":true,"mutationPending":false,"healthyFacts":[[true,true],[true,true]]}
```

Expected: revoke/replace the old owner without making the old mounted consumer's later detach unsafe; route/root disposal must finish and unregister owned callbacks. Actual: an unconditional closed-owner exception aborts that lifecycle, retaining root/handler ownership. This is a reproducible public-consumer lifecycle/resource defect, not an observer-lease leak or inferred security exploit. No wrong-account RPC or plaintext secret disclosure was observed.

### Controls, severity and evidence qualifications

- The **no-fault** adverse source and diagnostic copy are byte-identical between final target and parent archives. Final comparator: 3 identities, 2 errors (same adverse schedule plus diagnostic duplicate), 1 passing no-mutation control, exit1, terminal false, no skip/loader.
- The otherwise same root queue/pause/resume/teardown **without the mutation** passes on37 and ed8. This rejects a generally broken root fixture or ordinary unmount as the explanation.
- Supplemental initial Error/Object observer variants reach the same teardown failure only **after** passing synchronous root revocation, later healthy delivery, released pending state, stale-origin rejection and fresh action admission. Their injected observers are explicitly widened boundary evidence, not the primary production-reachability proof.
- Four final reporter errors represent **one defect/order**, not four independent findings. Five new identities are the two supplemental variants, no-fault adverse control, fact-only duplicate and passing no-mutation control.
- Failure repeats in focused new tests, initial full run and final full run. No exception is consumed or assertion removed to turn these tests green. Expectations remain outside swallowed observer callbacks.
- Primary probe: **R/app/test/independent_ed8_no_fault_control_test.dart:55–120**, SHA256 `b03d7e5e0e02cf919208e46215b0e66811fdcecf949bc099709db13dd48722eb`.
- Diagnostic duplicate: **R/app/test/independent_ed8_teardown_diagnostic_test.dart:115–148**, SHA256 `a63d9563a084d49fe7b38cae596b148f7c7880b72ccdb2d2811b46dca24838fb`.
- Facts: **R/full-final-exact-widget-evidence/independent-ed8-teardown-diagnostic.json** and **R/new-final-exact-parent37-widget-evidence/independent-ed8-teardown-diagnostic.json**.
- Raw logs/receipts: **R/new-final-exact-{ed8,parent37}{.log,-receipt.json}**, **R/full-final-exact{.log,-receipt.json}**. Exact no-fault derivation is retained in **R/NEW-NOFAULT-ADAPTER.diff**; no production API adapter was needed.

This inherited issue is within the expressly retained root teardown/unregistration contract, so the combined SPEC cannot receive PASS. Parent owns disposition and any repair; no fix was made here.

## ROOT37-1 repair: unchanged actual-root red → green

The original seven-case source SHA256 is **`c288e37bbff0d28d370a10c101d8e64d1610e6defd6953d31dc36d5f5e4061cb`** in the old review, target, comparator and producer archived copy. It compiles on37/ed8 without the old78 adapter. `review-evidence/` existed before firing it.

- Exact37: both original primary corruption schedules reproduce the root prune → authority → owner → `getConnections` stack reaching `begin` before native BEGIN. A remains pending after failure and after a physically committed successor; successor current=false. Reset does not clear corruption.
- Exacted8, same bytes: caller still receives its **own** sanitized `CredentialStorageException` (`Saved connection metadata could not be read safely.`), now from `_withSavedListTransaction.perform`/the actual load boundary rather than an escaping root observer. A pending=false after failure and after the physically successful successor; successor current=true. The identical unrelated B queued object survives.
- Supported real reset clears the actual corrupt saved key. Permanent actual-root tests additionally reload/assert physical key absence, unchanged credentials after failure, B exact-object survival and restored current B authority. No global queue clearing, baseline caching or weakened authority was substituted.
- Only production delta is the per-listener synchronous `try/catch` at `connection_mutation_barrier.dart:28–35`: 7 insertions / 1 deletion. Every affected ID's epoch/refcount changes before any observer. No epoch rollback or release on the observer's behalf; no async rethrow/global handler and no diagnostics. Zero diagnostics is permitted by the contract.
- Five permanent barrier cases assert Error/Exception isolation, all-ID visibility to first and later observers, duplicate IDs, overlap/nesting/reentrancy, snapshot membership delivery, exact idempotent release, stale epochs and empty-ID delivery. Facts are collected inside observers and asserted **outside** them, so catch-all observer delivery cannot hide a test assertion failure.
- Permanent transaction test retains real manager I/O failure propagation, rollback and held native-END acknowledgement before the queued same-ID successor BEGIN, with exact two BEGIN/END lifetimes and fresh physical credentials/current authority. Channel acknowledgement is simulated Dart evidence, **not** Android provider/Keystore proof.
- All eight new permanent regressions and all seven unchanged original cases pass in this review's focused and full runs. The rehosted two permanent root cases repeat the original schedules and are not new independent coverage.

## Retained approval-origin and public contracts

Fresh source tracing revisited complete `MobilePushService.binding` (`mobile_push_service.dart:76–85`, metadata plus API key/dashboard password hashed), creation capture (`normal_gateway_application_session.dart:161,1914–1919`; `chat_screen.dart:571,1623–1626`), physical root ingress before deferral/I/O (`main.dart:737–795`), frozen deferred replay (`497–509`), manager/owner validation and dispatch-owner capture across awaits (`798–854`), scoped queue/retry/single-flight/exact-object ACK (`turn_notification_service.dart:944–1002`), and mounted ChatScreen consume/dispatch (`chat_screen.dart:4002–4096`). Old input is not restamped with new account authority; raw IDs do not grant replacement-owner ownership. The newly found cleanup defect does not change these passing sensitive-answer oracles.

- Minimal valid-origin Root8 remains byte-exact SHA256 **`7a9f6d0bb930282ed2e1bb324dc647562ff318fd08633f0ec32062ace459cca6`** and passes8/8. Verified its only difference from raw Root8 is adding approvalAccount and the explicitly simulated other-process approvalMutation at the two original inputs. All adverse barriers, real mutations, binding/owner changes and exact-old-queue assertions remain.
- Raw Root8 SHA **`faad50efdb6caaebf5fc83bc85ae185e76340e2ce2c58d85839482945d19cac4`** is retained, **not freshly executed or claimed unchanged-green**. Prior37's six controls plus two superseded unscoped-admission prerequisite failures remain qualified historical evidence, not a product red.
- Fresh permanent production-root loopback wire control observes **zero** replacement-profile replies before fresh action, then **one** fresh `deny`. A valid response on its captured old wire is permitted. No baseline wrong-account exploit is claimed. Foreign-process origin syntax plus fresh owned input is not physical cold-launch/process-death acceptance.
- Same-ID credential/profile/configuration/ABA, old owner/manager/read completion, held direct true/false/throw and exact late-ACK ownership controls pass. Unrelated valid actions progress. Legacy unscoped automatic answers fail closed while body taps/manual navigation remain usable. Payloads retain hashes/opaque epoch only, not plaintext credentials.
- Prior Root59 all pass: 46 cases in five literal files plus13 schedules in two explicit main81d policy copies; **not59 raw unchanged schedules**. Their audited hashes match. Earlier full37 oracle audit is reused only after proving unchanged source/provenance bytes.
- Actual startup/resume confirmed background policy/readiness and trailing denied↔granted permission checks, targeted partial notification cleanup, quiet active-only FGS, ordinary-vs-proof intents, full account/profile/latest-intent fencing and exact alias route coalescing remain passing controls.
- Retained State/Route/composer controller/draft selection and exact120→120 scroll controls pass. Main173 compact single-line task rows and full same-controller read-only GET-only modal pass11 cases; its two task production files and peer test match81d. Main174's16 reasoning/tool visit controls pass: mounted default-collapse, explicit app verbose/manual choice semantics, same-State/lazy/alias/covered-route preservation and true-State-disposal reset of view choices only.
- B38 and C/R26 pass: full accepted loaded/paged C plus labelled bounded received R, C then R then Aux once, source-local identity/draft/key preservation, physical request-start freshness and cursor fencing. No guessed cross-source dedup/correlation or retirement oracle was revived.
- Known received lifecycle outcome remains distinct from matching uncertainty in the tested UI/export and physical resume controls. Current voice/unread ownership controls remain passing fixture evidence; no live voice action or status-only side effect is newly accepted. Reused CORE6/original CORE20 executions are consumer/regression evidence, **not parallel deep CORE approval**.

## Executed inventory and terminal outcomes

All test counts below are unique `(suite path, test name)` identities parsed from raw JSON. Cohorts overlap and must not be summed.

| Execution | Actual result |
|---|---|
| Original Root7, exact37 |5 pass /2 assertion errors; exit1; done.success=false;0 skip/loader|
| Same original Root7, exacted8 |7/7 pass; exit0; done.success=true;0 skip/loader|
| Initial full target +3 new identities |2543 unique:2540 pass /3 new cleanup errors; exit1; terminal false;0 skip/loader|
| **Final exact full target +5 new identities** |**2545 unique:2541 pass /4 same-defect cleanup errors; exit1; done.success=false;0 skip/loader**|
| Accepted inventory within final |All2511 pass:2404 old tracked +107 accepted independent; all prior2443 retained|
| Existing additional repair/replay inventory |Permanent8 + minimal Root8 + unchanged Root7 + reused CORE6 all pass;29 identities, not29 new independent schedules|
| Final standard affected-control focus |346/346 pass; exit0; done.success=true;0 errors/skips/loaders|
| Final new target probe cohort |5 unique:1 pass /4 cleanup errors; exit1; terminal false;0 skip/loader|
| Final byte-identical parent no-fault/diagnostic/no-mutation controls |3 unique:1 pass /2 cleanup errors; exit1; terminal false;0 skip/loader|
| Overlapping retained cohorts |425 retained; B38; C/R26; Root59; compact11; reasoning16; cleanup13; original CORE20: all pass|
| Final fatal whole lib/test analysis |exit0; `No issues found!`|
| Final no-write formatter |9 files;0 changes; exit0|
| Frozen target Git whitespace check |clean; exit0|

Commands and exact per-run arguments/exits are in **R/REVIEW-RECEIPT.json**, each `*-receipt.json`, **R/run.py** and **R/final_runs.py**. Reproduction (use the owned `env.json`, not default HOME/cache):

```sh
REVIEW_APP=base-app python3 /Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2/run.py original7-parent37 test --no-pub --concurrency=2 --reporter=json test/independent37_root_adverse_test.dart
python3 /Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2/run.py original7-ed8 test --no-pub --concurrency=2 --reporter=json test/independent37_root_adverse_test.dart
python3 /Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2/run.py new-final-exact-ed8 test --no-pub --concurrency=2 --reporter=json test/independent_ed8_observer_spec_test.dart test/independent_ed8_no_fault_control_test.dart test/independent_ed8_teardown_diagnostic_test.dart test/independent_ed8_no_mutation_teardown_test.dart
python3 /Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2/final_runs.py
python3 /Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2/final_audit.py
```

## Integrity, ownership and qualifications

- Exact target **615 tracked Git blobs /139 lib**, comparator **606 /139 lib** independently checked before and after. No mismatches. All606 parent blobs except the one allowlisted barrier are byte-identical in target. Version remains `2.1.32+2175`; manager/native/server/controller/screen/dependency/provenance changes were not smuggled into ed8. Main integration and producer remain clean at exacted8/direct parent37; no public/main fetch or fresh remote-identity claim.
- All **7416 borrowed third-party Dart hashes and nanosecond mtimes**, plus the **9554 dependency/SDK Dart superset**, match this review's own before/after snapshots. Source/metadata/cache manifests, archives, artifact hashes and all18 replay-source hashes are retained. Both package config and graph plus plugin metadata are present; main rootUri=`../`, dependency relative roots resolved against the original configured repair78 location, HOME/PUB_CACHE owned siblings outside app. No pub get/install/upgrade/dependency-source writes. Flutter commands serial per app, maximum2 workers.
- Storage UUID verified before writes and at final audit: **F7E08904-541C-463A-8BD5-284D3C146333**. Filtered extraction used the supplied compatible Python. Independently read toolchain: Flutter3.44.0 / Dart3.12.0.
- Two early one-line Python discovery commands had unmatched-parenthesis syntax errors and made no writes. A first owned diagnostic-copy test had one extra closing parenthesis and one loader error; its raw log/receipt remain. Only that owned diagnostic setup was corrected, then its real assertion-red order reran. Final whole runs have zero loaders. Owned new files were formatted and the final exact full run/analysis repeated without lint suppression or expectation weakening.
- Producer's earlier delivery-count and format/lint corrections remain disclosed producer harness history, not fresh product errors. The inherited21-second widget-only drain and minimal Root8's16-second cleanup are retained; neither is a correctness sleep or product timeout alteration. Historical native36/server126, raw removed-API loaders and other old fixture qualifications are not fresh acceptance credit.
- No app production edits/fixes/commits, build/sign/install/device/real credential/Vault/provider/live server/config/model/default/fallback/other-profile/TUI/push/tag/PR/release work. TUI remains paused. Review files/probes/metadata were created only in R. One procedural lesson was appended to the default profile's existing `async-state-concurrency-review` skill; this is not an app implementation change.

## Handoff artifacts

- Report: **R/ROOT-PUBLIC-SPEC.md**. Machine receipt: **R/REVIEW-RECEIPT.json**.
- Final exact output/identities: **R/full-final-exact.log**, **R/full-final-exact-receipt.json**, **R/FINAL-CASE-IDS.json.gz**.
- Original red→green facts/stacks: **R/original7-{parent37,ed8}-widget-evidence/independent37-root-{listener-leak,reset-recovery}.json**.
- New no-fault facts/parent comparison: **R/new-final-exact-{ed8,parent37}-widget-evidence/independent-ed8-teardown-diagnostic.json**; raw logs/receipts alongside.
- Target source archive SHA256: **`f01c4ae5cda312a28810f37a27d5bd1a9a0ee681c10e946f6373a0f9f554561b`**. Parent archive SHA256: **`3c88fa862d1cfaf2666e423f0ab490a43389924c170a5ea8526a2b7e81900baa`**.
- Integrity and replay: **R/{app,base-app}-SOURCE-BEFORE.json**, **R/CACHE-{BEFORE,AFTER}.json**, **R/SOURCE-CACHE-AFTER.json**, **R/REPLAY-SOURCES.json**, **R/ARTIFACT-CHECK.json**, **R/PROTECTED-BLOBS.json**.

**Final verdict: REQUEST_CHANGES for ROOT-ED8-1/P2 (inherited37 teardown). ROOT37-1 observer isolation itself passes unchanged actual-root repair proof. No QUALITY or deployment approval is issued.**
