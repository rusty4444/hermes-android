import collections,json,os,shutil,subprocess,sys,time
from pathlib import Path
R=Path(__file__).parent; A=R/os.environ.get('REVIEW_APP','app')
env=dict(os.environ,**json.loads((R/'env.json').read_text()))
name=sys.argv[1];args=['/opt/homebrew/bin/flutter',*sys.argv[2:]]
start=time.monotonic();log=R/(name+'.log');timeout=False
with log.open('w') as f:
 try:p=subprocess.run(args,cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600);exitcode=p.returncode
 except subprocess.TimeoutExpired:timeout=True;exitcode=124
suites={};started={};finished={};errors=[];done=None;loader_starts={};loader_done={}
for l in log.read_text().splitlines():
 try:e=json.loads(l)
 except ValueError:continue
 t=e.get('type')
 if t=='suite':suites[e['suite']['id']]=e['suite']['path']
 elif t=='testStart':
  test=e['test']
  if test['name'].startswith('loading '):loader_starts[test['id']]=test
  else:started[test['id']]=test
 elif t=='testDone':
  if e['testID'] in started and not e.get('hidden'):finished[e['testID']]=e
  if e['testID'] in loader_starts:loader_done[e['testID']]=e
 elif t=='error':errors.append(e)
 elif t=='done':done=e
cases=[{'path':str(Path(suites[started[i]['suiteID']]).relative_to(A)),'name':started[i]['name'],'result':e['result'],'skipped':bool(e.get('skipped'))} for i,e in finished.items()]
receipt={'name':name,'cwd':str(A),'args':args,'exit':exitcode,'timeout':timeout,'seconds':round(time.monotonic()-start,2),'count':len(cases),'unique':len(set((c['path'],c['name']) for c in cases)),'results':dict(collections.Counter(c['result'] for c in cases)),'skips':sum(c['skipped'] for c in cases),'errors':errors,'loader_errors':sum(e.get('result')=='error' for e in loader_done.values()),'done':done,'cases':cases}
(R/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
if (A/'review-evidence').exists():shutil.copytree(A/'review-evidence',R/(name+'-widget-evidence'),dirs_exist_ok=True)
print(json.dumps({k:v for k,v in receipt.items() if k not in ('cases','args','errors')},indent=2))
if not cases:print(log.read_text()[-4000:])
sys.exit(exitcode)
