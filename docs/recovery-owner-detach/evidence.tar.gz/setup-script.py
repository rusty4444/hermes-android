import hashlib, json, os, plistlib, shutil, subprocess, tarfile, tempfile, urllib.parse
from pathlib import Path
S=Path('/Volumes/Storage/Hermes/workspace/hermes-android-recovery-owner-detach')
OLD=Path('/Volumes/Storage/Hermes/scratch/root-public-ed8-spec-o8l9qex2')
CORE=Path('/Volumes/Storage/Hermes/scratch/core-ed8-spec-r98vb3vq')
BORROW=Path('/Volumes/Storage/Hermes/scratch/repair78-sw4ni6sb/app')
REV='ed8db9f12b07e2392edfc7dab41b586b22167f23'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=plistlib.loads(subprocess.check_output(['diskutil','info','-plist','/Volumes/Storage']))
assert v['VolumeUUID']=='F7E08904-541C-463A-8BD5-284D3C146333'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==REV
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
R=Path(tempfile.mkdtemp(prefix='recovery-owner-detach-',dir='/Volumes/Storage/Hermes/scratch'))
A=R/'app'; A.mkdir(); (R/'raw-before').mkdir()
subprocess.run(['git','archive','--format=tar','-o',str(R/'exact-ed8.tar'),REV],cwd=S,check=True)
with tarfile.open(R/'exact-ed8.tar') as t:t.extractall(A,filter='data')
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',REV],cwd=S,text=True).splitlines()
manifest={p:sha(A/p) for p in tracked}
assert len(manifest)==615
(R/'SOURCE-BEFORE.json').write_text(json.dumps(manifest,indent=2))
replays=json.loads((OLD/'REPLAY-SOURCES.json').read_text())
raw=[p for p in (OLD/'app/test').glob('independent_ed8*_test.dart')]
assert len(raw)==4
replays.update({str(p.relative_to(OLD/'app')):sha(p) for p in raw})
cp=CORE/'app/test/independent_core_ed8_observer_consumers_test.dart'
assert sha(cp)=='b8218602557e7fd18510e5f5b4a9a876d25340b220485101784b976a23835cb3'
replays[str(cp.relative_to(CORE/'app'))]=sha(cp)
for p,h in replays.items():
 source=cp if p==str(cp.relative_to(CORE/'app')) else OLD/'app'/p
 assert sha(source)==h
 shutil.copy2(source,A/p)
 if p in {str(x.relative_to(OLD/'app')) for x in raw}: shutil.copy2(source,R/'raw-before'/source.name)
assert sha(A/'test/independent_ed8_no_fault_control_test.dart')=='b03d7e5e0e02cf919208e46215b0e66811fdcecf949bc099709db13dd48722eb'
assert sha(A/'test/independent_ed8_teardown_diagnostic_test.dart')=='a63d9563a084d49fe7b38cae596b148f7c7880b72ccdb2d2811b46dca24838fb'
(R/'REPLAY-SOURCES.json').write_text(json.dumps(replays,indent=2))
for name in ['ROOT-PUBLIC-SPEC.md','REVIEW-RECEIPT.json','NEW-NOFAULT-ADAPTER.diff','full-final-exact-receipt.json','new-final-exact-ed8.log','new-final-exact-ed8-receipt.json','new-final-exact-parent37.log','new-final-exact-parent37-receipt.json','EXPECTED-CASES.json']:
 shutil.copy2(OLD/name,R/'raw-before'/name)
for name in ['new-final-exact-ed8-widget-evidence','new-final-exact-parent37-widget-evidence']:
 shutil.copytree(OLD/name,R/'raw-before'/name)
shutil.copy2(CORE/'CORE-SPEC-REPORT.md',R/'raw-before'/'CORE-SPEC-REPORT.md')
shutil.copy2(OLD/'run.py',R/'run.py')
config=json.loads((BORROW/'.dart_tool/package_config.json').read_text())
for p in config['packages']:
 p['rootUri']='../' if p['name']=='hermes_android' else urllib.parse.urljoin((BORROW/'.dart_tool/package_config.json').as_uri(),p['rootUri'])
(A/'.dart_tool').mkdir()
(A/'.dart_tool/package_config.json').write_text(json.dumps(config,indent=2))
for p in ['.dart_tool/package_graph.json','.flutter-plugins-dependencies']:
 shutil.copy2(BORROW/p,A/p)
(R/'home').mkdir(); (R/'pub-cache').mkdir()
for p in (OLD/'pub-cache').iterdir():
 if p.name in ['hosted','hosted-hashes','git']:
  (R/'pub-cache'/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
env=json.loads((OLD/'env.json').read_text());env['HOME']=str(R/'home');env['PUB_CACHE']=str(R/'pub-cache')
(R/'env.json').write_text(json.dumps(env,indent=2)); (A/'review-evidence').mkdir()
paths=json.loads((OLD/'CACHE-BEFORE.json').read_text())
cache={p:{'sha256':sha(Path(p)),'mtime_ns':Path(p).stat().st_mtime_ns} for p in paths}
assert cache==paths
(R/'CACHE-BEFORE.json').write_text(json.dumps(cache,indent=2))
(R/'RAW-ARCHIVE-HASHES.json').write_text(json.dumps({str(p.relative_to(R)):sha(p) for p in (R/'raw-before').rglob('*') if p.is_file()},indent=2))
(R/'setup.json').write_text(json.dumps({'root':str(R),'app':str(A),'source':str(S),'base':REV,'tracked':len(manifest),'borrow':str(BORROW),'cache_entries':len(cache),'volume_uuid':v['VolumeUUID'],'metadata':{p:sha(A/p) for p in ['.dart_tool/package_config.json','.dart_tool/package_graph.json','.flutter-plugins-dependencies']}},indent=2))
print(R)
