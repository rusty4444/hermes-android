# Parent-approved Android unreconciled-output implementation contract

## Decision and status

The user's exact decision is **“Keep full history + labelled unreconciled-output section”**. The independent contract review is accepted **for implementation**, with the operational clarifications below. This is NOT approval of Android production code, a SPEC/QUALITY pass, or release/device acceptance. No production policy implementation has started.

## Frozen source-of-truth artifacts

- User-approved policy: `/Volumes/Storage/Hermes/scratch/android-unreconciled-output-policy.md`.
- Binding reviewed contract: `/Volumes/Storage/Hermes/scratch/android-unreconciled-contract-3IABnx/IMPLEMENTATION_CONTRACT.md`.
  SHA-256: `2082d6371d9fc2a7b8f9e0710f6d36212f2841d156465be405d380d5b6f0f0e3`.
- Binding oracle ledger: `/Volumes/Storage/Hermes/scratch/android-unreconciled-contract-3IABnx/ORACLE_MIGRATION_LEDGER.md`.
  SHA-256: `d7ea1a5c1f9efa9fcbf589f1deab432770e666f3e87b762ca0eb423b32bec89f`.
- Evidence: same directory `REVIEW_EVIDENCE.json`.

Parent read the complete policy, contract and ledger; inspected the actual frozen owner getter and production renderer; checked clean integration at `cc009ac527c75e9f30bd8176f84ae54c4c2d48b9`, all 39 retained-file names in the ledger, and the source/oracle hash manifest. Hash-audit result follows:

```json
{
  "verified_source_oracle_records": 20,
  "mismatches": [],
  "source_revision": "cc009ac527c75e9f30bd8176f84ae54c4c2d48b9"
}
```

## Binding interpretation / small implementation choices

1. Both ordinal donor partitioning AND ordinary floor-based materialized-output retirement lack correspondence proof in the examined stock protocol. Remove both presentation mechanisms; do not preserve ordinary-success retirement merely to keep historical tests green. Empty-submission scaffold lifecycle cleanup is separate, narrowly bounded and must not erase materialized receipt scopes or independent child-observer state.
2. Use one owner and its existing read-only history/received rows/timeline/tools/subagent fields. A pure UI section DTO/helper is appropriate; no per-section reducer, body journal, reconciliation service or per-group budget. Remove the history-hiding APIs so missed consumers are compile-visible. Keep existing receipt admission floors, WAL, unknown outcomes, exactly-once wire emission and B's request-start authority untouched.
3. Saved and received sources project separately in one lazy list, canonical first, received second, auxiliary task/notice presentation once. Repetition across sources is allowed; duplicate durable identity within C or duplicate local scope within R is not. No text/timing/ordinal matching, global sorting or invented server fields.
4. Use the reviewed localized labels and a visible received provenance badge. No new initially collapsed outer container; retain existing tool/reasoning policies and stable inner card/pin identity. Show a Saved history heading consistently whenever C has visible cells, including C-only presentation, to avoid introducing a new header above existing saved cells only when R arrives. Source-qualify stable outer cell keys and provide keyed lazy-child index lookup; do not fabricate anonymous row correlation.
5. Preserve same Route/State/controllers, actual established non-following scroll behavior, tool visits, drafts and child viewers. The retained exact 120→120 alias control remains binding. Do not turn this into a new universal claim that arbitrary inserted canonical rows preserve both the same pixel and the same semantic text anchor; existing paging/scroll coordination still owns that behavior.
6. Audit ALL consumer gates: empty/error/loading, tool extraction, deferred/latest/paging, export, current-owned voice/unread and child views. Normal export must distinguish sources; current auto-voice/unread must not select unrelated canonical/donor text or fire again because the section or a same-content canonical row appears. SSE/recovery-v2 and model payloads remain unchanged.
7. Keep received data volatile for the existing bounded application/connection lifetime, not a promised eventual match or process-death recovery. Preserve shared run/text/identity/row/tool/task/pin budgets and disclose possible truncation. No new TTL/Hide action is needed. On terminal session/controller close fence callbacks and release its owned buffers; do not claim secure erasure from externally held immutable snapshots or clear another owner's draft/observer state.
8. Preserve raw original tests/receipts and exact hashes; use explicit policy-adapted versions/diffs and assertion-level R/S/A/H ledger. Existing adverse schedules and every unrelated safety assertion remain binding. Actual raw loader/oracle/cleanup results must be reported, not labelled unchanged-green. Do not undo prior public per-visit-tool API/default adaptations.

## Dependency / ownership gate

P2-B delegation `deleg_24287f75` is the sole current writer of owner/history-fetch code in `hermes-android-history-proof-and-refresh`. It must finish its focused commit and actual API handoff; parent must inspect/verify that handoff before creating the P2-A implementation branch. Do not edit its worktree, expand its scope or invent its token method names. B's component and the final A+B consumer contracts require fresh independent SPEC before QUALITY; this policy review supplies neither approval.

After B handoff, one exclusive P2-A writer may implement the accepted contract atop the actual reviewed B source, commit the compact decision/contract/oracle-change documentation into that task branch, and exercise the new two-source model/widget cases plus retained safety/public/Root consumers. Freeze the combined source for fresh independent CORE and Root/public SPEC, then QUALITY. Published ancestry/version remains held at v2.1.32 / 459… / `2.1.32+2175` until separately authorised candidate identity work. No backend protocol change, live configuration, signing, device action, installation, restart, push, tag, PR or release is authorised by this approval.
