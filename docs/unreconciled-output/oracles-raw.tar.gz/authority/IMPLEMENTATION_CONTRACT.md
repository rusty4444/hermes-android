# Reviewed Android uncorrelated-output contract

## Verdict and authority

**POLICY / IMPLEMENTABILITY REVIEW: PASS with the binding refinements below.** These refinements resolve presentation/lifetime/API choices; they do not reopen the user's completeness-over-dedup decision. **No implementation approval, new CORE SPEC PASS, or QUALITY PASS is claimed.** P2-A coding must wait for P2-B's finished, reviewed request-start commit and actual API handoff.

Source of authority: `/Users/sam.russell/.hermes/cache/scratch/android-unreconciled-output-policy.md` (read in full; unchanged). Read-only source: `/Volumes/Storage/Hermes/workspace/hermes-android-post-2.1.32-integration`, HEAD `cc009ac527c75e9f30bd8176f84ae54c4c2d48b9`, clean at initial inspection. Source locations below refer to that frozen tree, **not prospective B code**. Companion `ORACLE_MIGRATION_LEDGER.md` specifies test dispositions.

Read the ambiguity report and both independent SPEC reports supplied by the parent. Identical HTTP rows37,98/99,100/101,102/103 support both donor-persisted and donor-never-persisted worlds. The same observable input MUST produce the SAME truthful two-source projection in both worlds. No hidden World-A/World-B switch or provenance label is allowed.

## 1. Binding observable contract

1. **Canonical source C:** expose the entire accepted loaded/paged canonical window, without a presentation-only prefix/suffix/ordinal partition. Each durable row occurs once by durable identity in that source. Preserve server order and existing pagination/merge semantics; repeat text is not duplicate identity. All accepted raw rows reach the canonical display projector. Existing grouping of consecutive tool results and handling of empty/non-conversation records are not permission to suppress ambiguous messages.
2. **Received source R:** expose each retained local receipt scope once, with its prompt context, text, reasoning, tools and known receipt order. This is not another saved transcript. Retain materialized successful output as well as failed/unknown output when no correspondence is proved. Canonical hydration alone does not remove it.
3. **No cross-source dedup:** C and R may contain identical prompts, replies or tool presentations. Neither text equality nor an admission floor, subsequent user/assistant ordinal, terminal success, a larger row ID, fresh read, one local owner, or local/wire UUID proves that a received reply is a specific HTTP row.
4. **Two source-local orders, not one chronology:** show C first, then R as a separate section. C keeps canonical order; R keeps existing app-owned receipt/import order (`_settledPresentation` observation order followed by retained/current receipt order). The placement is a source grouping, not a claim that all received work happened after all saved rows. Do not globally sort sources by timestamps or IDs.
5. **Visible copy:** heading `Saved history` when both sources are present; R heading **`Received output — match to saved history unconfirmed`**. Explanation: `This may also appear in saved history. The app cannot confirm a match.` Label local user rows **`Local prompt context`**, not server echo or proof of sending. A pre-wire pending/rejected prompt is never presented as sent; keep existing pending/rejection/draft behavior.
6. **Availability:** R is not hidden behind a new initially-collapsed outer section. Existing card-level tool/reasoning policies remain. Loading, 404 and error UI must not cover usable R merely because C is empty. No new privacy storage, replay, history fetch expansion or background matching loop.
7. **Pure presentation:** no header, source flag, duplicate or wrapper enters HTTP/model history, prompt payload, chat DB or nonsecret WAL. Every original prompt remains exactly once on the wire. No automatic retry/resubmit follows a label, refresh, alias, reconnect or section lifecycle.

### Latest snapshot versus loaded window (do not conflate them)

`NormalGatewayChatSnapshot.historyRows` is the owner's last accepted latest observation; `ChatHistoryWindow.rows` is the route's loaded/paged canonical window. They are different existing authorities. Latest acceptance must allow newer empty/unidentified/lower-ID compressed snapshots; do not reject them using a row maximum or an R-related boundary. The existing window may retain previously loaded numeric rows across a shorter/empty latest page; that is the documented paging policy (`chat_history_window.dart:78–130`), not evidence of turn correlation. Test the exact latest observation and the expected retained window separately. This policy does not invent a deletion/compression protocol or require clearing all older loaded history on an empty response.

## 2. Minimal read-only API and renderer proposal (NOT implemented)

**Do not introduce a second received-state owner.** The frozen snapshot already separates the essential data:

| Existing symbol | Contract after P2-A |
|---|---|
| `historyRows` | Accepted canonical latest rows only; unchanged roles/content/IDs. |
| `displayRows` | **Received/local scaffold rows only**; includes settled imports and prior/current local receipt scopes, never copied canonical suffixes. |
| `timeline` | One read-only, bounded, scope-stable projection of received runs only, using existing `forPresentation` / `precededBy`. |
| `tools` | Received tool metadata only; no canonical tool extraction mixed into this snapshot field. |
| `subagents` | Existing independently observed task identity/metadata source; do not equate it with parent receipt retention or clone observer state per section. |
| `turnId`, `phase`, `wireEmitted`, `rowFloor`, input/status/error/draft fields | Existing lifecycle/admission authority; not HTTP row correlation. Preserve unchanged. |
| `presentationHistoryRows`, `historyForPresentation(...)` | **Remove**, including constructor parameter and all production/test consumers. They encode the superseded hiding policy; making them silently keep filtering is forbidden. Removing them makes missed consumers compile-visible. |

The smallest new DTO is a **UI-only section**, not a new turn model or persisted snapshot:

```dart
// Proposed declarations in core/utils/chat_display_items.dart, not existing API.
enum ChatDisplaySource { canonical, received, auxiliary }
class ChatDisplaySection {
  final ChatDisplaySource source;
  final List<dynamic> items; // existing Map/tool/reasoning/task/notice item types
  const ChatDisplaySection({required this.source, required this.items});
}
```

Use immutable item lists. No section fields are inserted into an authoritative message map. A pure proposed helper `buildNormalChatDisplaySections(...)` takes `canonicalRows`, `receivedRows`, `canonicalTools`, `receivedTools`, `receivedTimeline`, the existing merged task list, notices and verbose mode. It performs **separate** calls:

- C: `buildChatDisplayItems(messages: canonicalRows, toolActivities: canonicalTools, verbose: verbose)`; **no received timeline or received tool queue**.
- R: `buildChatDisplayItems(messages: receivedRows, toolActivities: receivedTools, timeline: receivedTimeline, verbose: verbose)`; **no canonical rows**.
- Auxiliary: existing task/notices strip once, without pretending its ordering is canonical or the parent's receipt chronology. Keep the task observer/controller authoritative and identity-merge only by established task/child identity. Do not display a second independent task controller per source.

Return nonempty sections; preserve C/R labels when that source has visible items. One R section can contain multiple local turns/scopes: a per-turn DTO, copied reducers, body cache, section expansion registry and new reconciliation service are unnecessary. Local `_normal_projection_id` anchors and `ChatTimelineRun.scope` retain scope membership; user-delimited interim scopes keep the existing receipt projector behavior. This avoids multiplying tombstone/text budgets by group.

### Actual consumer migration

| Frozen consumer | Required change / retained behavior |
|---|---|
| Owner snapshot getter `normal_gateway_application_session.dart:660–711` | Stop publishing `presentationHistoryRows` and `_hydratedPresentation` as received rows. Snapshot has C plus R, not an effective flattened transcript. Keep immutable rows and stable timeline projections. |
| `_canonicalPresentationBoundary`, `_refreshHydratedPresentation`, `_hydratedPresentation[Floor]`, `_SettledGatewayPresentation.base`, `_presentationBase` | Remove presentation partition/copy machinery once its callers are migrated; do not alter floor/WAL/pre-wire history authority merely because it uses similarly named fields. |
| `_settle:1778–1786`, `_retireSettledPresentation:812–825`, `_retireCompletedPresentation:1926–1947`, `_clearTransientPresentation:2005–2022` | Remove all floor/response-based materialized-output retirement. Settlement and latest acceptance update lifecycle/C without erasing uncorrelated R. Keep real unsent-scaffold cleanup, bounded eviction and teardown as distinct reasons, not claimed canonical matches. |
| `ChatScreen._applyNormalSnapshot:693–928` | Replace floor/base filtering and concatenation at844–868. For normal-owned chat, `_messages` becomes canonical loaded-window rows; retain a read-only snapshot/reference for R, not an independently accumulating route R list. Preserve event/input/status/rejected draft paths, materialization IDs, phase/voice fences and scroll coordinator. Handle the early idle return at725–730 so accepted C and retained R remain renderable even without an active turn. |
| `_applyNormalSnapshot:837–843`, `_fetchMessages`, deferred refresh, paging and `_acceptRecentMessages` | Feed only accepted C into `_historyWindow`. Reuse **B's actual** token/acceptance contract for latest success/error/loading/window effects. Older pages are not new latest observations. Reapply sections after paging without copying R into the window. |
| `_extractToolMessages:2118–2195` | Remove `historyForPresentation` filtering. Extract canonical tool metadata from all C; do not clear or merge the R reducer to install a canonical tool queue. Normal path must keep C-tool and R-tool inputs distinct. Actual matching tool IDs may preserve start/time or pin identity, but cannot retire parent prose/reasoning/whole scope. Keep legacy SSE/recovery-v2 behavior outside this normal-path branch. |
| `_buildBody:5167–5345` | Use sections for normal chat; retain legacy flat projection for SSE/recovery-v2. Extract the current heterogeneous item renderer into a method, not a new lifecycle owner. Flatten section headers/cells into the **same lazy ListView**; no nested scrolling/shrink-wrapped full-history Column. Include usable R in empty/loading/error checks. Load more remains attached to C. |
| Tool alias loop5211–5220; card constructors5250–5285 | Traverse tool groups in both sources. Keep `aliasTool` ingress fanout and current visit pins; matching tool identity is not whole-turn correlation. Preserve existing inner card keys/pin IDs and raw activity/run IDs. Source-qualified **outer cell** keys prevent C/R key collisions; keep those outer keys stable, and use keyed child-index lookup so insertion before a mounted card does not destroy its State. No new outer auto-collapse. |
| `_exportConversation:1316–1337` | For normal chat, export existing prose format under separate Saved history / Received output-unconfirmed headings; never flatten R into apparently saved conversation or silently omit it because `_messages` is now C-only. User-triggered existing sharing only; no new automatic file/journal. SSE export unchanged. |
| Auto-voice899–915, unread807–818 | Announce/materialize an owned current received completion once, not an unrelated latest canonical row or imported donor. Keep current user boundary and stable received assistant IDs; do not count section insertion, alias, identical refresh or C/R repetition as new received work. Manual read-aloud/copy/select remain available in either source. |
| `buildRestChatHistory(_messages):3007`, stock `_sendDesktopGatewayMessage`, recovery-v2 projection paths | No section/synthetic/history-wrapper input; stock wire text emission unchanged. Do not change legacy request construction or reducers just to share a renderer. |
| `_openDelegatedTask:3748–3767`, `DelegatedTaskTimeline` | Same modal/controller, read-only child history; preserve first anchor/latest tip and live sparse updates while C/R changes underneath. No child resume/create or parent scroll/composer reset. |
| `ChatPresentationRegistry` / Root | No new owner, registry, writer lease or Route. `openToolVisit/closeToolVisit/aliasTool/inheritAliasesFrom` remain identity-only bounded fanout; two prebinding views retain independent choices. Root receives no section bodies and retains exact canonical Route/State authority. Fresh affected-consumer verification is still required. |

### What is actually proved today?

No examined stock materialized-turn handoff proves cross-channel correspondence. `_responseRow(row, floor)` proves only a later displayable record; `_retireSettledPresentation` has the same gap even for known-success donors without ordinal counting. **Both must fall back to R.** A shared durable tool ID can prove that tool's identity for aliasing; it does not prove all parent output persisted. The existing explicit preview/reuse completion and scope-reassignment logic is **within received chronology**, not HTTP matching; retain it.

Narrow empty-scaffold exception: `_canHandOffSubmissionScaffolds` may remain only as **completed empty-submission UI cleanup**, renamed/documented accordingly, not canonical correlation. It must exclude every retained/prior materialized text/reasoning/tool/parent-subagent presentation, preserve failed/unknown/unsent draft handling and stale/incomplete-read controls, and never delete another scope. There is no received output to lose in that case; optional local prompt context is not a persistence receipt. No new general matching or evidence DTO is needed in P2-A.

## 3. Exact retention/lifetime and accessibility defaults

- **Storage owner:** existing `NormalGatewayChatOwner` in one `NormalGatewayApplicationSession` per saved connection configuration. R remains volatile. Route cover, pop/dispose and reopen do **not** clear it or resubmit. A verified alias transfers the same scopes/identities to the surviving owner, once; it does not turn them canonical.
- **End of lifetime:** connection removal/revocation, configuration-scope replacement, application-controller/session close, or process death ends availability. Frozen source has no public per-conversation received-clear API: do not advertise one. On terminal session close, synchronously fence callbacks and release owned received rows/timeline/tool buffers; do not change receipt retirement/draft cleanup authority. Previously delivered immutable snapshots cannot be securely erased from arbitrary external holders; make no secure-erasure promise.
- **No TTL or eventual-match promise:** stock observations may never prove a match. Retained output remains labelled for the remaining bounded app/connection lifetime, even after repeated successful reads. No new plaintext persistence is introduced to survive process death. No optional Hide/Dismiss action is required for this minimal change; if later added, it affects R only and cannot delete C, alter WAL or resubmit.
- **Bounds remain shared:** one combined received timeline across settled imports and retained prior/current scopes: existing1024 runs,1048576 text **code units** (not a claim of total byte memory),1024 tool-identity tombstones. Preserve existing row/tool caps too: live/prior row buffers each cap256; the settled-import guard checks combined256 rows/512 tool metadata; individual content/reasoning fields cap262144. Task-observer128 and pin/alias100 limits remain. These are not a claim that the frozen owner already has a universal256-row cap on every donor-free snapshot. Do not give each section its own allowance or rebuild a sliced timeline with fresh tombstones. Evict oldest eligible retained presentation first; keep current recent activity inspectable within the same truncation policy. Never resurrect evicted text from a full row accumulator or tools from the fallback queue. Eviction grants no canonical-match evidence.
- **Disclosure:** `Received output is kept temporarily in this app session and may be shortened or removed as limits are reached. It may not be available after the app or connection is closed.` Do not claim lossless/forever retention or that output was not saved. If truncation cannot be measured with existing metadata, disclose the general limit, not a fabricated per-item eviction count.
- **Accessibility:** localize labels through the existing l10n system; full heading uses header semantics and wraps at400 and1000 widths / enlarged text. A compact visible `Received · match unconfirmed` badge on received cells keeps provenance apparent when the section heading is scrolled away. Add a non-merging semantics label that identifies the source without swallowing ExpansionTile/action descendants or re-announcing every token. Retain selectable/copyable prose, tool/reasoning inspection, focus and standard actions. No tint-only or tooltip-only distinction; do not add a new collapsed source container.
- **UI continuity:** same actual ChatScreen State, ScrollController/position and current Route across alias and latest hydration; user not following stays at the established reader offset (the120.0→120.0 alias control is retained). Keep stable source-cell identity and existing inner card/pin identity; lazy remount restores manual values. True State disposal resets **tool** visit choices only, not reasoning/drafts. Explicit verbose/default preview behavior remains published v2.1.32 policy; this is not a styling redesign.

## 4. Sequencing, code scope and verification gate

Minimal expected production scope: `lib/core/services/normal_gateway_application_session.dart`, `lib/core/screens/chat_screen.dart`, `lib/core/utils/chat_display_items.dart`, plus necessary existing l10n ARB/generated surfaces for the labels. `chat_timeline.dart`, `chat_history_window.dart`, registry/pins, Root, task controller/viewer, stock wire, WAL, native/server and release identity should not need policy changes. If implementation discovers one is necessary, disclose the exact authority reason instead of replacing whole producer files.

**B integration prerequisite:** wait for its finished commit/API; preserve shared physical request-start tokens through actual initial/manual/deferred latest reads and errors, loading/window application and cold multi-page scans. Reassess against B's final signatures. A section DTO must not mint tokens at arrival, pass merged older windows as fresh latest observations, change immutable admission floors, or re-open pre-ACK/WAL/timeout gates.

Required new tests: same-observation worlds A/B; missing donor response/user/both; repeated content and unrelated rows before/between/after; later-at-settlement/later-refresh; newer empty/unidentified/compressed and held stale success/error; no synthetic/request/WAL contamination; no extra submit. Test C and R separately at model and actual ChatScreen levels, with labels, source-local order, per-scope uniqueness, card controllers/keys, read-only child viewer, same-State alias, exact scroll/draft and bounds at400/1000. Preserve all independent safety schedules. Ledger defines old oracle changes.

Freeze the combined A+B target, run source/fixture manifests and precise old/adapted diff receipts; focused new tests, all unaffected retained/public/Root tests, analyzer/format/diff checks and broad suite are regression evidence. Then obtain **fresh independent combined SPEC before QUALITY**. Earlier cc Root/public PASS and2243 tracked/native36/server126 historical results are not approval of the new renderer. Hold published `2.1.32+2175` and459 ancestry; no release/device/live-backend claims.

## Review limitations / implementation stop conditions

- This review inspected source and historical executable receipts; it did not rerun Flutter suites or simulate backend persistence. No package/device/network/auth/config action was needed.
- A implementation is unacceptable if it retains either destructive floor handoff, hides C via a renamed compatibility getter, renders both sources through one tool queue/timeline, loses R in a loading/error branch, or silently updates global flattened matchers.
- Latest-vs-loaded-window behavior, empty-scaffold cleanup, export/auto-voice, source keying and lifetime are binding clarifications above, not unresolved user questions. If final B changes these interfaces, reconcile its actual contract before coding rather than inventing method names.
