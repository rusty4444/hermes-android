# B-only handoff — request-start history authority

## Delivered source

- Commit: **`4a53e32e322423ce36fedc859e0ce62fcbb945c4`**
- Exact parent: `cc009ac527c75e9f30bd8176f84ae54c4c2d48b9`.
- Branch: `fix/android-history-proof-and-refresh`.
- Worktree: `/Volumes/Storage/Hermes/workspace/hermes-android-history-proof-and-refresh` — clean after commit.
- Own execution archive: `/Volumes/Storage/Hermes/scratch/p2b-request-start-xk87p1i1`.
- Own exact-base archive: `/Volumes/Storage/Hermes/scratch/p2b-request-start-xk87p1i1-base`.
- Structured handoff: `/Volumes/Storage/Hermes/scratch/p2b-request-start-xk87p1i1/B_ONLY_REPORT.json`.

Changed only:

1. `lib/core/services/normal_gateway_application_session.dart`
2. `lib/core/screens/chat_screen.dart`
3. New permanent `test/chat_history_request_start_test.dart` (36 cases).

This is a B-only implementation, **not Core approval or release approval**. P2-A ordinal/provenance and ordinary floor-retirement logic were left unchanged. Parent reports that the full-saved-history plus labelled-unreconciled-output contract is approved; that separate implementation has not been attempted here.

## Actual public API / migration contract

```dart
NormalGatewayHistoryRead beginHistoryRead(String stored);
NormalGatewayHistoryRead historyReadFence(String stored);
bool observeHistory(
  List<Map<String, dynamic>> rows, {
  NormalGatewayHistoryRead? read,
});
```

For a physical latest read, capture `beginHistoryRead(stored)` **before** calling the HTTP getter. Carry that exact token through both success and catch; use `observeHistory(rows, read: token)` on success and `token.isCurrent` to reject obsolete error handling. Never mint a token after awaiting the GET. There is no new protocol or ApiClient signature.

- `isAttached` checks the original session/root/local/stored binding and synchronous close fence.
- `isSuperseded` compares only with newer **accepted successful** authority. Issuing a later request, or its failure, does not revoke an older valid success.
- `isCurrent` additionally checks captured admission generation.
- Tokenless `observeHistory(rows)` remains compatible trusted external-observation ingress. Its documentation explicitly does **not** promise physical-request-start freshness.
- `historyReadFence` is for nonzero-offset context paging. It issues no latest sequence and must not be used to promote older context as a latest snapshot.

The owner stores accepted sequence, not maximum row ID/count. Newer empty, unidentified and lower-ID/compressed observations remain admissible. Known/null WAL floors and the bounded unknown-baseline behavior are unchanged.

## Complete production physical caller inventory

Line references below are in the delivered commit. ApiClient remains defined in the unchanged `connection_manager.dart`.

| Caller | Allocation / application / errors |
|---|---|
| Default owner history closure (`normal_gateway_application_session.dart:191`) and route testApiClient injection (`chat_screen.dart:701`) | All enter owner `_readLatestHistory:782–785`, which captures the shared token before `_session._history`. |
| Admission (`owner:1226`), recovery (`:1691`), settlement (`:1943`) | Same typed wrapper. Existing two-second admission bound, recovery observation epochs, generation/active checks and unknown-on-failure/retain-received behavior remain. No new floor-zero fallback. |
| Initial/manual/menu/error-retry route `_fetchMessages` (`chat_screen.dart:1846`) | `_beginHistoryRead:1848` precedes actual GET `:1859`; only offset-zero rows enter owner `:1875`. Recheck after owner subscriber delivery before route window/state. Catch checks shared freshness `:1894` before banner/message mutation. Accepted success clears a later failed refresh's banner. |
| Cold bounded `ChatHistoryWindow.fetchRecent` context pages | One unchanged first-page token across the batch. Later nonzero pages never issue latest authority. Only offset zero is passed to owner; the full batch remains route paging context. Final batch and page-continuation fences reject stale reads. `chat_history_window.dart` itself is unchanged. |
| Single-page helper `_getRecentMessages` (`:1908`) | Requires the already-captured route token and uses its captured stored identity. Its callers cannot silently mint authority after GET completion. |
| Deferred route refresh (`:2000`) | Captures token at `:2012` before helper call. Acceptance precedes route-window/error mutation. Catch checks identity and accepted-success supersession before restoring pending demand; finalizer releases only its captured flight. Required generation-change trailing refresh remains. |
| Older paging (`:1928`, physical GET `:1942`) | Captures `historyReadFence`, window revision, cursor and scroll generation. No `observeHistory` call and no new latest authority. Before apply and in the post-frame anchor callback, recheck identity, accepted authority, cursor/window and activity. Errors retain rows; cleanup releases only its own loader. |
| REST/SSE completion (`:3184` onward) | Captures token at `:3189` before helper GET, then rechecks after HTTP and attachment cleanup await. Catch uses the same token. Separate generation/identity-owned REST stream-latch release cannot overwrite newer transcript/error/status/scroll or leave Send permanently blocked after a discarded GET. |
| Alias adoption (`owner:898`) / close (`:559`, `:2094`) | Existing pre-WAL adoption unchanged. Captured losing-root, changed-binding, new-admission and closed-owner tokens cannot acquire arrival authority in the winner. |

Route tokens also capture value-equal credential/profile/origin configuration, widget-local and stored session identity, admission/response generation, mounted State and window revision. Rehydrating an equivalent connection is not confused with an account replacement. No credentials or token records are logged/persisted.

Loading cleanup is resource ownership, not history freshness: an obsolete result can release its own still-owned loader, never a newer loader or a departed identity's UI. The reentrant-callback regression verifies that a newer accepted observation during synchronous owner notification cannot then be overwritten by the outer route continuation.

## Verified results on the committed bytes

Every named run below has a terminal JSON `done`, explicit per-case IDs/results, no skips, and matching pre/post source hashes. Counts are separate gate results, not an overlapping sum. `B_ONLY_REPORT.json` contains the case lists and exact commands; `delivered-*-summary.json` contains the original reporter-derived receipts.

| Gate | Result |
|---|---|
| Exact independent two stale-route probes on cc009ac | **2 assertion failures**, 0 harness errors/skips (`base-stale-final` in own base archive; original first base run also 2 assertion failures). |
| Same probes on delivered B, twice | **2/2 pass each** (`delivered-stale-1`, `delivered-stale-2`). |
| New permanent matrix, twice | **36/36 pass each** (`delivered-matrix-1`, `delivered-matrix-2`). |
| Base-compatible permanent matrix | **24 assertion failures, 10 passes**, 0 harness errors/skips across 34 cases. Two additive typed-API tests are omitted only in the base copy because cc009ac lacks that API. No remaining semantic assertions changed. Exact deletion-only diff: `../p2b-request-start-xk87p1i1-base/BASE_API_ADAPTATION_DELIVERED.diff`. |
| Retained accepted set | **421/421 pass** (`delivered-retained421`). |
| Prior received-history set | **22/22 pass** (`delivered-prior22`). |
| Prior presentation/identity set | **22/22 pass** (`delivered-new22`). |
| Original independent adverses | **9/9 pass** (`delivered-nine`). |
| ROOT + PUBLIC unchanged/fresh probes | **59/59 pass** (`delivered-root59`, unchanged seven probe files). |
| Agreed cleanup copy | **13/13 pass** (`delivered-cleanup13`). |
| Raw original diagnostic | **12 pass, 1 pending-timer harness error** (`delivered-raw13`). Raw file unchanged; no production timer workaround and no weakening of its original oracle. |
| Fresh six | **2 B passes, 4 expected P2-A assertion failures**, 0 non-assertion errors (`delivered-fresh-six`). |
| Unchanged ambiguity counterexample | **1 expected assertion failure**, 0 harness errors (`delivered-ambiguity`). |
| Tracked full suite, including new permanent matrix | **2,279/2,279 pass** (`delivered-fullTracked`): original tracked 2,243 plus actual 36 new cases. |
| Full combined replay, raw/ambiguity standalone diagnostics excluded | **2,385 completed: 2,381 pass, exactly 4 expected P2-A assertion failures** (`delivered-combined-complete`). No non-assertion errors/skips. Programmatically deduplicated case union matches this run exactly. |
| Fatal full analysis / scoped analysis | **No issues** (`delivered-fatal-analysis-complete.log`, `delivered-scoped-analysis.log`). |
| Format / diff | **75 changed-since-public Dart files clean**, `git diff --check` clean. Scope is in `FORMAT_SCOPE.json`. |

Independent two-case file stayed byte-identical:

`b20a79d490745fac3be5d87dff9519f16fba849ffe4e3361a35d874c04935f88`

The permanent matrix uses physical HTTP entry/response-close/client-completion barriers. It covers appended/empty/lower/unidentified/failed newer reads, stale success/error, two actual hit-testable Refresh requests with later failure, deferred Refresh, close, local-to-stored binding, root redirect, admission, disposal, same-State account/session replacement, cross-owner token rejection, cold multi-page first-page authority, older cursor/anchor preservation and reentrant notification. The two SSE supersession cases use real HTTP/SSE and the retained production Refresh callback: ordinary UI hides that menu during streaming, so these are **explicitly widened callback-seam evidence**, not claimed simultaneous hit-testable user gestures.

The unchanged independent two-case probe is qualified exactly as supplied: the old request is actual hit-testable mounted ChatScreen Refresh; the newer real ApiClient HTTP read enters public owner observation. No second live Navigator route or live backend process is claimed. One intermediate untouched base replay reproduced only one failure (the supplied harness's known variability); both first/final base runs reproduced two. No oracle was altered to conceal this. The new direct physical-barrier matrix is separate permanent evidence.

## P2-A remains intentionally unresolved

The four exact remaining failures are:

- `CC boundary failed donor not persisted must not eat current response later=false`
- `CC boundary failed donor not persisted must not eat current response later=true`
- `CC mounted current preserved without persisted donor 400.0`
- `CC mounted current preserved without persisted donor 1000.0`

All come from unchanged `independent_spec_cc009ac_boundary_test.dart`. Canonical-boundary, hydration and floor-retirement source spans are byte-identical to cc009ac; see `P2A_UNCHANGED_PROOF.json`. Original four-case source and blocker report are preserved in `P2A_PRESERVED/`; the copied `.dart.source` suffix prevents duplicate diagnostic source from entering recursive analysis without changing its bytes. The exact ambiguity test is preserved/executed at `test/history_authority_ambiguity_counterexample_test.dart`.

Equal received/HTTP observations still cannot distinguish donor98/99 from unrelated repeated-content98/99. Request-start freshness does not prove that a donor persisted, and is not being used as correlation. No user/assistant ordinal, count, timestamp, prompt/text matching, donor-boundary or new projection policy was introduced. The approved separate A contract must now be implemented and reverified by its designated writer.

## Provenance, environment, limitations and harness corrections

- Storage UUID was checked before writes: `F7E08904-541C-463A-8BD5-284D3C146333`.
- Before: all **572** tracked blobs / **137** lib files captured. After: all **573** committed tracked blobs / **137** lib files match the worktree and own execution archive exactly (`BASE_MANIFEST.json`, `FINAL_SOURCE_MANIFEST.json`). Only the two authorized existing files differ; one permanent test file is added. Public `459022b93fe1e422cf03bee74862a9a4fefe4fe2` remains an ancestor. No merge/rebase/version change.
- Dependency source is owned sibling `/Volumes/Storage/Hermes/scratch/p2b-request-start-xk87p1i1-pub-cache`, not inside the app. Offline pub get; unchanged lockfile. **7,416 Dart dependency source files** match the read-only source cache, zero mismatches (`CACHE_AUDIT.json`, `CACHE_SOURCE_MANIFEST.json`). Main package config resolves to the own archive. No SDK/package installs/upgrades.
- Flutter **3.44.0**, Dart **3.12.0**, `/opt/homebrew/bin/flutter test --no-pub --concurrency=2 --reporter=json`; specified Java/Android environment retained. Fixtures use disposable loopback HTTP/WS/SSE and mocked preferences, not user conversations.
- Final tests were serial against fixed source. A long shell tool call hit the runtime's 420-second outer cap after tracked-full completion, interrupting combined replay. Its partial log is retained; the standalone **completed** combined replay above is authoritative.
- Earlier harness-only problems are retained in logs, not presented as product failures: missing own `review-evidence/` directory, duplicate preserved diagnostic `.dart` outside test scope, a tooltip finder cast and local-draft recovery-v2 fixture selection. Corrections stayed in own archive/test fixture. An initial new lint was fixed with braces before final validation. No production test-timer hack.
- Frozen ConnectionManager/ApiClient, main/root, presentation/tool pins/model, native/server, dependencies and version files are unchanged. Prior native/server test receipts are **reuse only**; this subtask did not execute the 36 native or 126 server tests. No build/sign/deploy/device/emulator/push/server restart/PR/tag/release actions.
- Default async-concurrency lesson updated to retain shared physical-start tokens through UI errors/callbacks, separate accepted-success order from issued reads and separate paging/resource cleanup from latest authority. No other profile was modified.

Parent should inspect this B API/commit, then branch the separate A worker from these exact bytes. Final integrated SPEC → QUALITY remains required after A. No self-approval is asserted.
